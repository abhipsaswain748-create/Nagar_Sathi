module.exports = {
  darkMode: 'class',
  content: ['./public/index.html', './public/js/**/*.js'],
  theme: {
    extend: {
      colors: {
        brand: { navy: '#15324B', ocean: '#21618C', teal: '#168C86', tealSoft: '#DDF3EF', sky: '#DCECF7', accent: '#4A8DB8' }
      },
      fontFamily: {
        sans: ['Inter', 'Noto Sans Devanagari', 'Noto Sans Oriya', 'sans-serif'],
        heading: ['Manrope', 'Inter', 'Noto Sans Devanagari', 'Noto Sans Oriya', 'sans-serif']
      }
    }
  },
  plugins: []
};
