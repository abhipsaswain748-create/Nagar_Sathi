@echo off
setlocal
title Nagar Sarthi Launcher
cd /d "%~dp0"

echo.
echo ==========================================
echo          NAGAR SARTHI - LAUNCHER
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js is not installed or is not in PATH.
  echo Install Node.js 22.5 or newer from https://nodejs.org/
  echo Finish installation, then double-click this file again.
  echo.
  pause
  exit /b 1
)

for /f "delims=" %%V in ('node -p "process.versions.node"') do set NODE_VERSION=%%V
echo Detected Node.js %NODE_VERSION%
node -e "const [a,b,c]=process.versions.node.split('.').map(Number); process.exit(a>22||(a===22&&(b>5||(b===5&&c>=0)))?0:1)"
if errorlevel 1 (
  echo [ERROR] Nagar Sarthi requires Node.js 22.5.0 or newer.
  echo Update Node.js from https://nodejs.org/ and try again.
  echo.
  pause
  exit /b 1
)

echo.
echo Checking whether Nagar Sarthi is already running...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -Uri 'http://localhost:3000' -UseBasicParsing -TimeoutSec 2; exit 0 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  echo Nagar Sarthi is already running. Opening your browser...
  start "" "http://localhost:3000"
  exit /b 0
)

echo Starting the Nagar Sarthi server...
start "Nagar Sarthi Server" cmd /k "cd /d ""%~dp0"" && node server\index.js"
echo Waiting for the server to become ready...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ready=$false; for($i=0;$i -lt 30;$i++){ try { $r=Invoke-WebRequest -Uri 'http://localhost:3000' -UseBasicParsing -TimeoutSec 2; if($r.StatusCode -ge 200){$ready=$true;break} } catch {}; Start-Sleep -Seconds 1 }; if($ready){ exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo [ERROR] The server did not become ready.
  echo Check the Nagar Sarthi Server window for errors and keep it open while using the app.
  echo.
  pause
  exit /b 1
)

echo Opening Nagar Sarthi in your default browser...
start "" "http://localhost:3000"
echo.
echo Nagar Sarthi is running. Keep the Nagar Sarthi Server window open.
echo Close that server window when you are finished.
timeout /t 5 >nul
exit /b 0
