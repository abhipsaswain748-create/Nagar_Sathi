#!/bin/sh
# Starts Nagar Sarthi (Node.js 22.5 or newer required)
cd "$(dirname "$0")" && exec node server/index.js
