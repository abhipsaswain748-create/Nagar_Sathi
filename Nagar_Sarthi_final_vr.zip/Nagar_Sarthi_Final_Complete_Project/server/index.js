// Nagar Sarthi Full-Stack HTTP Server
// Intelligent Civic Governance Ecosystem

const http = require('node:http');
// Minimal .env loader (no external dependency). Real environment variables take precedence.
(() => {
  const envPath = require('node:path').join(__dirname, '..', '.env');
  try {
    require('node:fs').readFileSync(envPath, 'utf8').split(/\r?\n/).forEach(line => {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    });
  } catch (e) { /* no .env file: defaults apply */ }
})();
const fs = require('node:fs');
const path = require('node:path');
const { db, initSchema } = require('./db');
const { seedDatabase } = require('./seed-data');
const { seedExtra } = require('./seed-extra');
const { resolveUser, STAFF_ROLES } = require('./auth');
const NagarSarthiAI = require('./ai-engine');

const setupComplaintsRoutes = require('./routes/complaints');
const setupAnalyticsRoutes = require('./routes/analytics');
const setupInnovationsRoutes = require('./routes/innovations');
const setupAIRoutes = require('./routes/ai');
const setupAuthRoutes = require('./routes/auth');
const setupNotificationsRoutes = require('./routes/notifications');
const setupFeedbackRoutes = require('./routes/feedback');
const setupWeatherRoutes = require('./routes/weather');
const setupMediaRoutes = require('./routes/media');
const setupSpeechRoutes = require('./routes/speech');
const setupAdminRoutes = require('./routes/admin');

const PORT = process.env.PORT || 3000;
const MAX_BODY_BYTES = Number(process.env.MAX_REQUEST_BYTES || 32 * 1024 * 1024);
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// Initialize database schema and demonstration data
initSchema();
seedDatabase(db);
seedExtra(db);

// Instantiate AI Intelligence Engine
const aiEngine = new NagarSarthiAI(db);

// Simple router mechanism
class Router {
  constructor() {
    this.routes = [];
  }

  add(method, pathPattern, handler) {
    // Convert e.g. /api/complaints/:id to regex
    const paramNames = [];
    const regexPattern = pathPattern.replace(/:([a-zA-Z0-9_]+)/g, (_, name) => {
      paramNames.push(name);
      return '([^/]+)';
    });
    const regex = new RegExp(`^${regexPattern}$`);
    this.routes.push({ method, pathPattern, regex, paramNames, handler });
  }

  get(path, handler) { this.add('GET', path, handler); }
  post(path, handler) { this.add('POST', path, handler); }
  patch(path, handler) { this.add('PATCH', path, handler); }
  put(path, handler) { this.add('PUT', path, handler); }
  delete(path, handler) { this.add('DELETE', path, handler); }

  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method === method) {
        const match = pathname.match(r.regex);
        if (match) {
          const params = {};
          r.paramNames.forEach((name, idx) => {
            params[name] = decodeURIComponent(match[idx + 1]);
          });
          return { handler: r.handler, params };
        }
      }
    }
    return null;
  }
}

const router = new Router();

// Same-origin, fixed-source proxy for the public Bhubaneswar ward population GIS layer.
// This avoids browser CORS restrictions and never accepts a caller-supplied upstream URL.
let wardDensityCache = { at: 0, data: null };
router.get('/api/public/ward-density', async (req, res) => {
  const now = Date.now();
  if (wardDensityCache.data && now - wardDensityCache.at < 6 * 60 * 60 * 1000) {
    res.writeHead(200, { 'Content-Type': 'application/geo+json; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
    res.end(JSON.stringify(wardDensityCache.data));
    return;
  }
  const source = 'https://bhubaneswarone.in/arcgis/rest/services/BhubaneswarOne/AdministrativeBoundary/MapServer/4/query?where=1%3D1&outFields=wardno,totalwardp,Shape_Area,WardLevelO,WardLeve_1&returnGeometry=true&outSR=4326&f=geojson';
  try {
    const upstream = await fetch(source, { headers: { Accept: 'application/geo+json, application/json' }, signal: AbortSignal.timeout(12000) });
    if (!upstream.ok) throw new Error(`Ward GIS upstream returned ${upstream.status}`);
    const data = await upstream.json();
    if (!data || !Array.isArray(data.features)) throw new Error('Ward GIS returned an invalid feature collection');
    wardDensityCache = { at: now, data };
    res.writeHead(200, { 'Content-Type': 'application/geo+json; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
    res.end(JSON.stringify(data));
  } catch (error) {
    console.warn('[Ward density] GIS source unavailable:', error.message);
    res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ success: false, error: 'Ward population GIS service is temporarily unavailable.' }));
  }
});

// Register API Routes
setupComplaintsRoutes(router, db, aiEngine);
setupAnalyticsRoutes(router, db);
setupInnovationsRoutes(router, db);
setupAIRoutes(router, db, aiEngine);
setupAuthRoutes(router, db);
setupNotificationsRoutes(router, db);
setupFeedbackRoutes(router, db);
setupWeatherRoutes(router, db);
setupMediaRoutes(router, db);
setupSpeechRoutes(router, db);
setupAdminRoutes(router, db);

// MIME type dictionary
const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.woff2': 'font/woff2'
};

const server = http.createServer((req, res) => {
  const startTime = Date.now();
  const urlObj = new URL(req.url, `http://${req.headers.host}`);
  const pathname = urlObj.pathname;

  // Set Security Headers (OWASP ASVS / DPDP compliance)
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  // Same-origin app: no wildcard CORS (session cookies must not be usable cross-site)
  res.setHeader('Permissions-Policy', 'microphone=(self), geolocation=(self), camera=(self)');

  // Handle pre-flight CORS
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Handle API routes
  if (pathname.startsWith('/api/')) {
    const chunks = [];
    let size = 0;
    let aborted = false;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES && !aborted) {
        aborted = true;
        res.writeHead(413, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Upload too large. Maximum request size is ' + Math.round(MAX_BODY_BYTES / 1048576) + ' MB.' }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', async () => {
      if (aborted) return;
      const bodyData = Buffer.concat(chunks).toString('utf8');
      if (bodyData) {
        try {
          req.body = JSON.parse(bodyData);
        } catch (e) {
          req.body = {};
        }
      } else {
        req.body = {};
      }
      try { req.user = resolveUser(db, req); } catch (e) { req.user = null; }

      // Central guard for legacy modules (innovations / analytics) written before role checks existed
      const staffOnly = (pathname.startsWith('/api/innovations/') && !['/api/innovations/civic-echo', '/api/innovations/duplicates'].includes(pathname))
        || pathname === '/api/analytics/charts';
      if (staffOnly && (!req.user || !STAFF_ROLES.includes(req.user.role))) {
        res.writeHead(req.user ? 403 : 401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: req.user ? 'You do not have permission for this action.' : 'Please log in to continue.' }));
        return;
      }

      const routeMatch = router.match(req.method, pathname);
      if (routeMatch) {
        try {
          await routeMatch.handler(req, res, routeMatch.params);
          const duration = Date.now() - startTime;
          console.log(`[API] ${req.method} ${pathname} - ${duration}ms`);
        } catch (err) {
          console.error(`[API ERROR] ${req.method} ${pathname}:`, err);
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'Internal server error' }));
        }
      } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: `Endpoint ${req.method} ${pathname} not found` }));
      }
    });
    return;
  }

  // Handle Static Files
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  // Security check: Prevent path traversal
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Access Denied');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // If not a file and not starting with /api, serve index.html for SPA client-side routing
      const indexHtml = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(indexHtml, (err2, content) => {
        if (err2) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('Not Found');
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    // Cache control: app code must refresh after updates; vendor assets can be cached
    res.setHeader('Cache-Control', pathname.startsWith('/vendor/') ? 'public, max-age=86400' : 'no-cache');

    fs.readFile(filePath, (err3, data) => {
      if (err3) {
        res.writeHead(500);
        res.end('File read error');
        return;
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    });
  });
});

server.listen(PORT, () => {
  console.log('================================================================');
  console.log('  🏛️  NAGAR SARTHI — AI-POWERED CIVIC GOVERNANCE ECOSYSTEM');
  console.log(`  🌐  Server running live at: http://localhost:${PORT}`);
  console.log('  🚀  Citizen, Administrative & Field Officer Portals Ready');
  console.log('================================================================');
});
