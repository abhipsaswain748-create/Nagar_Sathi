// Innovations Routes: CivicDNA, CivicPulse, CivicEcho, CivicForecast, CivicRoute, CivicProof, CivicTrace
const crypto = require('node:crypto');

function setupInnovationsRoutes(router, db) {
  // 1. CivicDNA / CivicTwin: Persistent Infrastructure Memory
  router.get('/api/innovations/civic-dna', (req, res) => {
    try {
      const assets = db.prepare(`
        SELECT i.*, 
               COUNT(c.id) as current_open_complaints
        FROM infrastructure_entities i
        LEFT JOIN complaints c ON i.id = c.infrastructure_asset_id AND c.status NOT IN ('Verified / Closed', 'Resolved')
        GROUP BY i.id
        ORDER BY i.total_failures DESC
      `).all();

      const enriched = assets.map(a => {
        const history = db.prepare('SELECT * FROM infrastructure_history WHERE infrastructure_id = ? ORDER BY repair_date DESC').all(a.id);
        return {
          ...a,
          repair_history: history
        };
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: enriched,
        meta: {
          concept: 'CivicDNA / CivicTwin',
          description: 'Tracks persistent structural memory of physical infrastructure to distinguish recurring engineering failures from one-off complaints.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicDNA error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 2. CivicPulse: Hotspot and Surge Detection
  router.get('/api/innovations/civic-pulse', (req, res) => {
    try {
      const hotspots = db.prepare('SELECT * FROM hotspot_records ORDER BY surge_percentage DESC').all();

      // Dynamically compute real-time surge clusters from complaints in last 7 days
      const clusters = db.prepare(`
        SELECT locality, category, ward_no, COUNT(*) as count,
               AVG(latitude) as center_lat, AVG(longitude) as center_lon
        FROM complaints
        GROUP BY locality, category
        HAVING count >= 2
        ORDER BY count DESC
      `).all();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: {
          verifiedHotspots: hotspots,
          emergingClusters: clusters
        },
        meta: {
          concept: 'CivicPulse',
          description: 'Spatial and temporal density surge algorithm identifying localized infrastructure stress before systemic failure.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicPulse error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 3. CivicEcho: Collective Impact Intelligence
  router.get('/api/innovations/civic-echo', (req, res) => {
    try {
      // Find parent incidents with linked sub-reports
      const grouped = db.prepare(`
        SELECT p.id as parent_id, p.title as parent_title, p.category, p.locality,
               p.community_confirmations_count, p.affected_citizens_estimate,
               COUNT(sub.id) as linked_duplicate_reports_count
        FROM complaints p
        LEFT JOIN complaints sub ON p.id = sub.parent_incident_id
        WHERE p.parent_incident_id IS NULL AND (sub.id IS NOT NULL OR p.community_confirmations_count > 1)
        GROUP BY p.id
        ORDER BY p.community_confirmations_count DESC
      `).all();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: grouped,
        meta: {
          concept: 'CivicEcho',
          description: 'Aggregates collective citizen weight and correlates duplicate incident reports into one parent incident without erasing individual citizen tickets.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicEcho error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 3b. Duplicate & Nearby Incident Detection Sentinel
  router.get('/api/innovations/duplicates', (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const lat = parseFloat(url.searchParams.get('lat') || '20.2961');
      const lon = parseFloat(url.searchParams.get('lon') || '85.8245');
      const category = url.searchParams.get('category') || '';

      const complaints = db.prepare(`
        SELECT id, tracking_number, title, category, latitude, longitude, status, locality
        FROM complaints
        WHERE status NOT IN ('Verified / Closed', 'Resolved')
      `).all();

      function getDistanceMeters(lat1, lon1, lat2, lon2) {
        const R = 6371e3;
        const phi1 = lat1 * Math.PI / 180;
        const phi2 = lat2 * Math.PI / 180;
        const deltaPhi = (lat2 - lat1) * Math.PI / 180;
        const deltaLambda = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(deltaPhi/2) * Math.sin(deltaPhi/2) +
                  Math.cos(phi1) * Math.cos(phi2) *
                  Math.sin(deltaLambda/2) * Math.sin(deltaLambda/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      }

      const matches = [];
      for (const c of complaints) {
        if (c.latitude && c.longitude) {
          const dist = getDistanceMeters(lat, lon, c.latitude, c.longitude);
          if (dist <= 300) {
            const isCatMatch = !category || c.category === category;
            const score = isCatMatch ? Math.round(100 - (dist / 300) * 35) : Math.round(50 - (dist / 300) * 20);
            if (score >= 50) {
              matches.push({
                ...c,
                distanceMeters: Math.round(dist),
                similarityScore: score
              });
            }
          }
        }
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, count: matches.length, data: matches }));
    } catch (err) {
      console.error('[API] duplicates error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 4. CivicForecast: Predictive SLA Intelligence
  router.get('/api/innovations/civic-forecast', (req, res) => {
    try {
      const now = new Date();
      const openComplaints = db.prepare(`
        SELECT c.id, c.title, c.category, c.locality, c.status, c.priority,
               c.priority_score, c.sla_deadline, c.is_overdue, c.created_at,
               d.name as department_name, d.code as department_code,
               o.name as officer_name, o.active_tasks
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN officers o ON c.assigned_officer_id = o.id
        WHERE c.status NOT IN ('Verified / Closed', 'Resolved')
        ORDER BY c.sla_deadline ASC
      `).all();

      const forecastList = openComplaints.map(c => {
        const deadline = new Date(c.sla_deadline);
        const hoursRemaining = Math.round((deadline.getTime() - now.getTime()) / (3600 * 1000));
        
        let riskCategory = 'LOW_RISK';
        let breachProbability = 15;
        const reasons = [];

        if (c.is_overdue || hoursRemaining <= 0) {
          riskCategory = 'BREACHED';
          breachProbability = 100;
          reasons.push(`SLA threshold already exceeded by ${Math.abs(hoursRemaining)} hours.`);
          reasons.push('Immediate escalation required to avoid public grievance hearing.');
        } else if (hoursRemaining <= 8) {
          riskCategory = 'CRITICAL_RISK';
          breachProbability = 85;
          reasons.push(`Only ${hoursRemaining} hours remaining before SLA breach.`);
          if (c.active_tasks > 3) reasons.push(`Assigned officer ${c.officer_name || 'Crew'} has high task queue (${c.active_tasks} active).`);
          if (c.priority === 'High') reasons.push('High-complexity technical resolution requires specialized machinery.');
        } else if (hoursRemaining <= 20) {
          riskCategory = 'MODERATE_RISK';
          breachProbability = 52;
          reasons.push(`${hoursRemaining} hours remaining. Work in progress.`);
        } else {
          riskCategory = 'ON_TRACK';
          breachProbability = 12;
          reasons.push(`Within safe operational window (${hoursRemaining}h remaining).`);
        }

        return {
          ...c,
          hoursRemaining,
          riskCategory,
          breachProbability,
          riskReasons: reasons
        };
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: forecastList,
        meta: {
          concept: 'CivicForecast',
          description: 'Explainable rule-based predictive sentinel forecasting SLA breach vulnerabilities before they occur.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicForecast error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 5. CivicRoute: Intelligent Work Bundling
  router.get('/api/innovations/civic-route', (req, res) => {
    try {
      const bundles = db.prepare(`
        SELECT b.*, d.name as department_name, o.name as officer_name
        FROM field_operation_groups b
        LEFT JOIN departments d ON b.department_id = d.id
        LEFT JOIN officers o ON b.assigned_officer_id = o.id
        ORDER BY b.created_at DESC
      `).all();

      const enriched = bundles.map(b => {
        const ids = JSON.parse(b.complaint_ids);
        const placeholders = ids.map(() => '?').join(',');
        const complaints = db.prepare(`
          SELECT id, title, category, latitude, longitude, landmark, status
          FROM complaints
          WHERE id IN (${placeholders})
        `).all(...ids);

        return {
          ...b,
          complaints
        };
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: enriched,
        meta: {
          concept: 'CivicRoute',
          description: 'Geospatial task bundling identifying nearby complaints to eliminate duplicate dispatch mileage and save fuel.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicRoute error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // Approve & Dispatch CivicRoute Bundle
  router.post('/api/innovations/civic-route/dispatch', (req, res) => {
    try {
      const { bundle_id, officer_id } = req.body;
      db.prepare(`UPDATE field_operation_groups SET status = 'Dispatched' WHERE id = ?`).run(bundle_id);

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, message: `CivicRoute bundle ${bundle_id} dispatched successfully.` }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 6. CivicProof: Evidence-Based Resolution Ledger
  router.get('/api/innovations/civic-proof', (req, res) => {
    try {
      const proofs = db.prepare(`
        SELECT id, tracking_number, title, category, locality, status,
               initial_photo_url, resolution_photo_url, resolution_notes,
               resolved_at, verified_at, is_disputed, dispute_reason
        FROM complaints
        WHERE initial_photo_url IS NOT NULL AND (resolution_photo_url IS NOT NULL OR status IN ('Resolution Submitted', 'Verified / Closed', 'Disputed'))
        ORDER BY updated_at DESC
      `).all();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: proofs,
        meta: {
          concept: 'CivicProof',
          description: 'Immutable before-and-after photographic evidence validation system preventing premature closure.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicProof error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  // 7. CivicTrace: Tamper-Evident Immutable Audit Log
  router.get('/api/innovations/civic-trace', (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const complaintId = url.searchParams.get('complaint_id');

      let sql = 'SELECT * FROM audit_logs';
      const params = [];
      if (complaintId) {
        sql += ' WHERE complaint_id = ?';
        params.push(complaintId);
      }
      sql += ' ORDER BY created_at DESC LIMIT 50';

      const logs = db.prepare(sql).all(...params);

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: logs,
        meta: {
          concept: 'CivicTrace',
          description: 'Append-only audit trail logging every workflow event, actor, timestamp and cryptographic hash verification.'
        }
      }));
    } catch (err) {
      console.error('[API] CivicTrace error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });
}

module.exports = setupInnovationsRoutes;
