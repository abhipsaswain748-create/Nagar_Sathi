// Nagar Sarthi AI routes
// - /api/ai/classify   : category suggestion (citizen must confirm; never auto-applied)
// - /api/ai/chat       : multilingual assistant grounded on the caller's authorised records
// If ANTHROPIC_API_KEY is configured the reply wording can be produced by an external model,
// but facts (IDs, statuses, deadlines) always come from the database. Otherwise a clearly
// labelled rule-based assistant answers.
const { ROLES, STAFF_ROLES } = require('../auth');
const { ok, fail, requireAuth, cleanText } = require('../http-utils');

const L = {
  English: {
    greeting: 'Hello! I can help you report a civic problem, choose the right category, track your complaints, and explain verification, SLA deadlines and feedback.',
    loginNeeded: 'Please log in as a citizen so I can look up your complaints.',
    notFound: 'I could not find complaint {id} among the complaints you are allowed to see.',
    status: 'Complaint {id} ("{title}") is currently "{status}". Category: {category}. Department: {dept}. SLA deadline: {deadline} ({sla}).',
    nextVerify: 'The authority marked it resolved. Open the complaint and tell us whether the issue is actually fixed.',
    nextDisputed: 'Your dispute is with the administration for review.',
    noComplaints: 'You have not submitted any complaints yet. Use "Report an Issue" to start.',
    myList: 'You have {n} complaint(s). Open ones:',
    allClosed: 'All your complaints are closed.',
    suggest: 'This sounds like "{category}" (suggestion based on the words: {evidence}). You can accept it or choose a different domain on the report form.',
    suggestUncertain: 'I am not sure which domain fits. Please choose the domain yourself on the report form.',
    missingLocation: 'Please also add a landmark or pin the location on the map.',
    report: 'To report: 1) open Report an Issue, 2) type or speak the problem, 3) confirm the domain, 4) set the location, 5) add photos, 6) review and submit. Nothing is submitted without your confirmation.',
    verify: 'When the authority marks your complaint resolved with a completion photo, you will be asked "Has the issue actually been resolved?". Choose Yes to close it, or No with a reason (and an optional photo) to send it back for review.',
    sla: 'Each domain has a target resolution time set by the department (demo values): {list}. The deadline starts when you submit.',
    community: 'Public reports right now: {list}. Open Civic Echo Community to confirm problems you also face.',
    feedback: 'After a complaint is resolved you can rate the work and the department, report incomplete work and add photos from the Feedback page.',
    staff: 'Open complaints in your scope: {open}. Overdue: {overdue}. Awaiting your review of completion evidence: {review}. Disputed: {disputed}.',
    fallback: 'I can help with: reporting a problem, choosing a category, tracking a complaint (send its ID, e.g. NS-2026-1101), SLA deadlines, verification and feedback.',
    rule: 'Rule-based assistant (no external AI configured)'
  },
  Hindi: {
    greeting: 'नमस्ते! मैं नागरिक समस्या दर्ज करने, सही श्रेणी चुनने, आपकी शिकायतों को ट्रैक करने और सत्यापन, SLA समय-सीमा व प्रतिक्रिया समझाने में मदद कर सकता हूँ।',
    loginNeeded: 'कृपया नागरिक के रूप में लॉग इन करें ताकि मैं आपकी शिकायतें देख सकूँ।',
    notFound: 'मुझे शिकायत {id} उन शिकायतों में नहीं मिली जिन्हें आप देख सकते हैं।',
    status: 'शिकायत {id} ("{title}") की वर्तमान स्थिति "{status}" है। श्रेणी: {category}। विभाग: {dept}। SLA समय-सीमा: {deadline} ({sla})।',
    nextVerify: 'प्राधिकरण ने इसे हल चिह्नित किया है। शिकायत खोलें और बताएं कि समस्या वास्तव में ठीक हुई या नहीं।',
    nextDisputed: 'आपकी आपत्ति प्रशासन के पास समीक्षा के लिए है।',
    noComplaints: 'आपने अभी तक कोई शिकायत दर्ज नहीं की है। शुरू करने के लिए "समस्या दर्ज करें" का उपयोग करें।',
    myList: 'आपकी {n} शिकायत(ें) हैं। खुली शिकायतें:',
    allClosed: 'आपकी सभी शिकायतें बंद हो चुकी हैं।',
    suggest: 'यह "{category}" जैसा लगता है (इन शब्दों पर आधारित सुझाव: {evidence})। आप इसे स्वीकार कर सकते हैं या रिपोर्ट फ़ॉर्म में दूसरी श्रेणी चुन सकते हैं।',
    suggestUncertain: 'मुझे निश्चित नहीं है कि कौन-सी श्रेणी सही है। कृपया रिपोर्ट फ़ॉर्म में स्वयं श्रेणी चुनें।',
    missingLocation: 'कृपया कोई पहचान-चिह्न भी जोड़ें या मानचित्र पर स्थान चिह्नित करें।',
    report: 'दर्ज करने के लिए: 1) "समस्या दर्ज करें" खोलें, 2) समस्या लिखें या बोलें, 3) श्रेणी की पुष्टि करें, 4) स्थान चुनें, 5) फ़ोटो जोड़ें, 6) जाँचकर जमा करें। आपकी पुष्टि के बिना कुछ भी जमा नहीं होता।',
    verify: 'जब प्राधिकरण पूर्णता फ़ोटो के साथ आपकी शिकायत को हल चिह्नित करेगा, तो आपसे पूछा जाएगा "क्या समस्या वास्तव में हल हो गई है?"। बंद करने के लिए हाँ चुनें, या कारण (और वैकल्पिक फ़ोटो) के साथ नहीं चुनकर इसे दोबारा समीक्षा के लिए भेजें।',
    sla: 'हर श्रेणी का विभाग द्वारा तय लक्ष्य समाधान समय है (डेमो मान): {list}। समय-सीमा जमा करने के समय से शुरू होती है।',
    community: 'अभी की सार्वजनिक रिपोर्टें: {list}। जिन समस्याओं का सामना आप भी कर रहे हैं उनकी पुष्टि के लिए सिविक इको समुदाय खोलें।',
    feedback: 'शिकायत हल होने के बाद आप प्रतिक्रिया पृष्ठ से कार्य और विभाग को रेटिंग दे सकते हैं, अधूरे कार्य की सूचना दे सकते हैं और फ़ोटो जोड़ सकते हैं।',
    staff: 'आपके दायरे में खुली शिकायतें: {open}। समय-सीमा पार: {overdue}। पूर्णता साक्ष्य की समीक्षा लंबित: {review}। विवादित: {disputed}।',
    fallback: 'मैं इनमें मदद कर सकता हूँ: समस्या दर्ज करना, श्रेणी चुनना, शिकायत ट्रैक करना (उसकी ID भेजें, जैसे NS-2026-1101), SLA समय-सीमा, सत्यापन और प्रतिक्रिया।',
    rule: 'नियम-आधारित सहायक (कोई बाहरी AI कॉन्फ़िगर नहीं)'
  },
  Odia: {
    greeting: 'ନମସ୍କାର! ମୁଁ ନାଗରିକ ସମସ୍ୟା ଦାଖଲ କରିବା, ଠିକ୍ ବର୍ଗ ବାଛିବା, ଆପଣଙ୍କ ଅଭିଯୋଗ ଟ୍ରାକ୍ କରିବା ଏବଂ ଯାଞ୍ଚ, SLA ସମୟସୀମା ଓ ମତାମତ ବୁଝାଇବାରେ ସାହାଯ୍ୟ କରିପାରିବି।',
    loginNeeded: 'ଦୟାକରି ନାଗରିକ ଭାବେ ଲଗ୍ ଇନ୍ କରନ୍ତୁ ଯାହାଦ୍ୱାରା ମୁଁ ଆପଣଙ୍କ ଅଭିଯୋଗ ଦେଖିପାରିବି।',
    notFound: 'ଆପଣ ଦେଖିପାରୁଥିବା ଅଭିଯୋଗ ମଧ୍ୟରେ ମୁଁ ଅଭିଯୋଗ {id} ପାଇଲି ନାହିଁ।',
    status: 'ଅଭିଯୋଗ {id} ("{title}") ର ବର୍ତ୍ତମାନ ସ୍ଥିତି "{status}"। ବର୍ଗ: {category}। ବିଭାଗ: {dept}। SLA ସମୟସୀମା: {deadline} ({sla})।',
    nextVerify: 'କର୍ତ୍ତୃପକ୍ଷ ଏହାକୁ ସମାଧାନ ଚିହ୍ନିତ କରିଛନ୍ତି। ଅଭିଯୋଗ ଖୋଲି ସମସ୍ୟା ପ୍ରକୃତରେ ଠିକ୍ ହୋଇଛି କି ନାହିଁ ଜଣାନ୍ତୁ।',
    nextDisputed: 'ଆପଣଙ୍କ ଆପତ୍ତି ପ୍ରଶାସନ ପାଖରେ ସମୀକ୍ଷା ପାଇଁ ଅଛି।',
    noComplaints: 'ଆପଣ ଏପର୍ଯ୍ୟନ୍ତ କୌଣସି ଅଭିଯୋଗ ଦାଖଲ କରିନାହାଁନ୍ତି। ଆରମ୍ଭ କରିବାକୁ "ସମସ୍ୟା ଦାଖଲ କରନ୍ତୁ" ବ୍ୟବହାର କରନ୍ତୁ।',
    myList: 'ଆପଣଙ୍କର {n}ଟି ଅଭିଯୋଗ ଅଛି। ଖୋଲା ଅଭିଯୋଗ:',
    allClosed: 'ଆପଣଙ୍କ ସମସ୍ତ ଅଭିଯୋଗ ବନ୍ଦ ହୋଇଯାଇଛି।',
    suggest: 'ଏହା "{category}" ପରି ଲାଗୁଛି (ଏହି ଶବ୍ଦ ଉପରେ ଆଧାରିତ ପରାମର୍ଶ: {evidence})। ଆପଣ ଏହାକୁ ଗ୍ରହଣ କରିପାରିବେ କିମ୍ବା ରିପୋର୍ଟ ଫର୍ମରେ ଅନ୍ୟ ବର୍ଗ ବାଛିପାରିବେ।',
    suggestUncertain: 'କେଉଁ ବର୍ଗ ଠିକ୍ ମୁଁ ନିଶ୍ଚିତ ନୁହେଁ। ଦୟାକରି ରିପୋର୍ଟ ଫର୍ମରେ ନିଜେ ବର୍ଗ ବାଛନ୍ତୁ।',
    missingLocation: 'ଦୟାକରି ଏକ ଚିହ୍ନିତ ସ୍ଥାନ ମଧ୍ୟ ଯୋଗ କରନ୍ତୁ କିମ୍ବା ମାନଚିତ୍ରରେ ସ୍ଥାନ ଚିହ୍ନିତ କରନ୍ତୁ।',
    report: 'ଦାଖଲ କରିବାକୁ: 1) "ସମସ୍ୟା ଦାଖଲ କରନ୍ତୁ" ଖୋଲନ୍ତୁ, 2) ସମସ୍ୟା ଲେଖନ୍ତୁ କିମ୍ବା କୁହନ୍ତୁ, 3) ବର୍ଗ ନିଶ୍ଚିତ କରନ୍ତୁ, 4) ସ୍ଥାନ ବାଛନ୍ତୁ, 5) ଫଟୋ ଯୋଗ କରନ୍ତୁ, 6) ଯାଞ୍ଚ କରି ଦାଖଲ କରନ୍ତୁ। ଆପଣଙ୍କ ନିଶ୍ଚିତକରଣ ବିନା କିଛି ଦାଖଲ ହୁଏ ନାହିଁ।',
    verify: 'କର୍ତ୍ତୃପକ୍ଷ ସମାପ୍ତି ଫଟୋ ସହ ଆପଣଙ୍କ ଅଭିଯୋଗକୁ ସମାଧାନ ଚିହ୍ନିତ କଲେ ଆପଣଙ୍କୁ ପଚରାଯିବ "ସମସ୍ୟା ପ୍ରକୃତରେ ସମାଧାନ ହୋଇଛି କି?"। ବନ୍ଦ କରିବାକୁ ହଁ ବାଛନ୍ତୁ, କିମ୍ବା କାରଣ (ଓ ବୈକଳ୍ପିକ ଫଟୋ) ସହ ନା ବାଛି ପୁନର୍ବାର ସମୀକ୍ଷା ପାଇଁ ପଠାନ୍ତୁ।',
    sla: 'ପ୍ରତ୍ୟେକ ବର୍ଗର ବିଭାଗ ଦ୍ୱାରା ନିର୍ଦ୍ଧାରିତ ଲକ୍ଷ୍ୟ ସମାଧାନ ସମୟ ଅଛି (ଡେମୋ ମୂଲ୍ୟ): {list}। ଦାଖଲ କରିବା ସମୟରୁ ସମୟସୀମା ଆରମ୍ଭ ହୁଏ।',
    community: 'ବର୍ତ୍ତମାନର ସାର୍ବଜନୀନ ରିପୋର୍ଟ: {list}। ଆପଣ ମଧ୍ୟ ସମ୍ମୁଖୀନ ହେଉଥିବା ସମସ୍ୟା ନିଶ୍ଚିତ କରିବାକୁ ସିଭିକ ଇକୋ ସମୁଦାୟ ଖୋଲନ୍ତୁ।',
    feedback: 'ଅଭିଯୋଗ ସମାଧାନ ପରେ ଆପଣ ମତାମତ ପୃଷ୍ଠାରୁ କାର୍ଯ୍ୟ ଓ ବିଭାଗକୁ ମୂଲ୍ୟାଙ୍କନ କରିପାରିବେ, ଅସମ୍ପୂର୍ଣ୍ଣ କାର୍ଯ୍ୟ ଜଣାଇପାରିବେ ଏବଂ ଫଟୋ ଯୋଗ କରିପାରିବେ।',
    staff: 'ଆପଣଙ୍କ ପରିସରରେ ଖୋଲା ଅଭିଯୋଗ: {open}। ସମୟସୀମା ଅତିକ୍ରାନ୍ତ: {overdue}। ସମାପ୍ତି ପ୍ରମାଣ ସମୀକ୍ଷା ବାକି: {review}। ବିବାଦିତ: {disputed}।',
    fallback: 'ମୁଁ ଏଥିରେ ସାହାଯ୍ୟ କରିପାରିବି: ସମସ୍ୟା ଦାଖଲ, ବର୍ଗ ବାଛିବା, ଅଭିଯୋଗ ଟ୍ରାକ୍ (ଏହାର ID ପଠାନ୍ତୁ, ଯଥା NS-2026-1101), SLA ସମୟସୀମା, ଯାଞ୍ଚ ଓ ମତାମତ।',
    rule: 'ନିୟମ-ଆଧାରିତ ସହାୟକ (କୌଣସି ବାହ୍ୟ AI ବିନ୍ୟାସିତ ନାହିଁ)'
  }
};

// Data labels the assistant inserts (categories / statuses) in each language
const CAT = {
  Hindi: { 'Road damage / potholes': 'सड़क क्षति / गड्ढे', 'Garbage accumulation': 'कचरा जमाव', 'Water leakage': 'जल रिसाव / जल आपूर्ति', 'Drainage blockage': 'नाली अवरोध', 'Streetlight failure': 'स्ट्रीटलाइट खराबी', 'Waterlogging / flooding': 'जलभराव / बाढ़', 'Damaged public infrastructure': 'क्षतिग्रस्त सार्वजनिक अवसंरचना', 'Sanitation issues': 'स्वच्छता समस्याएँ', 'Public safety hazards': 'सार्वजनिक सुरक्षा खतरे', 'Parks and public spaces': 'पार्क और सार्वजनिक स्थान', 'Other civic problems': 'अन्य नागरिक समस्याएँ' },
  Odia: { 'Road damage / potholes': 'ରାସ୍ତା କ୍ଷତି / ଗାତ', 'Garbage accumulation': 'ଅଳିଆ ଜମା', 'Water leakage': 'ଜଳ ଲିକ୍ / ଜଳ ଯୋଗାଣ', 'Drainage blockage': 'ନାଳ ଅବରୋଧ', 'Streetlight failure': 'ଷ୍ଟ୍ରିଟଲାଇଟ ବିଫଳତା', 'Waterlogging / flooding': 'ଜଳବନ୍ଦୀ / ବନ୍ୟା', 'Damaged public infrastructure': 'କ୍ଷତିଗ୍ରସ୍ତ ସାର୍ବଜନୀନ ଭିତ୍ତିଭୂମି', 'Sanitation issues': 'ପରିମଳ ସମସ୍ୟା', 'Public safety hazards': 'ସାର୍ବଜନୀନ ସୁରକ୍ଷା ବିପଦ', 'Parks and public spaces': 'ପାର୍କ ଓ ସାର୍ବଜନୀନ ସ୍ଥାନ', 'Other civic problems': 'ଅନ୍ୟାନ୍ୟ ନାଗରିକ ସମସ୍ୟା' }
};
const STAT = {
  Hindi: { 'Submitted': 'जमा', 'Under Review': 'समीक्षाधीन', 'Assigned': 'सौंपा गया', 'In Progress': 'कार्य प्रगति पर', 'Resolution Submitted': 'समाधान प्रस्तुत', 'Resolved': 'हल (सत्यापन प्रतीक्षित)', 'Verified / Closed': 'सत्यापित / बंद', 'Disputed': 'विवादित', 'Reopened': 'पुनः खोला गया', 'Escalated': 'उच्च स्तर पर भेजा गया', 'Rejected': 'अस्वीकृत' },
  Odia: { 'Submitted': 'ଦାଖଲ', 'Under Review': 'ସମୀକ୍ଷାଧୀନ', 'Assigned': 'ଦାୟିତ୍ୱ ଦିଆଯାଇଛି', 'In Progress': 'କାର୍ଯ୍ୟ ଚାଲିଛି', 'Resolution Submitted': 'ସମାଧାନ ଦାଖଲ', 'Resolved': 'ସମାଧାନ (ଯାଞ୍ଚ ଅପେକ୍ଷାରେ)', 'Verified / Closed': 'ଯାଞ୍ଚିତ / ବନ୍ଦ', 'Disputed': 'ବିବାଦିତ', 'Reopened': 'ପୁନଃ ଖୋଲାଗଲା', 'Escalated': 'ଉଚ୍ଚସ୍ତରକୁ ପଠାଗଲା', 'Rejected': 'ପ୍ରତ୍ୟାଖ୍ୟାତ' }
};
const SLA_TXT = {
  English: { overdue: 'overdue', due_today: 'due today', approaching: 'deadline approaching', on_track: 'on track', met: 'met', closed: 'closed', breached_closed: 'closed after deadline', escalated: 'escalated', escalated_overdue: 'escalated, overdue' },
  Hindi: { overdue: 'समय-सीमा पार', due_today: 'आज देय', approaching: 'समय-सीमा निकट', on_track: 'समय पर', met: 'समय पर पूरा', closed: 'बंद', breached_closed: 'समय-सीमा के बाद बंद', escalated: 'उच्च स्तर पर', escalated_overdue: 'उच्च स्तर पर, समय-सीमा पार' },
  Odia: { overdue: 'ସମୟସୀମା ଅତିକ୍ରାନ୍ତ', due_today: 'ଆଜି ଦେୟ', approaching: 'ସମୟସୀମା ନିକଟ', on_track: 'ସମୟ ମଧ୍ୟରେ', met: 'ସମୟରେ ସମ୍ପୂର୍ଣ୍ଣ', closed: 'ବନ୍ଦ', breached_closed: 'ସମୟସୀମା ପରେ ବନ୍ଦ', escalated: 'ଉଚ୍ଚସ୍ତରରେ', escalated_overdue: 'ଉଚ୍ଚସ୍ତରରେ, ସମୟସୀମା ଅତିକ୍ରାନ୍ତ' }
};

function fill(tpl, vars) { return tpl.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : '')); }

function setupAIRoutes(router, db, aiEngine) {
  const { slaState } = require('./complaints');
  const canAccess = (u, c) => u && c && (u.role === ROLES.ADMIN || (u.role === ROLES.CITIZEN && c.citizen_id === u.id) ||
    (u.role === ROLES.DEPT && c.department_id === u.department_id) || (u.role === ROLES.FIELD && c.assigned_officer_id === u.officer_id));

  router.post('/api/ai/classify', (req, res) => {
    const text = cleanText(req.body.text, 4000);
    if (!text) return fail(res, 400, 'Describe the problem first.', 'EMPTY');
    const exclude = Array.isArray(req.body.exclude) ? req.body.exclude : [];
    const r = aiEngine.classify(text, exclude);
    ok(res, { data: { ...r, location: r.location.matched ? r.location : null, disclaimer: 'Suggestion only. The citizen confirms or changes the category.' } });
  });

  router.post('/api/ai/chat', async (req, res) => {
    const lang = ['English', 'Hindi', 'Odia'].includes(req.body.language) ? req.body.language : 'English';
    const T = L[lang];
    const msg = cleanText(req.body.message, 2000);
    const lower = msg.toLowerCase();
    const u = req.user;
    const tc = c => (CAT[lang] && CAT[lang][c]) || c;
    const ts = s => (STAT[lang] && STAT[lang][s]) || s;
    const actions = [];
    let reply;

    const idMatch = msg.match(/NS-\d{4}-\d{3,5}/i);
    const has = (...w) => w.some(x => lower.includes(x));
    if (!msg) reply = T.greeting;
    else if (idMatch) {
      const id = idMatch[0].toUpperCase();
      if (!u) reply = T.loginNeeded;
      else {
        const c = db.prepare('SELECT c.*, d.name AS dept FROM complaints c LEFT JOIN departments d ON d.id = c.department_id WHERE c.id = ?').get(id);
        if (!canAccess(u, c)) reply = fill(T.notFound, { id });
        else {
          const s = slaState(c);
          reply = fill(T.status, { id, title: c.title, status: ts(c.status), category: tc(c.category), dept: c.dept || '-',
            deadline: new Date(c.sla_deadline).toLocaleString(lang === 'Hindi' ? 'hi-IN' : lang === 'Odia' ? 'or-IN' : 'en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }),
            sla: SLA_TXT[lang][s.state] || s.state });
          if (c.status === 'Resolved') reply += ' ' + T.nextVerify;
          if (c.status === 'Disputed') reply += ' ' + T.nextDisputed;
          actions.push({ type: 'open_complaint', id });
        }
      }
    } else if (u && STAFF_ROLES.includes(u.role) && has('overdue', 'summary', 'status', 'सारांश', 'ସାରାଂଶ', 'pending')) {
      let scope = ''; const p = [];
      if (u.role === ROLES.DEPT) { scope = ' AND department_id = ?'; p.push(u.department_id); }
      if (u.role === ROLES.FIELD) { scope = ' AND assigned_officer_id = ?'; p.push(u.officer_id); }
      const rows = db.prepare(`SELECT * FROM complaints WHERE status NOT IN ('Resolved','Verified / Closed','Rejected') AND id NOT LIKE 'NS-2025-%' ${scope}`).all(...p);
      reply = fill(T.staff, { open: rows.length, overdue: rows.filter(r => slaState(r).state.includes('overdue')).length,
        review: rows.filter(r => r.status === 'Resolution Submitted').length, disputed: rows.filter(r => r.status === 'Disputed').length });
    } else if (has('my complaint', 'track', 'status', 'मेरी शिकायत', 'ट्रैक', 'स्थिति', 'ମୋ ଅଭିଯୋଗ', 'ଟ୍ରାକ', 'ସ୍ଥିତି')) {
      if (!u || u.role !== ROLES.CITIZEN) reply = T.loginNeeded;
      else {
        const rows = db.prepare('SELECT id, title, status FROM complaints WHERE citizen_id = ? ORDER BY created_at DESC').all(u.id);
        if (!rows.length) reply = T.noComplaints;
        else {
          const open = rows.filter(r => !['Verified / Closed', 'Rejected'].includes(r.status));
          reply = fill(T.myList, { n: rows.length }) + (open.length ? '\n' + open.slice(0, 6).map(r => `• ${r.id}: ${ts(r.status)}`).join('\n') : ' ' + T.allClosed);
          actions.push({ type: 'navigate', route: 'my-complaints' });
        }
      }
    } else if (has('verify', 'verification', 'dispute', 'not fixed', 'सत्यापन', 'विवाद', 'ठीक नहीं', 'ଯାଞ୍ଚ', 'ବିବାଦ')) reply = T.verify;
    else if (has('sla', 'deadline', 'how long', 'समय-सीमा', 'कितना समय', 'ସମୟସୀମା')) {
      const map = { 'dept-roads': 'Road damage / potholes', 'dept-sanitation': 'Garbage accumulation', 'dept-water': 'Water leakage', 'dept-drainage': 'Drainage blockage', 'dept-electrical': 'Streetlight failure', 'dept-publicworks': 'Damaged public infrastructure' };
      const list = db.prepare('SELECT id, sla_hours_default FROM departments').all().filter(d => map[d.id]).map(d => `${tc(map[d.id])}: ${d.sla_hours_default}h`).join(', ');
      reply = fill(T.sla, { list });
    } else if (has('community', 'nearby', 'echo', 'समुदाय', 'आसपास', 'ସମୁଦାୟ', 'ଆଖପାଖ')) {
      const rows = db.prepare("SELECT category, COUNT(*) n FROM complaints WHERE status NOT IN ('Verified / Closed','Rejected') AND id NOT LIKE 'NS-2025-%' GROUP BY category ORDER BY n DESC LIMIT 4").all();
      reply = fill(T.community, { list: rows.map(r => `${tc(r.category)} (${r.n})`).join(', ') });
      actions.push({ type: 'navigate', route: 'community-issues' });
    } else if (has('feedback', 'rate', 'प्रतिक्रिया', 'रेटिंग', 'ମତାମତ')) { reply = T.feedback; actions.push({ type: 'navigate', route: 'feedback' }); }
    else {
      const cls = aiEngine.classify(msg);
      if (cls.category && !cls.uncertain) {
        reply = fill(T.suggest, { category: tc(cls.category), evidence: cls.evidence.join(', ') });
        if (cls.missing.includes('location')) reply += ' ' + T.missingLocation;
        actions.push({ type: 'start_report', category: cls.category, text: msg });
      } else if (has('report', 'complaint', 'how', 'दर्ज', 'शिकायत', 'कैसे', 'ଦାଖଲ', 'ଅଭିଯୋଗ', 'କିପରି')) {
        reply = T.report; actions.push({ type: 'navigate', route: 'report-issue' });
      } else if (cls.category) { reply = T.suggestUncertain; actions.push({ type: 'navigate', route: 'report-issue' }); }
      else reply = T.fallback;
    }

    let source = 'rules';
    if (process.env.ANTHROPIC_API_KEY && msg) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
          body: JSON.stringify({
            model: process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5', max_tokens: 400,
            system: `You are Nagar Sarthi, a civic assistant. Reply ONLY in ${lang}. Rewrite the FACTS below into a short, friendly answer to the citizen. Never add complaint IDs, statuses, departments, officers or dates that are not in FACTS.`,
            messages: [{ role: 'user', content: `Citizen message: ${msg}\n\nFACTS:\n${reply}` }]
          }),
          signal: AbortSignal.timeout(15000)
        });
        if (r.ok) {
          const d = await r.json();
          const text = (d.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
          if (text) { reply = text; source = 'anthropic'; }
        }
      } catch (e) { /* keep rule-based reply */ }
    }
    ok(res, { reply, actions, source, sourceLabel: source === 'rules' ? T.rule : 'Anthropic Claude (facts from Nagar Sarthi records)' });
  });

  router.post('/api/ai/parse-speech', (req, res) => {
    ok(res, { data: aiEngine.parseCitizenInput(cleanText(req.body.transcript, 4000), req.body.language || 'English') });
  });

  router.post('/api/ai/resolve-landmark', (req, res) => {
    ok(res, { data: aiEngine.resolveVagueLocation(cleanText(req.body.text, 300)) });
  });

  router.get('/api/ai/city-intelligence', (req, res) => {
    if (!requireAuth(req, res, STAFF_ROLES)) return;
    ok(res, { data: aiEngine.getCityIntelligence() });
  });
}

module.exports = setupAIRoutes;
