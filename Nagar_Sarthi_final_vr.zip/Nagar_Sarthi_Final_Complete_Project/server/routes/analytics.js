// Analytics Routes — Dynamic municipal performance calculations
function setupAnalyticsRoutes(router, db) {
  router.get('/api/analytics/kpis', (req, res) => {
    try {
      const totalRow = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE id NOT LIKE 'NS-2025-%'").get();
      const activeRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE status NOT IN ('Verified / Closed', 'Resolved')`).get();
      const inProgRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE status = 'In Progress'`).get();
      const resolvedRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE status IN ('Verified / Closed', 'Resolved')`).get();
      const overdueRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE is_overdue = 1 OR status = 'Escalated'`).get();
      const highPrioRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE priority = 'High' AND status NOT IN ('Verified / Closed', 'Resolved')`).get();
      const disputedRow = db.prepare(`SELECT COUNT(*) as count FROM complaints WHERE is_disputed = 1`).get();

      // SLA Compliance calculation: (Total - Overdue) / Total * 100
      const total = totalRow.count || 1;
      const overdue = overdueRow.count || 0;
      const slaCompliance = Math.max(0, Math.round(((total - overdue) / total) * 100));

      // Calculate total citizens confirmed via CivicEcho
      const communityRow = db.prepare('SELECT SUM(community_confirmations_count) as total_confirms, SUM(affected_citizens_estimate) as total_affected FROM complaints').get();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: {
          totalComplaints: totalRow.count,
          activeComplaints: activeRow.count,
          inProgressComplaints: inProgRow.count,
          resolvedComplaints: resolvedRow.count,
          overdueComplaints: overdueRow.count,
          highPriorityComplaints: highPrioRow.count,
          disputedComplaints: disputedRow.count,
          slaCompliancePct: slaCompliance,
          avgResolutionTimeHours: null, // not fabricated: see /api/admin/departments for measured values
          totalCommunityConfirmations: communityRow.total_confirms || 0,
          totalEstimatedAffected: communityRow.total_affected || 0
        }
      }));
    } catch (err) {
      console.error('[API] /api/analytics/kpis error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

  router.get('/api/analytics/charts', (req, res) => {
    try {
      // 1. Category Distribution
      const categoryRows = db.prepare(`
        SELECT category, COUNT(*) as count
        FROM complaints
        GROUP BY category
        ORDER BY count DESC
      `).all();

      // 2. Department Workload
      const deptRows = db.prepare(`
        SELECT d.code, d.name,
               COUNT(c.id) as total,
               SUM(CASE WHEN c.status IN ('Verified / Closed', 'Resolved') THEN 1 ELSE 0 END) as resolved,
               SUM(CASE WHEN c.status NOT IN ('Verified / Closed', 'Resolved') THEN 1 ELSE 0 END) as pending,
               SUM(CASE WHEN c.is_overdue = 1 THEN 1 ELSE 0 END) as overdue
        FROM departments d
        LEFT JOIN complaints c ON d.id = c.department_id
        GROUP BY d.id
      `).all();

      // 3. Priority Distribution
      const priorityRows = db.prepare(`
        SELECT priority, COUNT(*) as count
        FROM complaints
        GROUP BY priority
      `).all();

      // 4. Locality Distribution (Top Hotspots)
      const localityRows = db.prepare(`
        SELECT locality, COUNT(*) as count,
               SUM(CASE WHEN priority = 'High' THEN 1 ELSE 0 END) as high_prio
        FROM complaints
        GROUP BY locality
        ORDER BY count DESC
        LIMIT 6
      `).all();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: {
          categories: categoryRows,
          departments: deptRows,
          priorities: priorityRows,
          localities: localityRows
        }
      }));
    } catch (err) {
      console.error('[API] /api/analytics/charts error:', err);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });
}

module.exports = setupAnalyticsRoutes;
