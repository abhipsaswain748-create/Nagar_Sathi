// Authentication & Role Management Routes
// Separate portals: citizens log in through /api/auth/citizen/login, staff through /api/auth/staff/login.
// Roles are read from the database; the browser can never choose its own role.
const {
  ROLES, STAFF_ROLES, ADMIN_ROLES, hashPassword, verifyPassword,
  createSession, sessionCookie, clearCookie, destroySession,
  tooManyAttempts, recordFailure, clearFailures
} = require('../auth');
const { ok, created, fail, requireAuth, cleanText, clientIp } = require('../http-utils');

const LANGS = ['English', 'Hindi', 'Odia'];

function publicUser(u) {
  return {
    id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role,
    department_id: u.department_id, designation: u.designation,
    preferred_language: u.preferred_language || 'English', officer_id: u.officer_id || null
  };
}

function setupAuthRoutes(router, db) {
  function login(portal) {
    return (req, res) => {
      const email = cleanText(req.body.email, 200).toLowerCase();
      const password = String(req.body.password || '');
      const key = `${clientIp(req)}|${email}`;
      if (!email || !password) return fail(res, 400, 'Enter your email and password.', 'MISSING_FIELDS');
      if (tooManyAttempts(key)) return fail(res, 429, 'Too many failed attempts. Please wait 15 minutes and try again.', 'RATE_LIMITED');

      const user = db.prepare('SELECT * FROM profiles WHERE lower(email) = ?').get(email);
      if (!user || user.is_active === 0 || !verifyPassword(password, user.password_salt, user.password_hash)) {
        recordFailure(key);
        return fail(res, 401, 'Incorrect email or password.', 'BAD_CREDENTIALS');
      }
      // Portal separation is enforced here, on the server
      if (portal === 'citizen' && user.role !== ROLES.CITIZEN) {
        return fail(res, 403, 'This is a staff account. Please use the Administrator Portal.', 'WRONG_PORTAL');
      }
      if (portal === 'staff' && !STAFF_ROLES.includes(user.role)) {
        return fail(res, 403, 'Citizen accounts cannot access the Administrator Portal.', 'WRONG_PORTAL');
      }
      clearFailures(key);
      destroySession(db, req);
      const { token, expires } = createSession(db, user.id, portal);
      const lang = LANGS.includes(req.body.language) ? req.body.language : null;
      if (lang) db.prepare('UPDATE profiles SET preferred_language = ? WHERE id = ?').run(lang, user.id);
      const off = db.prepare('SELECT id FROM officers WHERE profile_id = ?').get(user.id);
      res.setHeader('Set-Cookie', sessionCookie(token, expires, req));
      ok(res, { user: publicUser({ ...user, preferred_language: lang || user.preferred_language, officer_id: off ? off.id : null }) });
    };
  }

  router.post('/api/auth/citizen/login', login('citizen'));
  router.post('/api/auth/staff/login', login('staff'));

  // Citizen self-registration (staff accounts are created by administrators only)
  router.post('/api/auth/citizen/register', (req, res) => {
    const name = cleanText(req.body.name, 120);
    const email = cleanText(req.body.email, 200).toLowerCase();
    const phone = cleanText(req.body.phone, 20);
    const password = String(req.body.password || '');
    if (!name || !email || !password) return fail(res, 400, 'Name, email and password are required.', 'MISSING_FIELDS');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail(res, 400, 'Enter a valid email address.', 'BAD_EMAIL');
    if (password.length < 8 || !/[0-9]/.test(password) || !/[A-Za-z]/.test(password)) {
      return fail(res, 400, 'Password must be at least 8 characters and contain letters and numbers.', 'WEAK_PASSWORD');
    }
    if (db.prepare('SELECT id FROM profiles WHERE lower(email) = ?').get(email)) {
      return fail(res, 409, 'An account with this email already exists.', 'EMAIL_TAKEN');
    }
    const id = `user-cit-${Date.now().toString(36)}`;
    const { salt, hash } = hashPassword(password);
    const lang = LANGS.includes(req.body.language) ? req.body.language : 'English';
    db.prepare(`INSERT INTO profiles (id, name, email, phone, role, department_id, designation, avatar, created_at, password_salt, password_hash, preferred_language, is_active)
      VALUES (?, ?, ?, ?, 'citizen', NULL, 'Citizen', NULL, ?, ?, ?, ?, 1)`)
      .run(id, name, email, phone || null, new Date().toISOString(), salt, hash, lang);
    const { token, expires } = createSession(db, id, 'citizen');
    res.setHeader('Set-Cookie', sessionCookie(token, expires, req));
    created(res, { user: publicUser({ id, name, email, phone, role: 'citizen', preferred_language: lang }) });
  });

  router.post('/api/auth/logout', (req, res) => {
    destroySession(db, req);
    res.setHeader('Set-Cookie', clearCookie());
    ok(res, { message: 'Logged out' });
  });

  router.get('/api/auth/me', (req, res) => {
    ok(res, { user: req.user ? publicUser(req.user) : null });
  });

  router.patch('/api/auth/preferences', (req, res) => {
    if (!requireAuth(req, res)) return;
    const lang = req.body.preferred_language;
    if (!LANGS.includes(lang)) return fail(res, 400, 'Unsupported language.', 'BAD_LANGUAGE');
    db.prepare('UPDATE profiles SET preferred_language = ? WHERE id = ?').run(lang, req.user.id);
    ok(res, { preferred_language: lang });
  });

  router.post('/api/auth/change-password', (req, res) => {
    if (!requireAuth(req, res)) return;
    const u = db.prepare('SELECT * FROM profiles WHERE id = ?').get(req.user.id);
    if (!verifyPassword(String(req.body.current_password || ''), u.password_salt, u.password_hash)) {
      return fail(res, 401, 'Current password is incorrect.', 'BAD_CREDENTIALS');
    }
    const np = String(req.body.new_password || '');
    if (np.length < 8 || !/[0-9]/.test(np) || !/[A-Za-z]/.test(np)) return fail(res, 400, 'Password must be at least 8 characters and contain letters and numbers.', 'WEAK_PASSWORD');
    const { salt, hash } = hashPassword(np);
    db.prepare('UPDATE profiles SET password_salt = ?, password_hash = ? WHERE id = ?').run(salt, hash, u.id);
    ok(res, { message: 'Password updated' });
  });

  // Reference data: departments are public (shown on forms); officer roster is staff-only
  router.get('/api/departments', (req, res) => {
    ok(res, { data: db.prepare('SELECT id, name, code, description, sla_hours_default, active_head, phone FROM departments').all() });
  });

  router.get('/api/officers', (req, res) => {
    if (!requireAuth(req, res, ADMIN_ROLES)) return;
    const rows = db.prepare(`
      SELECT o.*, d.name as department_name, d.code as department_code,
        (SELECT COUNT(*) FROM complaints c WHERE c.assigned_officer_id = o.id AND c.status IN ('Assigned','In Progress','Reopened','Disputed','Escalated')) AS open_tasks
      FROM officers o LEFT JOIN departments d ON o.department_id = d.id
    `).all();
    ok(res, { data: rows });
  });
}

module.exports = setupAuthRoutes;
