// Weather-synchronised civic risk
// Live forecast: Open-Meteo forecast API (no key; free for non-commercial use, attribution required).
// Risk = forecast rainfall at or above a configurable threshold + localities with recurring
// waterlogging/drainage complaints in Nagar Sarthi records. It is an estimate, not a prediction of certainty.
const { STAFF_ROLES } = require('../auth');
const { ok, fail, requireAuth, newId, cleanText } = require('../http-utils');

const LAT = Number(process.env.DEFAULT_LATITUDE || 20.2961);
const LON = Number(process.env.DEFAULT_LONGITUDE || 85.8245);
const RAIN_MM = Number(process.env.RAIN_RISK_THRESHOLD_MM || 20);
let cache = null;

async function fetchForecast() {
  if (process.env.WEATHER_DISABLED === 'true') throw new Error('Weather integration disabled by configuration');
  if (cache && Date.now() - cache.at < 30 * 60e3) return cache.data;
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,precipitation,weather_code&daily=precipitation_sum,precipitation_probability_max,temperature_2m_max&timezone=Asia%2FKolkata&forecast_days=3`;
  const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new Error(`Open-Meteo HTTP ${r.status}`);
  const d = await r.json();
  if (!d.daily || !Array.isArray(d.daily.time)) throw new Error('Unexpected Open-Meteo response');
  const data = {
    retrieved_at: new Date().toISOString(),
    current: d.current ? { temperature_c: d.current.temperature_2m, precipitation_mm: d.current.precipitation, time: d.current.time } : null,
    daily: d.daily.time.map((t, i) => ({ date: t, precipitation_mm: d.daily.precipitation_sum[i], precipitation_probability_pct: d.daily.precipitation_probability_max ? d.daily.precipitation_probability_max[i] : null, max_temp_c: d.daily.temperature_2m_max[i] }))
  };
  cache = { at: Date.now(), data };
  return data;
}

function setupWeatherRoutes(router, db) {
  router.get('/api/weather/risk', async (req, res) => {
    const yearAgo = new Date(Date.now() - 365 * 24 * 3600e3).toISOString();
    const recurring = db.prepare(`SELECT locality, ward_no, COUNT(*) AS n, MAX(created_at) AS last, MAX(is_demo) AS is_demo FROM complaints
      WHERE category IN ('Waterlogging / flooding','Drainage blockage') AND created_at >= ? GROUP BY locality, ward_no HAVING n >= 2 ORDER BY n DESC`).all(yearAgo);
    let forecast = null; let error = null;
    try { forecast = await fetchForecast(); } catch (e) { error = e.message; }
    const alerts = [];
    if (forecast) {
      const wet = forecast.daily.filter(d => d.precipitation_mm !== null && d.precipitation_mm >= RAIN_MM);
      if (wet.length) {
        for (const loc of recurring) {
          alerts.push({
            locality: loc.locality, ward_no: loc.ward_no, complaints_12m: loc.n, last_complaint: loc.last, is_demo: !!loc.is_demo,
            forecast_dates: wet.map(d => d.date), max_forecast_mm: Math.max(...wet.map(d => d.precipitation_mm)),
            level: loc.n >= 3 ? 'elevated' : 'watch',
            reason: `Rainfall of ${Math.max(...wet.map(d => d.precipitation_mm))} mm/day is forecast and this locality had ${loc.n} waterlogging/drainage complaints in the last 12 months. A preventive drainage inspection is recommended.`
          });
        }
      }
    }
    ok(res, { data: {
      available: !!forecast, error, source: 'Open-Meteo forecast API (open-meteo.com), CC BY 4.0',
      location: { latitude: LAT, longitude: LON, label: process.env.CITY_NAME || 'City centre' },
      threshold_mm: RAIN_MM, forecast, recurring_localities: recurring, alerts,
      disclaimer: 'Risk flags are estimates combining a weather forecast with past complaint records. They are not certain predictions.'
    } });
  });

  // Manually published advisories (staff only). Seeded advisories are labelled "(demo)".
  router.get('/api/weather/alerts', (req, res) => {
    const rows = db.prepare('SELECT * FROM weather_alerts WHERE active = 1 ORDER BY created_at DESC').all()
      .map(r => ({ ...r, affected_localities: (() => { try { return JSON.parse(r.affected_localities); } catch (e) { return []; } })() }));
    ok(res, { count: rows.length, data: rows });
  });

  router.post('/api/weather/alerts', (req, res) => {
    if (!requireAuth(req, res, STAFF_ROLES.filter(r => r !== 'field_officer'))) return;
    const b = req.body;
    const title = cleanText(b.title, 200);
    if (!title) return fail(res, 400, 'Title is required.');
    db.prepare(`INSERT INTO weather_alerts (id, title, severity, condition, precipitation_forecast_mm, affected_localities, infrastructure_risk, predicted_impact, preventive_advisory, active, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`).run(newId('WX'), title, ['CRITICAL', 'WARNING', 'ADVISORY'].includes(b.severity) ? b.severity : 'ADVISORY',
      cleanText(b.condition, 200) || '-', Number(b.precipitation_forecast_mm) || 0, JSON.stringify(Array.isArray(b.affected_localities) ? b.affected_localities.slice(0, 20) : []),
      cleanText(b.infrastructure_risk, 300) || '-', cleanText(b.predicted_impact, 300) || '-', cleanText(b.preventive_advisory, 500) || '-', new Date().toISOString());
    ok(res, { message: 'Advisory published' });
  });
}

module.exports = setupWeatherRoutes;
