// Citizen feedback: linked to real complaints, with ratings, evidence and administrative responses
const { ROLES, ADMIN_ROLES } = require('../auth');
const { ok, created, fail, requireAuth, query, newId, cleanText } = require('../http-utils');

const TYPES = ['resolution', 'service', 'platform', 'suggestion', 'repeated_issue', 'incomplete_work'];
const STATUSES = ['New', 'Under Review', 'Responded', 'Action Taken', 'Closed'];

function setupFeedbackRoutes(router, db) {
  const rating = v => { const n = Number(v); return Number.isInteger(n) && n >= 1 && n <= 5 ? n : null; };

  router.post('/api/feedback', (req, res) => {
    if (!requireAuth(req, res, [ROLES.CITIZEN])) return;
    const b = req.body; const u = req.user;
    const type = TYPES.includes(b.feedback_type) ? b.feedback_type : 'platform';
    const message = cleanText(b.message, 2000);
    const overall = rating(b.rating);
    if (!overall) return fail(res, 400, 'Give an overall rating from 1 to 5.', 'RATING_REQUIRED');
    if (!message) return fail(res, 400, 'Write a short comment.', 'MESSAGE_REQUIRED');
    let complaint = null;
    if (b.complaint_id) {
      complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(b.complaint_id);
      if (!complaint || complaint.citizen_id !== u.id) return fail(res, 403, 'You can only give feedback on your own complaints.');
      if (db.prepare('SELECT 1 FROM citizen_feedback WHERE complaint_id = ? AND citizen_id = ? AND feedback_type = ?').get(complaint.id, u.id, type)) {
        return fail(res, 409, 'You already submitted this feedback for this complaint.', 'DUPLICATE');
      }
    }
    if (['resolution', 'incomplete_work'].includes(type) && !complaint) return fail(res, 400, 'Choose the complaint this feedback is about.', 'COMPLAINT_REQUIRED');
    let mediaId = null;
    if (b.media_id) {
      const m = db.prepare('SELECT id FROM media WHERE id = ? AND owner_id = ?').get(b.media_id, u.id);
      if (m) mediaId = m.id;
    }
    const id = newId('FB'); const t = new Date().toISOString();
    db.prepare(`INSERT INTO citizen_feedback (id, citizen_id, citizen_name, citizen_email, complaint_id, feedback_type, rating, message, attachment_url, status, admin_response, created_at, updated_at,
      resolution_rating, department_rating, work_satisfactory, incomplete_work, repeated_issue, department_id, improvement_suggestion, attachment_media_id)
      VALUES (?,?,?,?,?,?,?,?,?, 'New', NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(id, u.id, u.name, u.email, complaint ? complaint.id : null, type, overall, message, mediaId ? `/api/media/${mediaId}` : null, t, t,
        rating(b.resolution_rating), rating(b.department_rating), ['yes', 'partly', 'no'].includes(b.work_satisfactory) ? b.work_satisfactory : null,
        b.incomplete_work || type === 'incomplete_work' ? 1 : 0, b.repeated_issue || type === 'repeated_issue' ? 1 : 0,
        complaint ? complaint.department_id : null, cleanText(b.improvement_suggestion, 1000) || null, mediaId);
    if (mediaId && complaint) db.prepare('UPDATE media SET complaint_id = ? WHERE id = ?').run(complaint.id, mediaId);
    db.prepare(`INSERT INTO notifications (id, user_id, target_role, title, message, complaint_id, type, is_read, created_at) VALUES (?, NULL, 'admin', ?, ?, ?, 'feedback', 0, ?)`)
      .run(newId('NOTIF'), `New feedback (${overall}/5)${complaint ? ` on ${complaint.id}` : ''}`, message.slice(0, 160), complaint ? complaint.id : null, t);
    created(res, { feedbackId: id });
  });

  router.get('/api/feedback', (req, res) => {
    if (!requireAuth(req, res)) return;
    const q = query(req); const u = req.user;
    let sql = `SELECT f.*, d.name AS department_name, c.title AS complaint_title, c.status AS complaint_status
      FROM citizen_feedback f LEFT JOIN departments d ON d.id = f.department_id LEFT JOIN complaints c ON c.id = f.complaint_id WHERE 1=1`;
    const p = [];
    if (u.role === ROLES.CITIZEN) { sql += ' AND f.citizen_id = ?'; p.push(u.id); }
    else if (u.role === ROLES.DEPT) { sql += ' AND f.department_id = ?'; p.push(u.department_id); }
    else if (u.role !== ROLES.ADMIN) return fail(res, 403, 'You do not have permission for this action.');
    for (const [k, col] of [['department_id', 'f.department_id'], ['complaint_id', 'f.complaint_id'], ['status', 'f.status'], ['feedback_type', 'f.feedback_type']]) {
      const v = q.get(k); if (v && v !== 'all') { sql += ` AND ${col} = ?`; p.push(v); }
    }
    const maxRating = q.get('max_rating');
    if (maxRating) { sql += ' AND f.rating <= ?'; p.push(Number(maxRating)); }
    sql += ' ORDER BY f.created_at DESC LIMIT 300';
    const rows = db.prepare(sql).all(...p).map(r => ({ ...r, attachment_url: r.attachment_media_id ? `/api/media/${r.attachment_media_id}` : (r.attachment_url && r.attachment_url.startsWith('http') ? r.attachment_url : null) }));
    let pending = [];
    if (u.role === ROLES.CITIZEN) {
      pending = db.prepare(`SELECT id, title, status, category, updated_at FROM complaints WHERE citizen_id = ? AND status IN ('Resolved','Verified / Closed','Disputed')
        AND id NOT IN (SELECT complaint_id FROM citizen_feedback WHERE citizen_id = ? AND complaint_id IS NOT NULL) ORDER BY updated_at DESC`).all(u.id, u.id);
    }
    const stats = {
      total: rows.length,
      average: rows.length ? Math.round(rows.reduce((a, r) => a + r.rating, 0) / rows.length * 10) / 10 : null,
      low: rows.filter(r => r.rating <= 2).length,
      awaiting: rows.filter(r => ['New', 'Under Review'].includes(r.status)).length
    };
    ok(res, { data: rows, pending, stats });
  });

  router.patch('/api/feedback/:id', (req, res, params) => {
    if (!requireAuth(req, res, ADMIN_ROLES)) return;
    const f = db.prepare('SELECT * FROM citizen_feedback WHERE id = ?').get(params.id);
    if (!f) return fail(res, 404, 'Feedback not found.');
    if (req.user.role === ROLES.DEPT && f.department_id !== req.user.department_id) return fail(res, 403, 'You do not have permission for this action.');
    const status = STATUSES.includes(req.body.status) ? req.body.status : f.status;
    const response = req.body.admin_response !== undefined ? cleanText(req.body.admin_response, 1500) : f.admin_response;
    const actionTaken = req.body.action_taken !== undefined ? cleanText(req.body.action_taken, 1500) : f.action_taken;
    const t = new Date().toISOString();
    db.prepare('UPDATE citizen_feedback SET status = ?, admin_response = ?, action_taken = ?, updated_at = ? WHERE id = ?').run(status, response, actionTaken, t, f.id);
    if (response && response !== f.admin_response) {
      db.prepare(`INSERT INTO notifications (id, user_id, target_role, title, message, complaint_id, type, is_read, created_at) VALUES (?, ?, 'citizen', ?, ?, ?, 'feedback_response', 0, ?)`)
        .run(newId('NOTIF'), f.citizen_id, 'Official response to your feedback', response.slice(0, 200), f.complaint_id, t);
    }
    ok(res, { message: 'Feedback updated' });
  });
}

module.exports = setupFeedbackRoutes;
