// Complaints Routes — full lifecycle with server-side access control
// Citizen reports → AI/Manual category → admin review/assignment → field evidence →
// resolution → citizen verification or dispute → reopen → feedback
const crypto = require('node:crypto');
const { ROLES, STAFF_ROLES, ADMIN_ROLES } = require('../auth');
const { ok, created, fail, requireAuth, query, newId, hashSig, clientIp, cleanText } = require('../http-utils');
const { CATEGORY_DEPARTMENT } = require('../seed-extra');

const CATEGORIES = Object.keys(CATEGORY_DEPARTMENT);
const STATUSES = ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolution Submitted', 'Resolved',
  'Verified / Closed', 'Disputed', 'Reopened', 'Escalated', 'Rejected'];
const OPEN_STATUSES = ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolution Submitted', 'Disputed', 'Reopened', 'Escalated'];
const CLOSED_STATUSES = ['Resolved', 'Verified / Closed', 'Rejected'];
const EVIDENCE_TYPES = ['inspection', 'progress', 'completion'];

function canAccess(user, c) {
  if (!user || !c) return false;
  if (user.role === ROLES.ADMIN) return true;
  if (user.role === ROLES.CITIZEN) return c.citizen_id === user.id;
  if (user.role === ROLES.DEPT) return c.department_id === user.department_id;
  if (user.role === ROLES.FIELD) return !!user.officer_id && c.assigned_officer_id === user.officer_id;
  return false;
}

function slaState(c, now = Date.now()) {
  const deadline = new Date(c.sla_deadline).getTime();
  if (CLOSED_STATUSES.includes(c.status)) {
    const done = c.resolved_at ? new Date(c.resolved_at).getTime() : null;
    return { state: done && done <= deadline ? 'met' : (done ? 'breached_closed' : 'closed'), hoursLeft: null };
  }
  const hoursLeft = (deadline - now) / 3600e3;
  if (c.status === 'Escalated' || c.escalated_at) return { state: hoursLeft < 0 ? 'escalated_overdue' : 'escalated', hoursLeft };
  if (hoursLeft < 0) return { state: 'overdue', hoursLeft };
  const today = new Date(now + 5.5 * 3600e3).toISOString().slice(0, 10); // IST calendar day
  const dueDay = new Date(deadline + 5.5 * 3600e3).toISOString().slice(0, 10);
  if (dueDay === today) return { state: 'due_today', hoursLeft };
  if (hoursLeft <= 24) return { state: 'approaching', hoursLeft };
  return { state: 'on_track', hoursLeft };
}

function mediaUrl(a) {
  return a.media_id ? `/api/media/${a.media_id}` : a.file_url;
}

function setupComplaintsRoutes(router, db, aiEngine) {
  const now = () => new Date().toISOString();

  function notify(userId, role, title, message, complaintId, type) {
    db.prepare(`INSERT INTO notifications (id, user_id, target_role, title, message, complaint_id, type, is_read, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`).run(newId('NOTIF'), userId || null, role, title, message, complaintId, type, now());
  }
  function notifyStaff(c, title, message, type) {
    notify(null, 'admin', title, message, c.id, type);
    if (c.department_id) {
      db.prepare("SELECT id FROM profiles WHERE role = 'dept_officer' AND department_id = ?").all(c.department_id)
        .forEach(p => notify(p.id, 'dept_officer', title, message, c.id, type));
    }
  }
  function notifyFieldOfficer(officerId, title, message, cid, type) {
    const o = officerId && db.prepare('SELECT profile_id FROM officers WHERE id = ?').get(officerId);
    if (o && o.profile_id) notify(o.profile_id, 'field_officer', title, message, cid, type);
  }
  function history(cid, from, to, notes, user) {
    db.prepare(`INSERT INTO complaint_status_history (id, complaint_id, from_status, to_status, notes, actor_name, actor_role, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(newId('SH'), cid, from, to, notes, user.name, user.role, now());
  }
  function action(cid, type, details, user, visible = 1) {
    db.prepare(`INSERT INTO complaint_actions (id, complaint_id, action_type, details, visible_to_citizen, actor_id, actor_name, actor_role, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(newId('ACT'), cid, type, details || '', visible ? 1 : 0, user.id, user.name, user.role, now());
  }
  function audit(cid, type, text, details, user, req) {
    const t = now();
    db.prepare(`INSERT INTO audit_logs (id, event_type, complaint_id, actor_id, actor_name, actor_role, action, details, ip_address, hash_signature, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(newId('AUDIT'), type, cid, user.id, user.name, user.role, text, details || '', clientIp(req), hashSig(`${cid}-${type}-${t}-${user.id}`), t);
  }
  function setStatus(c, to, notes, user, req, extraSql = '', extraParams = []) {
    db.prepare(`UPDATE complaints SET status = ?, updated_at = ? ${extraSql} WHERE id = ?`).run(to, now(), ...extraParams, c.id);
    history(c.id, c.status, to, notes, user);
    audit(c.id, 'STATUS_CHANGE', `Changed status from "${c.status}" to "${to}"`, notes, user, req);
  }
  function load(id) {
    return db.prepare('SELECT * FROM complaints WHERE id = ? OR tracking_number = ?').get(id, id);
  }
  function guard(req, res, id, roles) {
    if (!requireAuth(req, res, roles)) return null;
    const c = load(id);
    if (!c) { fail(res, 404, 'Complaint not found.'); return null; }
    if (!canAccess(req.user, c)) { fail(res, 403, 'You do not have access to this complaint.'); return null; }
    return c;
  }
  function linkMedia(c, mediaIds, evidenceType, user, isPublic = 0, caption = '') {
    const ids = Array.isArray(mediaIds) ? mediaIds.slice(0, 6) : [];
    let n = 0;
    for (const mid of ids) {
      const m = db.prepare('SELECT * FROM media WHERE id = ? AND owner_id = ?').get(mid, user.id);
      if (!m) continue;
      if (db.prepare('SELECT 1 FROM complaint_attachments WHERE media_id = ?').get(mid)) continue;
      db.prepare(`INSERT INTO complaint_attachments (id, complaint_id, file_url, file_type, caption, is_resolution_proof, uploaded_by, created_at,
        evidence_type, uploaded_by_name, uploaded_by_role, status_at_upload, media_id, is_public, is_demo)
        VALUES (?, ?, ?, 'image', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)`)
        .run(newId('ATT'), c.id, `/api/media/${mid}`, caption, evidenceType === 'completion' ? 1 : 0, user.id, now(),
          evidenceType, user.name, user.role, c.status, mid, isPublic ? 1 : 0);
      db.prepare('UPDATE media SET complaint_id = ? WHERE id = ?').run(c.id, mid);
      n++;
    }
    return n;
  }
  function decorate(r) {
    const sla = slaState(r);
    return {
      ...r,
      priority_reasons: (() => { try { return r.priority_reasons ? JSON.parse(r.priority_reasons) : []; } catch (e) { return []; } })(),
      sla_state: sla.state,
      sla_hours_left: sla.hoursLeft === null ? null : Math.round(sla.hoursLeft * 10) / 10,
      is_overdue: ['overdue', 'escalated_overdue'].includes(sla.state) ? 1 : 0
    };
  }

  // ---------- LIST (role-scoped)
  router.get('/api/complaints', (req, res) => {
    if (!requireAuth(req, res)) return;
    const q = query(req);
    let sql = `SELECT c.*, d.name as department_name, d.code as department_code, o.name as officer_name,
      (SELECT COUNT(*) FROM complaint_attachments a WHERE a.complaint_id = c.id) AS attachment_count,
      (SELECT a.media_id FROM complaint_attachments a WHERE a.complaint_id = c.id AND a.evidence_type = 'complaint' LIMIT 1) AS first_media_id,
      (SELECT a.file_url FROM complaint_attachments a WHERE a.complaint_id = c.id AND a.evidence_type = 'complaint' LIMIT 1) AS first_photo_url
      FROM complaints c LEFT JOIN departments d ON c.department_id = d.id LEFT JOIN officers o ON c.assigned_officer_id = o.id WHERE 1=1`;
    const p = [];
    const u = req.user;
    if (u.role === ROLES.CITIZEN) { sql += ' AND c.citizen_id = ?'; p.push(u.id); }
    else if (u.role === ROLES.DEPT) { sql += ' AND c.department_id = ?'; p.push(u.department_id); }
    else if (u.role === ROLES.FIELD) { sql += ' AND c.assigned_officer_id = ?'; p.push(u.officer_id || '__none__'); }

    const eq = { category: 'c.category', status: 'c.status', priority: 'c.priority', locality: 'c.locality', department_id: 'c.department_id', assigned_officer_id: 'c.assigned_officer_id' };
    for (const [k, col] of Object.entries(eq)) {
      const v = q.get(k);
      if (v && v !== 'all') { sql += ` AND ${col} = ?`; p.push(v); }
    }
    const from = q.get('from'); const to = q.get('to');
    if (from) { sql += ' AND c.created_at >= ?'; p.push(new Date(from).toISOString()); }
    if (to) { sql += ' AND c.created_at <= ?'; p.push(new Date(new Date(to).getTime() + 86399e3).toISOString()); }
    const search = q.get('search');
    if (search) {
      sql += ' AND (c.id LIKE ? OR c.title LIKE ? OR c.description LIKE ? OR c.landmark LIKE ? OR c.locality LIKE ?)';
      const s = `%${search}%`; p.push(s, s, s, s, s);
    }
    if (q.get('include_history') !== 'true') sql += " AND c.id NOT LIKE 'NS-2025-%'";
    sql += ' ORDER BY c.created_at DESC LIMIT 500';
    let rows = db.prepare(sql).all(...p).map(decorate).map(r => ({
      ...r,
      thumbnail_url: r.first_media_id ? `/api/media/${r.first_media_id}` : (r.first_photo_url || null),
      citizen_phone: u.role === ROLES.CITIZEN || u.role === ROLES.ADMIN || u.role === ROLES.DEPT ? r.citizen_phone : null
    }));
    const sla = q.get('sla');
    if (sla && sla !== 'all') rows = rows.filter(r => sla === 'escalated' ? r.sla_state.startsWith('escalated') : r.sla_state === sla);
    if (q.get('overdue') === 'true') rows = rows.filter(r => r.is_overdue);
    ok(res, { count: rows.length, data: rows });
  });

  // ---------- PUBLIC MAP (privacy-projected, no personal data, only photos the citizen allowed to be public)
  router.get('/api/complaints-public-map', (req, res) => {
    const q = query(req);
    let sql = `SELECT c.id, c.title, c.category, c.description, c.priority, c.status, c.locality, c.ward_no,
      c.latitude, c.longitude, c.community_confirmations_count, c.parent_incident_id, c.created_at, c.updated_at, c.is_demo,
      d.name as department_name,
      (SELECT COUNT(*) FROM complaints k WHERE k.parent_incident_id = c.id) AS linked_reports,
      (SELECT COUNT(*) FROM complaints h WHERE h.category = c.category AND h.id != c.id
         AND abs(h.latitude - c.latitude) < 0.0025 AND abs(h.longitude - c.longitude) < 0.0025) AS nearby_same_category
      FROM complaints c LEFT JOIN departments d ON c.department_id = d.id
      WHERE c.latitude IS NOT NULL AND c.status != 'Rejected' AND c.id NOT LIKE 'NS-2025-%'`;
    const p = [];
    for (const k of ['category', 'status', 'priority', 'locality']) {
      const v = q.get(k);
      if (v && v !== 'all') { sql += ` AND c.${k} = ?`; p.push(v); }
    }
    const from = q.get('from');
    if (from) { sql += ' AND c.created_at >= ?'; p.push(new Date(from).toISOString()); }
    const search = q.get('search');
    if (search) { sql += ' AND (c.title LIKE ? OR c.locality LIKE ? OR c.id LIKE ?)'; const s = `%${search}%`; p.push(s, s, s); }
    sql += ' ORDER BY c.created_at DESC LIMIT 300';
    const rows = db.prepare(sql).all(...p).map(r => {
      const h = parseInt(crypto.createHash('md5').update(r.id).digest('hex').substring(0, 6), 16);
      const photo = db.prepare("SELECT media_id, file_url FROM complaint_attachments WHERE complaint_id = ? AND is_public = 1 AND evidence_type = 'complaint' LIMIT 1").get(r.id);
      return {
        ...r,
        latitude: +(r.latitude + ((h % 100) - 50) * 0.000015).toFixed(4),
        longitude: +(r.longitude + (((h >> 4) % 100) - 50) * 0.000015).toFixed(4),
        related_reports: (r.community_confirmations_count || 1) + r.linked_reports,
        public_photo_url: photo ? (photo.media_id ? `/api/media/${photo.media_id}` : photo.file_url) : null,
        privacy_protected: true
      };
    });
    ok(res, { count: rows.length, data: rows, meta: { coordinate_precision: 'approx. 100 m offset applied for privacy' } });
  });

  // ---------- DETAIL
  router.get('/api/complaints/:id', (req, res, params) => {
    const c = guard(req, res, params.id);
    if (!c) return;
    const isCitizen = req.user.role === ROLES.CITIZEN;
    const full = db.prepare(`SELECT c.*, d.name as department_name, d.code as department_code, o.name as officer_name, o.phone as officer_phone,
      i.name as infrastructure_name, i.health_index as infrastructure_health
      FROM complaints c LEFT JOIN departments d ON c.department_id = d.id LEFT JOIN officers o ON c.assigned_officer_id = o.id
      LEFT JOIN infrastructure_entities i ON c.infrastructure_asset_id = i.id WHERE c.id = ?`).get(c.id);
    const attachments = db.prepare('SELECT * FROM complaint_attachments WHERE complaint_id = ? ORDER BY created_at ASC').all(c.id)
      .map(a => ({ ...a, url: mediaUrl(a), evidence_type: a.evidence_type || (a.is_resolution_proof ? 'completion' : 'complaint') }));
    const timeline = db.prepare('SELECT * FROM complaint_status_history WHERE complaint_id = ? ORDER BY created_at ASC').all(c.id);
    const actions = db.prepare(`SELECT * FROM complaint_actions WHERE complaint_id = ? ${isCitizen ? 'AND visible_to_citizen = 1' : ''} ORDER BY created_at ASC`).all(c.id);
    const confirmations = db.prepare('SELECT id, confirmation_type, created_at FROM community_confirmations WHERE complaint_id = ?').all(c.id);
    const feedback = db.prepare('SELECT id, rating, resolution_rating, department_rating, status, created_at FROM citizen_feedback WHERE complaint_id = ?').all(c.id);
    const data = { ...decorate(full), attachments, timeline, actions, confirmations, feedback,
      can_verify: isCitizen && c.citizen_id === req.user.id && c.status === 'Resolved',
      can_give_feedback: isCitizen && ['Resolved', 'Verified / Closed', 'Disputed'].includes(c.status) };
    if (!isCitizen) {
      data.audits = db.prepare('SELECT * FROM audit_logs WHERE complaint_id = ? ORDER BY created_at DESC').all(c.id);
      data.ai = db.prepare('SELECT * FROM ai_recommendations WHERE complaint_id = ?').all(c.id);
      data.infraHistory = c.infrastructure_asset_id ? db.prepare('SELECT * FROM infrastructure_history WHERE infrastructure_id = ?').all(c.infrastructure_asset_id) : [];
    }
    ok(res, { data });
  });

  // ---------- CREATE (citizen)
  router.post('/api/complaints', (req, res) => {
    if (!requireAuth(req, res, [ROLES.CITIZEN])) return;
    const b = req.body; const u = req.user;
    const description = cleanText(b.description, 4000);
    let title = cleanText(b.title, 200);
    const category = b.category;
    if (!description && !title) return fail(res, 400, 'Describe the problem before submitting.', 'MISSING_DESCRIPTION');
    if (!CATEGORIES.includes(category)) return fail(res, 400, 'Select a valid civic issue domain.', 'BAD_CATEGORY');
    const lat = Number(b.latitude); const lon = Number(b.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
      return fail(res, 400, 'Choose the location of the problem on the map or by landmark.', 'BAD_LOCATION');
    }
    const ai = aiEngine.parseCitizenInput(`${title} ${description} ${b.landmark || ''}`, b.original_language || 'English');
    if (!title) title = (ai.title || description.slice(0, 80)).slice(0, 200);
    const deptId = CATEGORY_DEPARTMENT[category];
    const dept = db.prepare('SELECT sla_hours_default FROM departments WHERE id = ?').get(deptId);
    const slaHours = dept ? dept.sla_hours_default : 48;
    const t = now();
    const maxRow = db.prepare("SELECT MAX(CAST(substr(id, 9) AS INTEGER)) AS m FROM complaints WHERE id LIKE 'NS-2026-%'").get();
    const id = `NS-${new Date().getFullYear()}-${Math.max(1200, (maxRow.m || 0) + 1)}`;
    const source = ['manual', 'ai', 'ai_overridden'].includes(b.category_source) ? b.category_source : 'manual';
    let parent = null;
    const dupes = aiEngine.findPotentialDuplicates(lat, lon, category);
    if (dupes.length && dupes[0].similarityScore >= 80) parent = dupes[0].existingComplaintId;
    const asset = db.prepare('SELECT id FROM infrastructure_entities WHERE abs(latitude - ?) < 0.005 AND abs(longitude - ?) < 0.005 LIMIT 1').get(lat, lon);

    db.prepare(`INSERT INTO complaints (id, tracking_number, citizen_id, citizen_name, citizen_phone, category, subcategory, title, description,
      original_language, transcription, latitude, longitude, location_address, landmark, locality, ward_no, location_confidence, status,
      priority, priority_score, priority_reasons, department_id, assigned_officer_id, sla_deadline, sla_hours, is_overdue,
      parent_incident_id, community_confirmations_count, affected_citizens_estimate, infrastructure_asset_id, is_disputed,
      is_demo, category_source, ai_suggested_category, ai_confidence, created_at, updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Submitted', ?,?,?,?, NULL, ?, ?, 0, ?, 1, ?, ?, 0, 0, ?, ?, ?, ?, ?)`)
      .run(id, id, u.id, u.name, u.phone || null, category, cleanText(b.subcategory, 120) || null, title, description || title,
        ['English', 'Hindi', 'Odia'].includes(b.original_language) ? b.original_language : 'English', cleanText(b.transcription, 4000) || null,
        lat, lon, cleanText(b.location_address, 300) || `${lat.toFixed(5)}, ${lon.toFixed(5)}`, cleanText(b.landmark, 200) || null,
        cleanText(b.locality, 120) || ai.location.locality || 'Unspecified', Number(b.ward_no) || ai.location.ward || 0,
        Math.min(1, Math.max(0, Number(b.location_confidence) || 0.8)),
        ai.priority, ai.priorityScore, JSON.stringify(ai.priorityReasons || []), deptId,
        new Date(Date.now() + slaHours * 3600e3).toISOString(), slaHours, parent, Number(b.affected_citizens_estimate) || 1,
        asset ? asset.id : null, source, CATEGORIES.includes(b.ai_suggested_category) ? b.ai_suggested_category : null,
        Number.isFinite(Number(b.ai_confidence)) ? Number(b.ai_confidence) : null, t, t);
    const c = load(id);
    if (b.ai_suggested_category) {
      db.prepare(`INSERT INTO ai_recommendations (id, complaint_id, recommended_category, recommended_department, recommended_priority, confidence_score, explanation, urgency_detected, overridden_by, override_reason, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(newId('AIR'), id, b.ai_suggested_category, CATEGORY_DEPARTMENT[b.ai_suggested_category] || null,
        ai.priority, Number(b.ai_confidence) || null, 'Category suggested by Nagar Sarthi AI and shown to the citizen before submission.',
        ai.priority === 'High' ? 1 : 0, source === 'ai_overridden' ? u.id : null, source === 'ai_overridden' ? 'Citizen changed the suggested category' : null, t);
    }
    const photos = linkMedia(c, b.media_ids, 'complaint', u, b.photos_public ? 1 : 0, 'Citizen complaint photo');
    history(id, null, 'Submitted', `Complaint submitted by citizen. Category: ${category} (${source === 'manual' ? 'selected by citizen' : source === 'ai' ? 'AI suggestion accepted' : 'AI suggestion changed by citizen'}).`, u);
    audit(id, 'COMPLAINT_REGISTERED', `Registered complaint "${title}"`, `Category: ${category} | Photos: ${photos}`, u, req);
    notify(u.id, 'citizen', `Complaint ${id} submitted`, `We received your report "${title}". You can track it under Track Progress.`, id, 'submission');
    notifyStaff(c, `New complaint ${id}`, `${category} in ${c.locality}: ${title}`, 'submission');
    created(res, { complaintId: id, trackingNumber: id, photosLinked: photos, parentIncidentId: parent });
  });

  // ---------- STATUS (admin / department)
  const ADMIN_STATUS = ['Under Review', 'Assigned', 'In Progress', 'Resolved', 'Rejected', 'Reopened', 'Escalated'];
  // Allowed manual transitions. "Resolution Submitted" is reached only through completion evidence;
  // "Verified / Closed" and "Disputed" only through the citizen's verification.
  const TRANSITIONS = {
    'Submitted': ['Under Review', 'Assigned', 'Rejected', 'Escalated'],
    'Under Review': ['Assigned', 'In Progress', 'Rejected', 'Escalated'],
    'Assigned': ['Under Review', 'In Progress', 'Escalated', 'Rejected'],
    'In Progress': ['Assigned', 'Escalated'],
    'Resolution Submitted': ['Resolved', 'In Progress'],
    'Resolved': ['Reopened'],
    'Disputed': ['Reopened', 'Escalated'],
    'Reopened': ['Assigned', 'In Progress', 'Escalated'],
    'Escalated': ['Under Review', 'Assigned', 'In Progress', 'Reopened'],
    'Verified / Closed': [],
    'Rejected': []
  };
  router.patch('/api/complaints/:id/status', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const to = req.body.status; const notes = cleanText(req.body.notes, 1000);
    if (!ADMIN_STATUS.includes(to)) return fail(res, 400, 'This status cannot be set manually.', 'BAD_STATUS');
    if (!(TRANSITIONS[c.status] || []).includes(to)) return fail(res, 409, `A complaint cannot move from "${c.status}" to "${to}".`, 'BAD_TRANSITION');
    if (['Rejected', 'Reopened', 'Escalated'].includes(to) && !notes) return fail(res, 400, 'Please record a reason for this change.', 'REASON_REQUIRED');
    if (to === 'Resolved') {
      const ev = db.prepare("SELECT COUNT(*) n FROM complaint_attachments WHERE complaint_id = ? AND evidence_type = 'completion'").get(c.id).n;
      if (!ev) return fail(res, 409, 'Upload or receive a completion (verification) photograph before marking resolved.', 'EVIDENCE_REQUIRED');
    }
    let extra = ''; const ep = [];
    if (to === 'Resolved') { extra = ', resolved_at = ?'; ep.push(now()); }
    if (to === 'Reopened') { extra = ', reopened_count = reopened_count + 1, is_disputed = 0, resolved_at = NULL'; }
    if (to === 'Escalated') { extra = ', escalated_at = ?'; ep.push(now()); }
    setStatus(c, to, notes || `Status updated to ${to}`, req.user, req, extra, ep);
    action(c.id, 'status_change', `${c.status} → ${to}${notes ? `: ${notes}` : ''}`, req.user);
    if (to === 'Resolved') {
      notify(c.citizen_id, 'citizen', `Please verify: ${c.id} marked resolved`, 'The authority has marked your complaint resolved and uploaded evidence. Has the issue actually been resolved? Open the complaint to confirm or dispute.', c.id, 'verification_request');
    } else {
      notify(c.citizen_id, 'citizen', `Update on ${c.id}: ${to}`, notes || `Your complaint status is now "${to}".`, c.id, 'status');
    }
    if (to === 'Reopened') notifyFieldOfficer(c.assigned_officer_id, `Complaint ${c.id} reopened`, notes, c.id, 'reopened');
    ok(res, { message: `Status updated to ${to}` });
  });

  // ---------- ASSIGN department / field worker
  router.post('/api/complaints/:id/assign', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const deptId = req.body.department_id || c.department_id;
    const offId = req.body.assigned_officer_id || null;
    if (!db.prepare('SELECT 1 FROM departments WHERE id = ?').get(deptId)) return fail(res, 400, 'Unknown department.');
    if (req.user.role === ROLES.DEPT && deptId !== req.user.department_id) return fail(res, 403, 'Department officers can only assign within their own department. Ask an administrator to transfer it.');
    let off = null;
    if (offId) {
      off = db.prepare('SELECT * FROM officers WHERE id = ?').get(offId);
      if (!off) return fail(res, 400, 'Unknown field worker.');
    }
    const notes = cleanText(req.body.notes, 500);
    const newStatus = off ? (['Reopened', 'Disputed', 'In Progress'].includes(c.status) ? c.status : 'Assigned') : c.status;
    db.prepare('UPDATE complaints SET department_id = ?, assigned_officer_id = ?, updated_at = ? WHERE id = ?').run(deptId, off ? off.id : null, now(), c.id);
    const dept = db.prepare('SELECT name FROM departments WHERE id = ?').get(deptId);
    const text = `Department: ${dept.name}${off ? ` | Field worker: ${off.name}` : ''}${notes ? ` | ${notes}` : ''}`;
    if (newStatus !== c.status) setStatus(c, newStatus, text, req.user, req);
    action(c.id, deptId !== c.department_id ? 'department_assigned' : 'field_worker_assigned', text, req.user);
    audit(c.id, 'ASSIGNMENT', 'Assignment updated', text, req.user, req);
    notify(c.citizen_id, 'citizen', `Update on ${c.id}`, `Your complaint was assigned to ${dept.name}${off ? ' and a field worker' : ''}.`, c.id, 'assignment');
    if (off) notifyFieldOfficer(off.id, `New task ${c.id}`, `${c.category} at ${c.locality}: ${c.title}`, c.id, 'assignment');
    ok(res, { message: 'Assignment saved' });
  });

  // ---------- PRIORITY change with reason
  router.post('/api/complaints/:id/priority', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const p = req.body.priority; const reason = cleanText(req.body.reason, 500);
    if (!['High', 'Medium', 'Low'].includes(p)) return fail(res, 400, 'Choose High, Medium or Low.');
    if (!reason) return fail(res, 400, 'A reason is required to change priority.', 'REASON_REQUIRED');
    db.prepare('UPDATE complaints SET priority = ?, updated_at = ? WHERE id = ?').run(p, now(), c.id);
    action(c.id, 'priority_change', `${c.priority} → ${p}: ${reason}`, req.user);
    audit(c.id, 'PRIORITY_CHANGE', `Priority ${c.priority} → ${p}`, reason, req.user, req);
    ok(res, { message: 'Priority updated' });
  });

  // ---------- REQUEST more information from citizen
  router.post('/api/complaints/:id/request-info', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const msg = cleanText(req.body.message, 800);
    if (!msg) return fail(res, 400, 'Write what information is needed.', 'REASON_REQUIRED');
    db.prepare('UPDATE complaints SET info_requested = 1, updated_at = ? WHERE id = ?').run(now(), c.id);
    action(c.id, 'info_requested', msg, req.user);
    notify(c.citizen_id, 'citizen', `More information needed for ${c.id}`, msg, c.id, 'info_request');
    ok(res, { message: 'Request sent to citizen' });
  });

  router.post('/api/complaints/:id/respond-info', (req, res, params) => {
    const c = guard(req, res, params.id, [ROLES.CITIZEN]);
    if (!c) return;
    const msg = cleanText(req.body.message, 1500);
    if (!msg && !(req.body.media_ids || []).length) return fail(res, 400, 'Add a reply or a photo.');
    const n = linkMedia(c, req.body.media_ids, 'complaint', req.user, 0, 'Additional photo from citizen');
    db.prepare('UPDATE complaints SET info_requested = 0, updated_at = ? WHERE id = ?').run(now(), c.id);
    action(c.id, 'citizen_reply', `${msg}${n ? ` (+${n} photo)` : ''}`, req.user);
    notifyStaff(c, `Citizen replied on ${c.id}`, msg || 'New photo added', 'citizen_reply');
    ok(res, { message: 'Reply sent' });
  });

  // ---------- ESCALATE
  router.post('/api/complaints/:id/escalate', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const reason = cleanText(req.body.reason, 600);
    if (!reason) return fail(res, 400, 'A reason is required to escalate.', 'REASON_REQUIRED');
    setStatus(c, 'Escalated', reason, req.user, req, ', escalated_at = ?', [now()]);
    action(c.id, 'escalated', reason, req.user);
    notify(null, 'admin', `Escalated: ${c.id}`, reason, c.id, 'escalation');
    notify(c.citizen_id, 'citizen', `Update on ${c.id}: Escalated`, 'Your complaint has been escalated to senior officials for faster action.', c.id, 'escalation');
    ok(res, { message: 'Escalated' });
  });

  // ---------- REMARK (internal or visible)
  router.post('/api/complaints/:id/remark', (req, res, params) => {
    const c = guard(req, res, params.id, STAFF_ROLES);
    if (!c) return;
    const text = cleanText(req.body.text, 1500);
    if (!text) return fail(res, 400, 'Remark is empty.');
    action(c.id, 'remark', text, req.user, req.body.visible_to_citizen ? 1 : 0);
    if (req.body.visible_to_citizen) notify(c.citizen_id, 'citizen', `Administrative update on ${c.id}`, text, c.id, 'admin_update');
    ok(res, { message: 'Remark saved' });
  });

  // ---------- LOCATION calibration (admin)
  router.patch('/api/complaints/:id', (req, res, params) => {
    const c = guard(req, res, params.id, ADMIN_ROLES);
    if (!c) return;
    const { latitude, longitude, location_address, landmark } = req.body;
    db.prepare(`UPDATE complaints SET latitude = COALESCE(?, latitude), longitude = COALESCE(?, longitude),
      location_address = COALESCE(?, location_address), landmark = COALESCE(?, landmark), updated_at = ? WHERE id = ?`)
      .run(Number.isFinite(+latitude) ? +latitude : null, Number.isFinite(+longitude) ? +longitude : null,
        location_address ? cleanText(location_address, 300) : null, landmark ? cleanText(landmark, 200) : null, now(), c.id);
    action(c.id, 'location_corrected', `${c.latitude},${c.longitude} → ${latitude},${longitude}`, req.user, 0);
    ok(res, { message: 'Location updated' });
  });

  // ---------- COMMUNITY +1 (any citizen, once)
  router.post('/api/complaints/:id/confirm', (req, res, params) => {
    if (!requireAuth(req, res, [ROLES.CITIZEN])) return;
    const c = load(params.id);
    if (!c) return fail(res, 404, 'Complaint not found.');
    if (c.citizen_id === req.user.id) return fail(res, 409, 'You reported this issue yourself.');
    if (db.prepare('SELECT 1 FROM community_confirmations WHERE complaint_id = ? AND citizen_id = ?').get(c.id, req.user.id)) {
      return fail(res, 409, 'You have already confirmed this issue.', 'ALREADY_CONFIRMED');
    }
    db.prepare('INSERT INTO community_confirmations (id, complaint_id, citizen_id, confirmation_type, comment, created_at) VALUES (?,?,?,?,?,?)')
      .run(newId('CONF'), c.id, req.user.id, req.body.confirmation_type === 'still_present' ? 'still_present' : 'affected', cleanText(req.body.comment, 300), now());
    db.prepare('UPDATE complaints SET community_confirmations_count = community_confirmations_count + 1, affected_citizens_estimate = affected_citizens_estimate + 1, updated_at = ? WHERE id = ?').run(now(), c.id);
    ok(res, { message: 'Thank you. Your confirmation was added.' });
  });

  // ---------- FIELD EVIDENCE (inspection / progress / completion)
  router.post('/api/complaints/:id/evidence', (req, res, params) => {
    const c = guard(req, res, params.id, STAFF_ROLES);
    if (!c) return;
    const type = req.body.evidence_type;
    if (!EVIDENCE_TYPES.includes(type)) return fail(res, 400, 'Choose inspection, work-in-progress or completion.', 'BAD_EVIDENCE_TYPE');
    if (CLOSED_STATUSES.includes(c.status)) return fail(res, 409, 'This complaint is already closed.');
    const notes = cleanText(req.body.notes, 1500);
    if (type === 'completion' && !(req.body.media_ids || []).length) return fail(res, 400, 'A completion photograph is required.', 'EVIDENCE_REQUIRED');
    const n = linkMedia(c, req.body.media_ids, type, req.user, 0, notes);
    if (type === 'completion' && !n) return fail(res, 400, 'The completion photograph could not be attached. Upload it again.', 'EVIDENCE_REQUIRED');
    const labels = { inspection: 'Inspection', progress: 'Work in progress', completion: 'Work completed' };
    action(c.id, `evidence_${type}`, `${labels[type]}: ${notes || 'photo uploaded'} (${n} photo${n === 1 ? '' : 's'})`, req.user);
    audit(c.id, 'EVIDENCE_UPLOAD', `${labels[type]} evidence uploaded`, notes, req.user, req);
    if (type === 'completion') {
      setStatus(c, 'Resolution Submitted', `Completion evidence uploaded. ${notes}`, req.user, req, ', resolution_notes = ?', [notes]);
      notifyStaff(c, `Review completion: ${c.id}`, 'Field worker uploaded completion evidence. Review and mark resolved.', 'evidence');
      notify(c.citizen_id, 'citizen', `Work completed on ${c.id}`, 'The field team reports the work is done. An official will review it and then ask you to confirm.', c.id, 'evidence');
    } else if (['Assigned', 'Reopened', 'Under Review'].includes(c.status)) {
      setStatus(c, 'In Progress', `${labels[type]} update. ${notes}`, req.user, req);
      notify(c.citizen_id, 'citizen', `Work started on ${c.id}`, `${labels[type]} update from the field team.`, c.id, 'work_started');
    } else {
      notify(c.citizen_id, 'citizen', `Progress on ${c.id}`, `${labels[type]} photo uploaded by the field team.`, c.id, 'evidence');
    }
    ok(res, { message: 'Evidence saved', photos: n });
  });

  // ---------- CITIZEN VERIFICATION or DISPUTE
  router.post('/api/complaints/:id/verify', (req, res, params) => {
    const c = guard(req, res, params.id, [ROLES.CITIZEN]);
    if (!c) return;
    if (c.status !== 'Resolved') return fail(res, 409, 'This complaint is not waiting for your confirmation.', 'NOT_AWAITING_VERIFICATION');
    if (req.body.verified === true) {
      setStatus(c, 'Verified / Closed', 'Citizen confirmed the issue is resolved.', req.user, req, ', verified_at = ?, is_disputed = 0', [now()]);
      action(c.id, 'citizen_verified', 'Citizen confirmed resolution', req.user);
      notifyStaff(c, `Verified by citizen: ${c.id}`, 'Citizen confirmed the issue is resolved.', 'verified');
      return ok(res, { message: 'Thank you for confirming.' });
    }
    const reason = cleanText(req.body.dispute_reason, 1000);
    if (!reason) return fail(res, 400, 'Tell us what is still wrong.', 'REASON_REQUIRED');
    const n = linkMedia(c, req.body.media_ids, 'dispute', req.user, 0, 'Citizen dispute photo');
    setStatus(c, 'Disputed', `Citizen says the issue still exists: ${reason}`, req.user, req, ', is_disputed = 1, dispute_reason = ?', [reason]);
    action(c.id, 'citizen_disputed', `${reason}${n ? ` (+${n} photo)` : ''}`, req.user);
    notifyStaff(c, `Disputed resolution: ${c.id}`, reason, 'dispute');
    ok(res, { message: 'Your dispute was sent to the administration for review.' });
  });
}

module.exports = setupComplaintsRoutes;
module.exports.slaState = slaState;
module.exports.CATEGORIES = CATEGORIES;
module.exports.STATUSES = STATUSES;
module.exports.OPEN_STATUSES = OPEN_STATUSES;
module.exports.CLOSED_STATUSES = CLOSED_STATUSES;
