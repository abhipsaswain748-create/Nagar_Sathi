// Media (photo) uploads with validation, EXIF-location stripping and access control.
// Files are stored outside /public and served only through /api/media/:id after a permission check.
const fs = require('node:fs');
const path = require('node:path');
const { STAFF_ROLES, ROLES } = require('../auth');
const { ok, created, fail, requireAuth, newId, send } = require('../http-utils');

const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MAX_IMAGE_BYTES = Number(process.env.MAX_IMAGE_BYTES || 5 * 1024 * 1024);
const CITIZEN_PURPOSES = ['complaint', 'dispute', 'feedback'];
const STAFF_PURPOSES = ['inspection', 'progress', 'completion'];

function sniff(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.length > 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  return null;
}

// Remove APP1 (EXIF/XMP, which can carry GPS coordinates) segments from JPEG files
function stripJpegMetadata(buf) {
  if (!(buf[0] === 0xff && buf[1] === 0xd8)) return buf;
  const parts = [buf.slice(0, 2)];
  let i = 2;
  while (i + 4 <= buf.length) {
    if (buf[i] !== 0xff) break;
    const marker = buf[i + 1];
    if (marker === 0xda) { parts.push(buf.slice(i)); return Buffer.concat(parts); } // start of scan
    const len = buf.readUInt16BE(i + 2);
    const seg = buf.slice(i, i + 2 + len);
    if (marker !== 0xe1) parts.push(seg);
    i += 2 + len;
  }
  return buf; // unexpected structure: keep original rather than corrupt it
}

function canView(db, user, media) {
  if (!user) return false;
  if (media.owner_id === user.id) return true;
  if (STAFF_ROLES.includes(user.role)) return true;
  if (media.complaint_id) {
    const c = db.prepare('SELECT citizen_id FROM complaints WHERE id = ?').get(media.complaint_id);
    if (c && c.citizen_id === user.id) return true;
  }
  return false;
}

function isPublic(db, mediaId) {
  return !!db.prepare('SELECT 1 FROM complaint_attachments WHERE media_id = ? AND is_public = 1').get(mediaId);
}

function setupMediaRoutes(router, db) {
  router.post('/api/media', (req, res) => {
    if (!requireAuth(req, res)) return;
    const purpose = String(req.body.purpose || 'complaint');
    const allowed = req.user.role === ROLES.CITIZEN ? CITIZEN_PURPOSES : [...STAFF_PURPOSES, 'complaint'];
    if (!allowed.includes(purpose)) return fail(res, 403, 'You cannot upload this type of evidence.', 'FORBIDDEN_PURPOSE');

    const raw = String(req.body.data || '');
    const b64 = raw.includes(',') ? raw.split(',').pop() : raw;
    if (!b64) return fail(res, 400, 'No image received.', 'NO_FILE');
    let buf;
    try { buf = Buffer.from(b64, 'base64'); } catch (e) { return fail(res, 400, 'The file could not be read.', 'BAD_FILE'); }
    if (buf.length > MAX_IMAGE_BYTES) return fail(res, 413, `Photo is larger than ${Math.round(MAX_IMAGE_BYTES / 1048576)} MB.`, 'TOO_LARGE');
    const type = sniff(buf);
    if (!type) return fail(res, 415, 'Only JPEG, PNG or WEBP photos are accepted.', 'BAD_TYPE');
    if (type.mime === 'image/jpeg') buf = stripJpegMetadata(buf);

    const id = newId('MED');
    const fileName = `${id}.${type.ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, fileName), buf);
    db.prepare('INSERT INTO media (id, owner_id, owner_role, complaint_id, purpose, mime, size_bytes, file_name, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(id, req.user.id, req.user.role, req.body.complaint_id || null, purpose, type.mime, buf.length, fileName, new Date().toISOString());
    created(res, { media: { id, url: `/api/media/${id}`, mime: type.mime, size: buf.length, purpose } });
  });

  router.get('/api/media/:id', (req, res, params) => {
    const m = db.prepare('SELECT * FROM media WHERE id = ?').get(params.id);
    if (!m) return fail(res, 404, 'Photo not found.');
    if (!canView(db, req.user, m) && !isPublic(db, m.id)) return fail(res, req.user ? 403 : 401, 'You do not have access to this photo.');
    const file = path.join(UPLOAD_DIR, path.basename(m.file_name));
    fs.readFile(file, (err, data) => {
      if (err) return send(res, 404, { success: false, error: 'File missing on server.' });
      res.writeHead(200, { 'Content-Type': m.mime, 'Cache-Control': 'private, max-age=600', 'X-Content-Type-Options': 'nosniff' });
      res.end(data);
    });
  });

  router.delete('/api/media/:id', (req, res, params) => {
    if (!requireAuth(req, res)) return;
    const m = db.prepare('SELECT * FROM media WHERE id = ?').get(params.id);
    if (!m) return fail(res, 404, 'Photo not found.');
    if (m.owner_id !== req.user.id) return fail(res, 403, 'You can only remove your own uploads.');
    if (db.prepare('SELECT 1 FROM complaint_attachments WHERE media_id = ?').get(m.id)) return fail(res, 409, 'This photo is already part of a submitted record.');
    db.prepare('DELETE FROM media WHERE id = ?').run(m.id);
    try { fs.unlinkSync(path.join(UPLOAD_DIR, path.basename(m.file_name))); } catch (e) {}
    ok(res, { message: 'Removed' });
  });
}

module.exports = setupMediaRoutes;
module.exports.canView = canView;
