// Notifications — scoped to the authenticated user.
// Fix: the old query used "all" in double quotes, which SQLite treats as an identifier (crashes when
// double-quoted string literals are disabled, as in Node's bundled SQLite). Parameters are bound now.
const { ROLES } = require('../auth');
const { ok, fail, requireAuth } = require('../http-utils');

function scope(user) {
  // Personal notifications, plus role broadcasts (user_id NULL) for staff roles
  if (user.role === ROLES.CITIZEN) return { sql: 'user_id = ?', p: [user.id] };
  return { sql: '(user_id = ? OR (user_id IS NULL AND target_role IN (?, ?)))', p: [user.id, user.role, 'all'] };
}

function setupNotificationsRoutes(router, db) {
  router.get('/api/notifications', (req, res) => {
    if (!req.user) return ok(res, { count: 0, unreadCount: 0, data: [] });
    const s = scope(req.user);
    // Department officials only see broadcasts about their department's complaints
    let extra = '';
    const p = [...s.p];
    if (req.user.role === ROLES.DEPT) { extra = ' AND (complaint_id IS NULL OR user_id = ? OR complaint_id IN (SELECT id FROM complaints WHERE department_id = ?))'; p.push(req.user.id, req.user.department_id); }
    const rows = db.prepare(`SELECT * FROM notifications WHERE ${s.sql}${extra} ORDER BY created_at DESC LIMIT 50`).all(...p);
    ok(res, { count: rows.length, unreadCount: rows.filter(r => !r.is_read).length, data: rows });
  });

  router.post('/api/notifications/:id/read', (req, res, params) => {
    if (!requireAuth(req, res)) return;
    const s = scope(req.user);
    const r = db.prepare(`UPDATE notifications SET is_read = 1 WHERE id = ? AND ${s.sql}`).run(params.id, ...s.p);
    if (!r.changes) return fail(res, 404, 'Notification not found.');
    ok(res, { message: 'Marked as read' });
  });

  router.post('/api/notifications/read-all', (req, res) => {
    if (!requireAuth(req, res)) return;
    const s = scope(req.user);
    db.prepare(`UPDATE notifications SET is_read = 1 WHERE ${s.sql}`).run(...s.p);
    ok(res, { message: 'All notifications marked as read' });
  });
}

module.exports = setupNotificationsRoutes;
