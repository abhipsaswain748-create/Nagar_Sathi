// Administrative command-centre data + public civic intelligence (aggregated, privacy-safe)
const { ROLES, STAFF_ROLES, ADMIN_ROLES } = require('../auth');
const { ok, fail, requireAuth, query, newId } = require('../http-utils');
const { slaState, OPEN_STATUSES } = require('./complaints');


function scoped(db, user, q) {
  let sql = "SELECT c.*, d.name AS department_name, o.name AS officer_name FROM complaints c LEFT JOIN departments d ON d.id = c.department_id LEFT JOIN officers o ON o.id = c.assigned_officer_id WHERE c.id NOT LIKE 'NS-2025-%'";
  const p = [];
  if (user.role === ROLES.DEPT) { sql += ' AND c.department_id = ?'; p.push(user.department_id); }
  if (user.role === ROLES.FIELD) { sql += ' AND c.assigned_officer_id = ?'; p.push(user.officer_id || '_'); }
  if (q) {
    for (const k of ['category', 'status', 'priority', 'locality', 'department_id']) {
      const v = q.get(k); if (v && v !== 'all') { sql += ` AND c.${k} = ?`; p.push(v); }
    }
    if (q.get('from')) { sql += ' AND c.created_at >= ?'; p.push(new Date(q.get('from')).toISOString()); }
    if (q.get('to')) { sql += ' AND c.created_at <= ?'; p.push(new Date(new Date(q.get('to')).getTime() + 86399e3).toISOString()); }
  }
  return db.prepare(sql).all(...p).map(c => ({ ...c, sla: slaState(c) }));
}

function clusters(rows, radiusMeters = 300) {
  // Group by civic domain and actual geographic distance. This avoids missing a hotspot
  // merely because two nearby reports fall on opposite sides of a rounded grid boundary.
  const valid = rows.filter(r => Number.isFinite(Number(r.latitude)) && Number.isFinite(Number(r.longitude))
    && Math.abs(Number(r.latitude)) <= 90 && Math.abs(Number(r.longitude)) <= 180);
  const parent = valid.map((_, i) => i);
  const find = i => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
  const join = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent[rb] = ra; };
  const radians = n => n * Math.PI / 180;
  const distance = (a, b) => {
    const dLat = radians(Number(b.latitude) - Number(a.latitude));
    const dLon = radians(Number(b.longitude) - Number(a.longitude));
    const lat1 = radians(Number(a.latitude)), lat2 = radians(Number(b.latitude));
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
    return 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  };
  for (let i = 0; i < valid.length; i++) {
    for (let j = i + 1; j < valid.length; j++) {
      if (valid[i].category === valid[j].category && distance(valid[i], valid[j]) <= radiusMeters) join(i, j);
    }
  }
  const groups = new Map();
  valid.forEach((row, i) => { const root = find(i); if (!groups.has(root)) groups.set(root, []); groups.get(root).push(row); });
  return [...groups.values()];
}

function setupAdminRoutes(router, db) {
  // ---- Public homepage statistics (real counts; flags when they include demo records)
  router.get('/api/public/stats', (req, res) => {
    const rows = db.prepare("SELECT status, sla_deadline, resolved_at, is_demo FROM complaints WHERE id NOT LIKE 'NS-2025-%'").all();
    const closed = rows.filter(r => r.resolved_at);
    const met = closed.filter(r => new Date(r.resolved_at) <= new Date(r.sla_deadline)).length;
    ok(res, { data: {
      total: rows.length,
      active: rows.filter(r => OPEN_STATUSES.includes(r.status)).length,
      verified: rows.filter(r => r.status === 'Verified / Closed').length,
      slaCompliancePct: closed.length ? Math.round(met / closed.length * 100) : null,
      slaSample: closed.length,
      includesDemo: rows.some(r => r.is_demo)
    } });
  });

  // ---- Overview with filters
  router.get('/api/admin/overview', (req, res) => {
    if (!requireAuth(req, res, STAFF_ROLES)) return;
    const rows = scoped(db, req.user, query(req));
    const by = (f) => rows.reduce((m, r) => { const k = f(r) || 'Unassigned'; m[k] = (m[k] || 0) + 1; return m; }, {});
    const open = rows.filter(r => OPEN_STATUSES.includes(r.status));
    const dayAgo = Date.now() - 24 * 3600e3;
    ok(res, { data: {
      total: rows.length,
      new24h: rows.filter(r => new Date(r.created_at).getTime() >= dayAgo).length,
      byStatus: by(r => r.status),
      pending: rows.filter(r => ['Submitted', 'Under Review'].includes(r.status)).length,
      highPriorityOpen: open.filter(r => r.priority === 'High').length,
      sla: {
        approaching: open.filter(r => r.sla.state === 'approaching').length,
        dueToday: open.filter(r => r.sla.state === 'due_today').length,
        overdue: open.filter(r => ['overdue', 'escalated_overdue'].includes(r.sla.state)).length,
        escalated: open.filter(r => r.sla.state.startsWith('escalated')).length,
        metOnClosed: rows.filter(r => r.sla.state === 'met').length,
        closedAfterDeadline: rows.filter(r => r.sla.state === 'breached_closed').length
      },
      byCategory: by(r => r.category),
      byDepartment: by(r => r.department_name),
      includesDemo: rows.some(r => r.is_demo)
    } });
  });

  // ---- Department performance
  router.get('/api/admin/departments', (req, res) => {
    if (!requireAuth(req, res, ADMIN_ROLES)) return;
    const depts = db.prepare('SELECT * FROM departments').all().filter(d => req.user.role === ROLES.ADMIN || d.id === req.user.department_id);
    const all = scoped(db, { role: ROLES.ADMIN });
    const data = depts.map(d => {
      const rows = all.filter(r => r.department_id === d.id);
      const resolved = rows.filter(r => r.resolved_at);
      const met = resolved.filter(r => new Date(r.resolved_at) <= new Date(r.sla_deadline)).length;
      const hours = resolved.map(r => (new Date(r.resolved_at) - new Date(r.created_at)) / 3600e3).filter(h => h > 0);
      return {
        id: d.id, name: d.name, code: d.code, sla_hours_default: d.sla_hours_default, head: d.active_head,
        total: rows.length,
        pending: rows.filter(r => ['Submitted', 'Under Review', 'Assigned'].includes(r.status)).length,
        inProgress: rows.filter(r => ['In Progress', 'Resolution Submitted', 'Reopened', 'Disputed', 'Escalated'].includes(r.status)).length,
        resolved: rows.filter(r => ['Resolved', 'Verified / Closed'].includes(r.status)).length,
        overdue: rows.filter(r => OPEN_STATUSES.includes(r.status) && r.sla.state.includes('overdue')).length,
        slaCompliancePct: resolved.length ? Math.round(met / resolved.length * 100) : null,
        avgResolutionHours: hours.length >= 2 ? Math.round(hours.reduce((a, b) => a + b, 0) / hours.length) : null,
        sampleSize: resolved.length
      };
    });
    ok(res, { data });
  });

  // ---- Field workers and their evidence
  router.get('/api/admin/field-workers', (req, res) => {
    if (!requireAuth(req, res, ADMIN_ROLES)) return;
    let officers = db.prepare('SELECT o.*, d.name AS department_name FROM officers o LEFT JOIN departments d ON d.id = o.department_id').all();
    if (req.user.role === ROLES.DEPT) officers = officers.filter(o => o.department_id === req.user.department_id);
    const data = officers.map(o => {
      const tasks = db.prepare("SELECT id, title, status, priority, sla_deadline, resolved_at, category, locality, escalated_at FROM complaints WHERE assigned_officer_id = ? AND id NOT LIKE 'NS-2025-%' ORDER BY updated_at DESC").all(o.id)
        .map(t => ({ ...t, sla_state: slaState(t).state }));
      const evidence = db.prepare(`SELECT a.complaint_id, a.evidence_type, a.created_at, a.caption, a.media_id, a.file_url FROM complaint_attachments a
        JOIN complaints c ON c.id = a.complaint_id WHERE c.assigned_officer_id = ? AND a.evidence_type IN ('inspection','progress','completion') ORDER BY a.created_at DESC LIMIT 6`).all(o.id)
        .map(e => ({ ...e, url: e.media_id ? `/api/media/${e.media_id}` : e.file_url }));
      return { id: o.id, name: o.name, designation: o.designation, zone: o.zone, department_name: o.department_name, has_login: !!o.profile_id,
        open: tasks.filter(t => OPEN_STATUSES.includes(t.status)).length, tasks, evidence };
    });
    ok(res, { data, note: 'No live GPS tracking: location of field workers is not collected.' });
  });

  // ---- Audit log (staff, scoped)
  router.get('/api/admin/audit', (req, res) => {
    if (!requireAuth(req, res, ADMIN_ROLES)) return;
    const q = query(req);
    let sql = 'SELECT a.* FROM audit_logs a LEFT JOIN complaints c ON c.id = a.complaint_id WHERE 1=1'; const p = [];
    if (req.user.role === ROLES.DEPT) { sql += ' AND c.department_id = ?'; p.push(req.user.department_id); }
    if (q.get('complaint_id')) { sql += ' AND a.complaint_id = ?'; p.push(q.get('complaint_id')); }
    sql += ' ORDER BY a.created_at DESC LIMIT 200';
    ok(res, { data: db.prepare(sql).all(...p) });
  });

  // ---- Incident grouping correction (admin)
  router.post('/api/admin/incidents/:id/unlink', (req, res, params) => {
    if (!requireAuth(req, res, [ROLES.ADMIN])) return;
    const c = db.prepare('SELECT * FROM complaints WHERE id = ?').get(params.id);
    if (!c || !c.parent_incident_id) return fail(res, 404, 'This complaint is not grouped.');
    db.prepare('UPDATE complaints SET parent_incident_id = NULL, updated_at = ? WHERE id = ?').run(new Date().toISOString(), c.id);
    db.prepare(`INSERT INTO complaint_actions (id, complaint_id, action_type, details, visible_to_citizen, actor_id, actor_name, actor_role, created_at) VALUES (?,?,?,?,0,?,?,?,?)`)
      .run(newId('ACT'), c.id, 'incident_ungrouped', `Removed from shared incident ${c.parent_incident_id}`, req.user.id, req.user.name, req.user.role, new Date().toISOString());
    ok(res, { message: 'Removed from incident group' });
  });
  router.post('/api/admin/incidents/:id/link', (req, res, params) => {
    if (!requireAuth(req, res, [ROLES.ADMIN])) return;
    const c = db.prepare('SELECT * FROM complaints WHERE id = ?').get(params.id);
    const parent = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.body.parent_id || '');
    if (!c || !parent || parent.id === c.id) return fail(res, 400, 'Choose a valid parent incident.');
    db.prepare('UPDATE complaints SET parent_incident_id = ?, updated_at = ? WHERE id = ?').run(parent.id, new Date().toISOString(), c.id);
    ok(res, { message: 'Grouped' });
  });

  // ---- Shared incidents (public, aggregated)
  router.get('/api/intel/incidents', (req, res) => {
    const rows = db.prepare(`SELECT c.id, c.category, c.locality, c.ward_no, c.status, c.parent_incident_id, c.created_at, c.updated_at,
      c.community_confirmations_count, c.latitude, c.longitude, c.is_demo, c.title, d.name AS department_name FROM complaints c
      LEFT JOIN departments d ON d.id = c.department_id WHERE c.id NOT LIKE 'NS-2025-%' AND c.status != 'Rejected'`).all();
    const groups = new Map();
    // 1) explicit groups (parent + children)
    for (const r of rows) {
      const root = r.parent_incident_id || r.id;
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(r);
    }
    const data = [...groups.entries()].map(([root, members]) => {
      const lead = members.find(m => m.id === root) || members[0];
      const reporters = members.reduce((a, m) => a + (m.community_confirmations_count || 1), 0);
      const dates = members.map(m => m.created_at).sort();
      return {
        incident_id: `INC-${root}`, lead_complaint: root, title: lead.title, category: lead.category, area: `${lead.locality}, Ward ${lead.ward_no}`,
        related_complaints: members.length, citizens_reporting: reporters, earliest: dates[0], latest: dates[dates.length - 1],
        status: lead.status, department: lead.department_name, is_demo: members.some(m => m.is_demo),
        complaint_ids: members.map(m => m.id), latitude: +lead.latitude.toFixed(3), longitude: +lead.longitude.toFixed(3)
      };
    }).filter(g => g.related_complaints > 1 || g.citizens_reporting > 1)
      .sort((a, b) => b.citizens_reporting - a.citizens_reporting);
    ok(res, { data, meta: { rule: 'Grouped only when a complaint was linked to an existing open complaint of the same category within ~150 m at submission, or by an administrator. Individual complaints are kept.' } });
  });

  // ---- Recurring issue history (public, aggregated; includes closed history)
  router.get('/api/intel/recurring', (req, res) => {
    const q = query(req);
    let rows = db.prepare('SELECT id, category, locality, ward_no, latitude, longitude, status, created_at, resolved_at, is_demo FROM complaints WHERE status != ?').all('Rejected');
    if (q.get('category') && q.get('category') !== 'all') rows = rows.filter(r => r.category === q.get('category'));
    const yearAgo = Date.now() - 365 * 24 * 3600e3;
    const data = clusters(rows).filter(g => g.length >= 2).map(g => {
      g.sort((a, b) => a.created_at.localeCompare(b.created_at));
      const recent = g.filter(r => new Date(r.created_at).getTime() >= yearAgo).length;
      const open = g.filter(r => OPEN_STATUSES.includes(r.status));
      const lat = g.reduce((a, r) => a + r.latitude, 0) / g.length;
      const lon = g.reduce((a, r) => a + r.longitude, 0) / g.length;
      return {
        category: g[0].category, area: `${g[g.length - 1].locality}, Ward ${g[g.length - 1].ward_no}`,
        latitude: +lat.toFixed(3), longitude: +lon.toFixed(3),
        total_reports: g.length, reports_last_12_months: recent,
        first_reported: g[0].created_at, last_reported: g[g.length - 1].created_at,
        previous_resolutions: g.filter(r => r.resolved_at).map(r => r.resolved_at).sort(),
        currently_open: open.length, current_status: open.length ? open[open.length - 1].status : 'No open complaint',
        flag_preventive_maintenance: recent >= 3,
        flag_reason: recent >= 3 ? `${recent} reports of the same category within ~300 m in the last 12 months (rule: 3 or more).` : null,
        is_demo: g.some(r => r.is_demo)
      };
    }).sort((a, b) => b.total_reports - a.total_reports);
    ok(res, { data, meta: { method: 'Same category within a ~300 m grid cell. Flags are rule-based recommendations, not inspections.' } });
  });

  // ---- Hotspots (public): open complaints in the selected window
  router.get('/api/intel/hotspots', (req, res) => {
    const q = query(req);
    const days = Math.min(365, Math.max(1, Number(q.get('days')) || 30));
    const since = new Date(Date.now() - days * 24 * 3600e3).toISOString();
    let rows = db.prepare("SELECT id, category, locality, ward_no, latitude, longitude, priority, status, is_demo FROM complaints WHERE created_at >= ? AND id NOT LIKE 'NS-2025-%' AND status != 'Rejected'").all(since);
    if (q.get('category') && q.get('category') !== 'all') rows = rows.filter(r => r.category === q.get('category'));
    const data = clusters(rows).filter(g => g.length >= 2).map(g => ({
      category: g[0].category, area: `${g[0].locality}, Ward ${g[0].ward_no}`, count: g.length,
      latitude: +(g.reduce((a, r) => a + r.latitude, 0) / g.length).toFixed(3),
      longitude: +(g.reduce((a, r) => a + r.longitude, 0) / g.length).toFixed(3),
      severity: { High: g.filter(r => r.priority === 'High').length, Medium: g.filter(r => r.priority === 'Medium').length, Low: g.filter(r => r.priority === 'Low').length },
      open: g.filter(r => OPEN_STATUSES.includes(r.status)).length, is_demo: g.some(r => r.is_demo)
    })).sort((a, b) => b.count - a.count);
    ok(res, { data, meta: { days, method: '2 or more complaints of the same category within ~300 m in the period.' } });
  });
}

module.exports = setupAdminRoutes;
