// Server-side speech-to-text fallback.
// Used when the browser's own speech recognition is unavailable or does not support the chosen language.
// Provider: Azure AI Speech "REST API for short audio" (lists en-IN, hi-IN and or-IN as supported locales).
// The key never leaves the server. Without AZURE_SPEECH_KEY + AZURE_SPEECH_REGION this route reports
// "not configured" honestly instead of pretending to transcribe.
const { ok, fail, requireAuth } = require('../http-utils');

const LOCALES = { English: 'en-IN', Hindi: 'hi-IN', Odia: 'or-IN' };

function providerConfigured() {
  return !!(process.env.AZURE_SPEECH_KEY && process.env.AZURE_SPEECH_REGION);
}

function setupSpeechRoutes(router) {
  router.get('/api/speech/config', (req, res) => {
    ok(res, {
      serverProvider: providerConfigured() ? 'azure' : null,
      locales: LOCALES,
      maxSeconds: 55
    });
  });

  router.post('/api/speech/transcribe', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const locale = LOCALES[req.body.language];
    if (!locale) return fail(res, 400, 'Choose English, Hindi or Odia.', 'BAD_LANGUAGE');
    if (!providerConfigured()) {
      return fail(res, 503, 'Server speech recognition is not configured. Type your complaint instead, or ask the administrator to add an Azure Speech key.', 'STT_NOT_CONFIGURED');
    }
    const raw = String(req.body.audio || '');
    const audio = Buffer.from(raw.includes(',') ? raw.split(',').pop() : raw, 'base64');
    if (audio.length < 1000) return fail(res, 400, 'No audio was captured. Check your microphone and try again.', 'EMPTY_AUDIO');
    if (audio.slice(0, 4).toString() !== 'RIFF') return fail(res, 415, 'Audio must be 16 kHz mono WAV.', 'BAD_AUDIO');

    const url = `https://${process.env.AZURE_SPEECH_REGION}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=${locale}&format=simple`;
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': process.env.AZURE_SPEECH_KEY,
          'Content-Type': 'audio/wav; codecs=audio/pcm; samplerate=16000',
          Accept: 'application/json'
        },
        body: audio,
        signal: AbortSignal.timeout(30000)
      });
      const text = await r.text();
      if (!r.ok) {
        console.error('[STT] provider error', r.status, text.slice(0, 200));
        return fail(res, 502, `Speech service returned an error (${r.status}).`, 'STT_PROVIDER_ERROR');
      }
      let data = {};
      try { data = JSON.parse(text); } catch (e) {}
      if (data.RecognitionStatus !== 'Success' || !data.DisplayText) {
        return fail(res, 422, 'No speech could be recognised in that recording. Please speak closer to the microphone and retry.', 'NO_SPEECH');
      }
      ok(res, { transcript: data.DisplayText, locale, provider: 'azure' });
    } catch (err) {
      console.error('[STT] network error', err.message);
      fail(res, 504, 'Could not reach the speech service. Check the internet connection.', 'STT_NETWORK');
    }
  });
}

module.exports = setupSpeechRoutes;
