// Shared HTTP helpers for route modules
const crypto = require('node:crypto');

function send(res, status, payload, headers = {}) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(payload));
}

function ok(res, payload = {}) { send(res, 200, { success: true, ...payload }); }
function created(res, payload = {}) { send(res, 201, { success: true, ...payload }); }
function fail(res, status, error, code) { send(res, status, { success: false, error, code: code || undefined }); }

// Returns true when the request may continue; otherwise responds 401/403.
function requireAuth(req, res, roles) {
  if (!req.user) { fail(res, 401, 'Please log in to continue.', 'AUTH_REQUIRED'); return false; }
  if (roles && !roles.includes(req.user.role)) { fail(res, 403, 'You do not have permission for this action.', 'FORBIDDEN'); return false; }
  return true;
}

function query(req) {
  return new URL(req.url, 'http://localhost').searchParams;
}

function newId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`.toUpperCase();
}

function hashSig(str) {
  return crypto.createHash('sha256').update(str).digest('hex').substring(0, 16);
}

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
}

function cleanText(v, max = 2000) {
  if (v === undefined || v === null) return '';
  return String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);
}

module.exports = { send, ok, created, fail, requireAuth, query, newId, hashSig, clientIp, cleanText };
