// Nagar Sarthi Database Module (SQLite with Node.js native DatabaseSync)
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'nagar_sarthi.db');

// Initialize database
let db;
try {
  db = new DatabaseSync(DB_PATH);
  console.log(`[DB] Connected to SQLite database at: ${DB_PATH}`);
} catch (err) {
  console.error('[DB] SQLite initialization failed:', err);
  throw err;
}

// Enable foreign keys
db.exec('PRAGMA foreign_keys = ON;');

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS profiles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      role TEXT NOT NULL CHECK(role IN ('citizen', 'admin', 'dept_officer', 'field_officer')),
      department_id TEXT,
      designation TEXT,
      avatar TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS departments (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT UNIQUE NOT NULL,
      description TEXT,
      sla_hours_default INTEGER NOT NULL DEFAULT 48,
      active_head TEXT,
      phone TEXT,
      icon TEXT
    );

    CREATE TABLE IF NOT EXISTS officers (
      id TEXT PRIMARY KEY,
      profile_id TEXT,
      department_id TEXT NOT NULL,
      name TEXT NOT NULL,
      designation TEXT,
      zone TEXT,
      phone TEXT,
      active_tasks INTEGER DEFAULT 0,
      status TEXT DEFAULT 'available',
      FOREIGN KEY (department_id) REFERENCES departments(id)
    );

    CREATE TABLE IF NOT EXISTS infrastructure_entities (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      locality TEXT NOT NULL,
      ward_no INTEGER NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      install_year INTEGER,
      last_repaired_date TEXT,
      total_failures INTEGER DEFAULT 0,
      health_index REAL DEFAULT 100.0,
      preventive_maintenance_recommended INTEGER DEFAULT 0,
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id TEXT PRIMARY KEY,
      tracking_number TEXT UNIQUE NOT NULL,
      citizen_id TEXT NOT NULL,
      citizen_name TEXT NOT NULL,
      citizen_phone TEXT,
      category TEXT NOT NULL,
      subcategory TEXT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      original_language TEXT DEFAULT 'English',
      audio_url TEXT,
      transcription TEXT,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      location_address TEXT NOT NULL,
      landmark TEXT,
      locality TEXT NOT NULL,
      ward_no INTEGER NOT NULL DEFAULT 1,
      location_confidence REAL DEFAULT 0.95,
      status TEXT NOT NULL DEFAULT 'Submitted',
      priority TEXT NOT NULL DEFAULT 'Medium',
      priority_score INTEGER DEFAULT 50,
      priority_reasons TEXT, -- JSON array
      department_id TEXT,
      assigned_officer_id TEXT,
      sla_deadline TEXT NOT NULL,
      sla_hours INTEGER NOT NULL DEFAULT 48,
      is_overdue INTEGER DEFAULT 0,
      parent_incident_id TEXT,
      community_confirmations_count INTEGER DEFAULT 1,
      affected_citizens_estimate INTEGER DEFAULT 1,
      infrastructure_asset_id TEXT,
      initial_photo_url TEXT,
      resolution_photo_url TEXT,
      resolution_notes TEXT,
      resolved_at TEXT,
      verified_at TEXT,
      is_disputed INTEGER DEFAULT 0,
      dispute_reason TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (department_id) REFERENCES departments(id),
      FOREIGN KEY (infrastructure_asset_id) REFERENCES infrastructure_entities(id)
    );

    CREATE TABLE IF NOT EXISTS complaint_attachments (
      id TEXT PRIMARY KEY,
      complaint_id TEXT NOT NULL,
      file_url TEXT NOT NULL,
      file_type TEXT NOT NULL,
      caption TEXT,
      is_resolution_proof INTEGER DEFAULT 0,
      uploaded_by TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS complaint_status_history (
      id TEXT PRIMARY KEY,
      complaint_id TEXT NOT NULL,
      from_status TEXT,
      to_status TEXT NOT NULL,
      notes TEXT,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS community_confirmations (
      id TEXT PRIMARY KEY,
      complaint_id TEXT NOT NULL,
      citizen_id TEXT NOT NULL,
      confirmation_type TEXT NOT NULL,
      comment TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS infrastructure_history (
      id TEXT PRIMARY KEY,
      infrastructure_id TEXT NOT NULL,
      complaint_id TEXT,
      repair_date TEXT NOT NULL,
      contractor TEXT,
      cost_estimate_inr INTEGER,
      failure_cause TEXT,
      evidence_photo_url TEXT,
      FOREIGN KEY (infrastructure_id) REFERENCES infrastructure_entities(id)
    );

    CREATE TABLE IF NOT EXISTS ai_recommendations (
      id TEXT PRIMARY KEY,
      complaint_id TEXT NOT NULL,
      recommended_category TEXT,
      recommended_department TEXT,
      recommended_priority TEXT,
      confidence_score REAL,
      explanation TEXT,
      urgency_detected INTEGER DEFAULT 0,
      overridden_by TEXT,
      override_reason TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS hotspot_records (
      id TEXT PRIMARY KEY,
      locality TEXT NOT NULL,
      category TEXT NOT NULL,
      ward_no INTEGER NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      radius_meters INTEGER NOT NULL DEFAULT 500,
      complaint_count_7d INTEGER NOT NULL,
      surge_percentage REAL NOT NULL,
      severity_level TEXT NOT NULL,
      ai_summary TEXT,
      recommended_action TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS field_operation_groups (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      department_id TEXT NOT NULL,
      assigned_officer_id TEXT,
      complaint_ids TEXT NOT NULL,
      total_distance_km REAL NOT NULL,
      estimated_time_hours REAL NOT NULL,
      efficiency_gain_pct INTEGER NOT NULL,
      status TEXT DEFAULT 'Suggested',
      created_at TEXT NOT NULL,
      FOREIGN KEY (department_id) REFERENCES departments(id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      target_role TEXT NOT NULL DEFAULT 'all',
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      complaint_id TEXT,
      type TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      event_type TEXT NOT NULL,
      complaint_id TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      hash_signature TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS privacy_requests (
      id TEXT PRIMARY KEY,
      citizen_id TEXT NOT NULL,
      citizen_name TEXT NOT NULL,
      request_type TEXT NOT NULL,
      details TEXT NOT NULL,
      status TEXT DEFAULT 'Pending',
      response_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS citizen_feedback (
      id TEXT PRIMARY KEY,
      citizen_id TEXT NOT NULL,
      citizen_name TEXT NOT NULL,
      citizen_email TEXT,
      complaint_id TEXT,
      feedback_type TEXT NOT NULL DEFAULT 'platform', -- 'platform', 'resolution', 'suggestion', 'technical'
      rating INTEGER NOT NULL DEFAULT 5, -- 1 to 5
      message TEXT NOT NULL,
      attachment_url TEXT,
      status TEXT NOT NULL DEFAULT 'New', -- 'New', 'Under Review', 'Responded', 'Closed'
      admin_response TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS weather_alerts (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'WARNING', -- 'CRITICAL', 'WARNING', 'ADVISORY'
      condition TEXT NOT NULL,
      precipitation_forecast_mm REAL DEFAULT 0,
      affected_localities TEXT NOT NULL, -- JSON array
      infrastructure_risk TEXT NOT NULL,
      predicted_impact TEXT NOT NULL,
      preventive_advisory TEXT NOT NULL,
      active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      portal TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS media (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      owner_role TEXT NOT NULL,
      complaint_id TEXT,
      purpose TEXT NOT NULL,
      mime TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      file_name TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS complaint_actions (
      id TEXT PRIMARY KEY,
      complaint_id TEXT NOT NULL,
      action_type TEXT NOT NULL,
      details TEXT,
      visible_to_citizen INTEGER DEFAULT 1,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  // Additive migrations for databases created by earlier versions
  addColumns('profiles', {
    password_salt: 'TEXT', password_hash: 'TEXT',
    preferred_language: "TEXT DEFAULT 'English'", is_active: 'INTEGER DEFAULT 1'
  });
  addColumns('complaints', {
    is_demo: 'INTEGER DEFAULT 0', category_source: "TEXT DEFAULT 'manual'",
    ai_suggested_category: 'TEXT', ai_confidence: 'REAL', escalated_at: 'TEXT',
    reopened_count: 'INTEGER DEFAULT 0', info_requested: 'INTEGER DEFAULT 0'
  });
  addColumns('complaint_attachments', {
    evidence_type: "TEXT DEFAULT 'complaint'", uploaded_by_name: 'TEXT', uploaded_by_role: 'TEXT',
    status_at_upload: 'TEXT', media_id: 'TEXT', is_public: 'INTEGER DEFAULT 0', is_demo: 'INTEGER DEFAULT 0'
  });
  addColumns('citizen_feedback', {
    resolution_rating: 'INTEGER', department_rating: 'INTEGER', work_satisfactory: 'TEXT',
    incomplete_work: 'INTEGER DEFAULT 0', repeated_issue: 'INTEGER DEFAULT 0',
    department_id: 'TEXT', improvement_suggestion: 'TEXT', attachment_media_id: 'TEXT', action_taken: 'TEXT'
  });
  console.log('[DB] Database schema initialized successfully.');
}

function addColumns(table, cols) {
  const existing = new Set(db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name));
  for (const [name, type] of Object.entries(cols)) {
    if (!existing.has(name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
  }
}

module.exports = {
  db,
  initSchema
};
