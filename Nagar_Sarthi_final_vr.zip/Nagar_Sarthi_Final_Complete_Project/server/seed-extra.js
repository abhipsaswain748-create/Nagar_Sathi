// Nagar Sarthi — Seed extensions (idempotent)
// 1. Demo login credentials (hashed) for every seeded account
// 2. Extra roles (field workers linked to the officer roster)
// 3. Clear "demo" flags on seeded records and evidence rows separated by type
// 4. Extra demo complaints covering every lifecycle status and recurring locations
const { hashPassword } = require('./auth');

const DEMO_CITIZEN_PASSWORD = process.env.DEMO_CITIZEN_PASSWORD || 'Citizen@2026';
const DEMO_STAFF_PASSWORD = process.env.DEMO_STAFF_PASSWORD || 'Staff@2026';

const CATEGORY_DEPARTMENT = {
  'Road damage / potholes': 'dept-roads',
  'Garbage accumulation': 'dept-sanitation',
  'Sanitation issues': 'dept-sanitation',
  'Water leakage': 'dept-water',
  'Drainage blockage': 'dept-drainage',
  'Waterlogging / flooding': 'dept-drainage',
  'Streetlight failure': 'dept-electrical',
  'Damaged public infrastructure': 'dept-publicworks',
  'Public safety hazards': 'dept-publicworks',
  'Parks and public spaces': 'dept-publicworks',
  'Other civic problems': 'dept-publicworks'
};

function seedExtra(db) {
  const now = new Date();
  const past = h => new Date(now.getTime() - h * 3600e3).toISOString();
  const future = h => new Date(now.getTime() + h * 3600e3).toISOString();

  // --- Extra staff profiles linked to the officer roster
  const extraProfiles = [
    ['user-field-3', 'Tapan Mohanty', 'tapan.mohanty@field.bmc.gov.in', '+91 94370 33120', 'field_officer', 'dept-drainage', 'Drainage Field Supervisor', 'officer-3'],
    ['user-field-4', 'Bikash Das', 'bikash.das@field.bmc.gov.in', '+91 94370 44871', 'field_officer', 'dept-electrical', 'Street Lighting Field Technician', 'officer-4']
  ];
  for (const p of extraProfiles) {
    if (!db.prepare('SELECT id FROM profiles WHERE id = ?').get(p[0])) {
      db.prepare('INSERT INTO profiles (id, name, email, phone, role, department_id, designation, avatar, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(p[0], p[1], p[2], p[3], p[4], p[5], p[6], null, past(2000));
    }
    db.prepare('UPDATE officers SET profile_id = ? WHERE id = ? AND profile_id IS NULL').run(p[0], p[7]);
  }

  // --- Demo passwords (only set when missing, never overwrite a changed password)
  const noPw = db.prepare('SELECT id, role FROM profiles WHERE password_hash IS NULL').all();
  for (const u of noPw) {
    const { salt, hash } = hashPassword(u.role === 'citizen' ? DEMO_CITIZEN_PASSWORD : DEMO_STAFF_PASSWORD);
    db.prepare('UPDATE profiles SET password_salt = ?, password_hash = ? WHERE id = ?').run(salt, hash, u.id);
  }

  // Production switch: deactivate every seeded demo account
  const seeded = ['user-citizen-1', 'user-citizen-2', 'user-admin-1', 'user-dept-roads', 'user-field-1', 'user-field-2', 'user-field-3', 'user-field-4'];
  const off = process.env.DISABLE_DEMO_ACCOUNTS === 'true';
  for (const id of seeded) db.prepare('UPDATE profiles SET is_active = ? WHERE id = ?').run(off ? 0 : 1, id);
  if (!off) console.log('[SEED] Demo accounts are active (see README). Set DISABLE_DEMO_ACCOUNTS=true before any real deployment.');

  // --- Extra demo complaints (only once)
  const marker = db.prepare("SELECT id FROM complaints WHERE id = 'NS-2026-1101'").get();
  if (!marker) {
    const extra = [
      ['NS-2026-1101', 'user-citizen-2', 'Rajesh Mohanty', 'Garbage accumulation', 'Roadside waste heap', 'Garbage heap near Infocity Circle not cleared for three days', 'Large heap of mixed household waste beside the service road. Stray cattle are spreading it onto the road.', 20.3580, 85.8115, 'Infocity Circle, Patia, Ward 4', 'Infocity Circle', 'Patia', 4, 'Submitted', 'Medium', 58, null, null, 50, 10],
      ['NS-2026-1102', 'user-citizen-1', 'Priyadarshini Jena', 'Streetlight failure', 'Consecutive dark poles', 'Five streetlights dark on Saheed Nagar lane 3', 'Five poles in a row are not working since Sunday. Women returning from work avoid this lane after dark.', 20.2860, 85.8440, 'Lane 3, Saheed Nagar, Ward 30', 'Near Ram Mandir', 'Saheed Nagar', 30, 'Under Review', 'High', 74, 'dept-electrical', null, 30, 20],
      ['NS-2026-1103', 'user-citizen-2', 'Rajesh Mohanty', 'Water leakage', 'Feeder line valve leakage', 'Drinking water pipeline leaking at Damana Square', 'Clean water is gushing from a valve chamber for two days. Road surface is getting damaged.', 20.3228, 85.8199, 'Damana Square, Chandrasekharpur, Ward 11', 'Damana Square', 'Chandrasekharpur', 11, 'Assigned', 'High', 77, 'dept-water', null, 40, 22],
      ['NS-2026-1104', 'user-citizen-1', 'Priyadarshini Jena', 'Waterlogging / flooding', 'Railway underpass flooding', 'Knee-deep water under Rasulgarh underpass after rain', 'Every time it rains the underpass fills with water and two-wheelers get stuck. Same problem as last monsoon.', 20.3018, 85.8662, 'NH-16 Service Road, Rasulgarh Square, Ward 14', 'Rasulgarh Square', 'Rasulgarh', 14, 'Reopened', 'High', 88, 'dept-drainage', 'officer-3', 140, -4],
      ['NS-2026-1105', 'user-citizen-2', 'Rajesh Mohanty', 'Drainage blockage', 'Silt-choked box drain', 'Drain choked with silt near Rasulgarh market', 'Box drain beside the market is completely choked. Dirty water flows onto the road.', 20.3009, 85.8650, 'Rasulgarh Market Road, Ward 14', 'Rasulgarh Square', 'Rasulgarh', 14, 'In Progress', 'Medium', 66, 'dept-drainage', 'officer-3', 60, 12],
      ['NS-2026-1106', 'user-citizen-1', 'Priyadarshini Jena', 'Road damage / potholes', 'Pothole & surface crater', 'Pothole reappeared on Janpath near Ram Mandir', 'The pothole repaired last month has opened again at the same spot.', 20.2845, 85.8428, 'Janpath Rd, Saheed Nagar, Ward 30', 'Near Ram Mandir Traffic Signal', 'Saheed Nagar', 30, 'Resolved', 'High', 80, 'dept-roads', 'officer-1', 400, -100],
      ['NS-2026-1107', 'user-citizen-2', 'Rajesh Mohanty', 'Sanitation issues', 'Open waste water stagnation', 'Stagnant sewage water near Unit 9 Haat', 'Waste water is stagnating behind the haat. Mosquito breeding and foul smell.', 20.2763, 85.8284, 'Bhubaneswar Central Haat, Unit 9, Ward 33', 'Unit 9 Haat', 'Unit 9', 33, 'Disputed', 'Medium', 62, 'dept-sanitation', 'officer-2', 200, -20],
      ['NS-2026-1108', 'user-citizen-1', 'Priyadarshini Jena', 'Other civic problems', 'Fallen tree branch', 'Fallen branch blocking footpath at Nayapalli', 'A large branch fell during the storm and blocks the footpath near IRC Village.', 20.2982, 85.8193, 'IRC Village, Nayapalli, Ward 26', 'IRC Village', 'Nayapalli', 26, 'Submitted', 'Low', 35, null, null, 6, 66]
    ];
    const ins = db.prepare(`INSERT INTO complaints (
      id, tracking_number, citizen_id, citizen_name, citizen_phone, category, subcategory, title, description,
      original_language, latitude, longitude, location_address, landmark, locality, ward_no, location_confidence,
      status, priority, priority_score, priority_reasons, department_id, assigned_officer_id, sla_deadline, sla_hours,
      is_overdue, community_confirmations_count, affected_citizens_estimate, initial_photo_url, is_disputed, dispute_reason,
      is_demo, category_source, reopened_count, created_at, updated_at, resolved_at)
      VALUES (?,?,?,?,?,?,?,?,?, 'English', ?,?,?,?,?,?, 0.9, ?,?,?, '[]', ?,?,?, 48, ?, 1, 20, NULL, ?, ?, 1, 'manual', ?, ?, ?, ?)`);
    for (const c of extra) {
      const [id, cid, cname, cat, sub, title, desc, lat, lon, addr, lm, loc, ward, status, pri, score, dept, off, ageH, slaInH] = c;
      ins.run(id, id, cid, cname, cid === 'user-citizen-1' ? '+91 94371 88201' : '+91 98610 44321', cat, sub, title, desc,
        lat, lon, addr, lm, loc, ward, status, pri, score, dept || CATEGORY_DEPARTMENT[cat], off, future(slaInH),
        slaInH < 0 && !['Resolved'].includes(status) ? 1 : 0,
        status === 'Disputed' ? 1 : 0, status === 'Disputed' ? 'Water was pumped out once but stagnation returned the next day.' : null,
        status === 'Reopened' ? 1 : 0, past(ageH), past(Math.max(1, Math.floor(ageH / 3))), status === 'Resolved' ? past(30) : null);
      db.prepare('INSERT INTO complaint_status_history (id, complaint_id, from_status, to_status, notes, actor_name, actor_role, created_at) VALUES (?,?,?,?,?,?,?,?)')
        .run(`SH-${id}-1`, id, null, 'Submitted', 'Complaint logged by citizen (demo record).', cname, 'citizen', past(ageH));
      if (status !== 'Submitted') {
        db.prepare('INSERT INTO complaint_status_history (id, complaint_id, from_status, to_status, notes, actor_name, actor_role, created_at) VALUES (?,?,?,?,?,?,?,?)')
          .run(`SH-${id}-2`, id, 'Submitted', status, 'Status updated by administrator (demo record).', 'Municipal Administrator', 'admin', past(Math.max(1, Math.floor(ageH / 3))));
      }
    }
    // Historical resolved recurrences for CivicDNA style recurring-history (demo)
    const hist = [
      ['NS-2025-0901', 'Waterlogging / flooding', 'Rasulgarh underpass flooded after heavy rain', 20.3016, 85.8660, 'Rasulgarh', 14, 2400],
      ['NS-2025-0955', 'Waterlogging / flooding', 'Water accumulation at Rasulgarh underpass', 20.3020, 85.8664, 'Rasulgarh', 14, 1800],
      ['NS-2025-1010', 'Road damage / potholes', 'Pothole on Janpath near Ram Mandir', 20.2843, 85.8430, 'Saheed Nagar', 30, 2000],
      ['NS-2025-1077', 'Garbage accumulation', 'Overflowing bin at Infocity Circle', 20.3582, 85.8112, 'Patia', 4, 1500]
    ];
    for (const h of hist) {
      const [id, cat, title, lat, lon, loc, ward, ageH] = h;
      ins.run(id, id, 'user-citizen-2', 'Rajesh Mohanty', '+91 98610 44321', cat, 'Historical record', title, 'Historical demo record used for recurring-issue analysis.',
        lat, lon, `${loc}, Ward ${ward}`, loc, loc, ward, 'Verified / Closed', 'Medium', 50, CATEGORY_DEPARTMENT[cat], null, past(ageH - 48), 0, 0, null, 0, past(ageH), past(ageH - 60), past(ageH - 40));
    }
  }

  // --- Mark original seeded records as demo + convert legacy photo columns into typed evidence rows
  db.prepare("UPDATE complaints SET is_demo = 1 WHERE id LIKE 'NS-2026-10%' OR id LIKE 'NS-2025-%'").run();
  const legacy = db.prepare("SELECT id, citizen_name, initial_photo_url, resolution_photo_url, status FROM complaints WHERE is_demo = 1").all();
  for (const c of legacy) {
    const has = db.prepare('SELECT COUNT(*) n FROM complaint_attachments WHERE complaint_id = ?').get(c.id).n;
    if (has) continue;
    if (c.initial_photo_url && /^https:\/\//.test(c.initial_photo_url)) {
      db.prepare(`INSERT INTO complaint_attachments (id, complaint_id, file_url, file_type, caption, is_resolution_proof, uploaded_by, created_at, evidence_type, uploaded_by_name, uploaded_by_role, status_at_upload, is_public, is_demo)
        VALUES (?,?,?,?,?,0,?,?, 'complaint', ?, 'citizen', 'Submitted', 1, 1)`)
        .run(`ATT-${c.id}-C`, c.id, c.initial_photo_url, 'image', 'Sample photo (demo data)', 'seed', new Date().toISOString(), c.citizen_name);
    }
    if (c.resolution_photo_url && /^https:\/\//.test(c.resolution_photo_url)) {
      db.prepare(`INSERT INTO complaint_attachments (id, complaint_id, file_url, file_type, caption, is_resolution_proof, uploaded_by, created_at, evidence_type, uploaded_by_name, uploaded_by_role, status_at_upload, is_public, is_demo)
        VALUES (?,?,?,?,?,1,?,?, 'completion', 'Field team (demo)', 'field_officer', 'Resolution Submitted', 1, 1)`)
        .run(`ATT-${c.id}-R`, c.id, c.resolution_photo_url, 'image', 'Sample completion photo (demo data)', 'seed', new Date().toISOString());
    }
  }
  // Neutralise a seeded feedback that claimed tested Odia voice recognition
  db.prepare("UPDATE citizen_feedback SET message = 'Being able to report in my own language instead of filling long forms is very useful. Please keep improving it.' WHERE id = 'FB-03'").run();
  db.prepare("UPDATE weather_alerts SET title = title || ' (demo)' WHERE title NOT LIKE '%(demo)'").run();
}

module.exports = { seedExtra, CATEGORY_DEPARTMENT, DEMO_CITIZEN_PASSWORD, DEMO_STAFF_PASSWORD };
