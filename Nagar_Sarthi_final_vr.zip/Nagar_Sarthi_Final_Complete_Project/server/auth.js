// Nagar Sarthi — Authentication, Sessions & Role-Based Access Control
// Passwords: scrypt with per-user salt. Sessions: random 256-bit token in an HttpOnly cookie,
// stored server-side (hashed) with expiry. All permission checks happen on the server.
const crypto = require('node:crypto');

const SESSION_COOKIE = 'ns_session';
const SESSION_TTL_HOURS = Number(process.env.SESSION_TTL_HOURS || 12);

const ROLES = {
  CITIZEN: 'citizen',
  ADMIN: 'admin',
  DEPT: 'dept_officer',
  FIELD: 'field_officer'
};
const STAFF_ROLES = [ROLES.ADMIN, ROLES.DEPT, ROLES.FIELD];
const ADMIN_ROLES = [ROLES.ADMIN, ROLES.DEPT];

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, expectedHash) {
  if (!salt || !expectedHash) return false;
  const { hash } = hashPassword(password, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(expectedHash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function sha256(v) {
  return crypto.createHash('sha256').update(v).digest('hex');
}

function parseCookies(req) {
  const out = {};
  const header = req.headers.cookie || '';
  header.split(';').forEach(part => {
    const idx = part.indexOf('=');
    if (idx > -1) out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  });
  return out;
}

function createSession(db, userId, portal) {
  const token = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_TTL_HOURS * 3600 * 1000);
  db.prepare('INSERT INTO sessions (token_hash, user_id, portal, created_at, expires_at) VALUES (?, ?, ?, ?, ?)')
    .run(sha256(token), userId, portal, now.toISOString(), expires.toISOString());
  return { token, expires };
}

function sessionCookie(token, expires, req) {
  const secure = (req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === 'true') ? '; Secure' : '';
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}${secure}`;
}

function clearCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Expires=Thu, 01 Jan 1970 00:00:00 GMT`;
}

function destroySession(db, req) {
  const token = parseCookies(req)[SESSION_COOKIE];
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
}

// Resolves req.user (or null) from the session cookie.
function resolveUser(db, req) {
  const token = parseCookies(req)[SESSION_COOKIE];
  if (!token) return null;
  const row = db.prepare(`
    SELECT s.portal, s.expires_at, p.id, p.name, p.email, p.phone, p.role, p.department_id,
           p.designation, p.preferred_language, p.is_active
    FROM sessions s JOIN profiles p ON p.id = s.user_id
    WHERE s.token_hash = ?
  `).get(sha256(token));
  if (!row) return null;
  if (new Date(row.expires_at) < new Date() || row.is_active === 0) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    return null;
  }
  // Field officers are linked to an officer roster row
  if (row.role === ROLES.FIELD) {
    const off = db.prepare('SELECT id FROM officers WHERE profile_id = ?').get(row.id);
    row.officer_id = off ? off.id : null;
  }
  delete row.expires_at;
  delete row.is_active;
  return row;
}

// Simple in-memory login throttle (per IP + email) to slow brute force
const attempts = new Map();
function tooManyAttempts(key) {
  const now = Date.now();
  const rec = attempts.get(key) || { count: 0, first: now };
  if (now - rec.first > 15 * 60 * 1000) { attempts.set(key, { count: 0, first: now }); return false; }
  return rec.count >= 8;
}
function recordFailure(key) {
  const now = Date.now();
  const rec = attempts.get(key) || { count: 0, first: now };
  rec.count += 1;
  attempts.set(key, rec);
}
function clearFailures(key) { attempts.delete(key); }

module.exports = {
  ROLES, STAFF_ROLES, ADMIN_ROLES, SESSION_COOKIE,
  hashPassword, verifyPassword, parseCookies,
  createSession, sessionCookie, clearCookie, destroySession, resolveUser,
  tooManyAttempts, recordFailure, clearFailures
};
