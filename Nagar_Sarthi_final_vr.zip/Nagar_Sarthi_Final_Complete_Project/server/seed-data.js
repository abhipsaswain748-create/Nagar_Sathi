// Seed Data for Nagar Sarthi — Bhubaneswar Municipal Corporation (BMC) Demonstration
const crypto = require('node:crypto');

function generateHash(str) {
  return crypto.createHash('sha256').update(str).digest('hex').substring(0, 16);
}

function seedDatabase(db) {
  // Check if data already exists
  const existing = db.prepare('SELECT COUNT(*) as count FROM complaints').get();
  if (existing.count > 0) {
    // Check if feedback needs to be seeded
    const fbCount = db.prepare('SELECT COUNT(*) as count FROM citizen_feedback').get();
    if (fbCount.count === 0) {
      seedFeedbackAndWeather(db);
    }
    console.log(`[DB] Database already contains ${existing.count} complaints.`);
    return;
  }

  console.log('[DB] Seeding demonstration database with Bhubaneswar municipal context...');

  // 1. Seed Departments
  const departments = [
    {
      id: 'dept-roads',
      name: 'Works & Infrastructure Division',
      code: 'WID',
      description: 'Responsible for municipal road repair, pothole filling, pavements, flyovers and pedestrian walkways.',
      sla_hours_default: 48,
      active_head: 'Er. S. Tripathy (Superintending Engineer)',
      phone: '+91 674 253 4101',
      icon: 'Hammer'
    },
    {
      id: 'dept-sanitation',
      name: 'Solid Waste Management & Sanitation',
      code: 'SWM',
      description: 'Door-to-door municipal collection, community waste depots, street sweeping and bio-medical sanitation.',
      sla_hours_default: 24,
      active_head: 'Smt. Ananya Rath (Chief Sanitation Officer)',
      phone: '+91 674 253 4102',
      icon: 'Trash2'
    },
    {
      id: 'dept-drainage',
      name: 'Drainage & Stormwater Sewerage',
      code: 'DSS',
      description: 'Primary, secondary and tertiary stormwater drains, culvert desilting, waterlogging mitigation and canal maintenance.',
      sla_hours_default: 36,
      active_head: 'Er. Debabrata Nayak (Executive Engineer)',
      phone: '+91 674 253 4103',
      icon: 'Waves'
    },
    {
      id: 'dept-water',
      name: 'Public Health Engineering & Water Supply',
      code: 'PHED',
      description: 'Potable water pipelines, tanker emergency supply, borewell maintenance and valve leakage control.',
      sla_hours_default: 24,
      active_head: 'Er. K. C. Pradhan (Divisional Engineer)',
      phone: '+91 674 253 4104',
      icon: 'Droplets'
    },
    {
      id: 'dept-electrical',
      name: 'Electrical & Street Lighting Division',
      code: 'ESLD',
      description: 'LED streetlights, high-mast illumination, junction traffic lights and electrical pole hazard mitigation.',
      sla_hours_default: 24,
      active_head: 'Er. R. K. Mohapatra (Assistant Executive Engineer)',
      phone: '+91 674 253 4105',
      icon: 'Zap'
    },
    {
      id: 'dept-publicworks',
      name: 'Urban Amenities & Public Works',
      code: 'UAPW',
      description: 'Parks, public toilets, bus shelters, municipal boundary walls, footbridges and signage repair.',
      sla_hours_default: 72,
      active_head: 'Er. P. K. Sahoo (Urban Town Planner)',
      phone: '+91 674 253 4106',
      icon: 'Building2'
    }
  ];

  const insertDept = db.prepare(`
    INSERT INTO departments (id, name, code, description, sla_hours_default, active_head, phone, icon)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  departments.forEach(d => {
    insertDept.run(d.id, d.name, d.code, d.description, d.sla_hours_default, d.active_head, d.phone, d.icon);
  });

  // 2. Seed Profiles
  const profiles = [
    {
      id: 'user-citizen-1',
      name: 'Priyadarshini Jena',
      email: 'priyadarshini.jena@odisha.in',
      phone: '+91 94371 88201',
      role: 'citizen',
      department_id: null,
      designation: 'Resident & Community Activist, Saheed Nagar',
      avatar: null,
      created_at: '2026-09-10T08:00:00Z'
    },
    {
      id: 'user-citizen-2',
      name: 'Rajesh Mohanty',
      email: 'rajesh.mohanty@gmail.com',
      phone: '+91 98610 44321',
      role: 'citizen',
      department_id: null,
      designation: 'Resident, Patia Infocity Zone',
      avatar: null,
      created_at: '2026-09-12T09:30:00Z'
    },
    {
      id: 'user-admin-1',
      name: 'Commissioner B. K. Patnaik, IAS',
      email: 'commissioner.bmc@bhubaneswar.gov.in',
      phone: '+91 674 253 4001',
      role: 'admin',
      department_id: null,
      designation: 'Municipal Commissioner, BMC',
      avatar: null,
      created_at: '2026-08-01T08:00:00Z'
    },
    {
      id: 'user-dept-roads',
      name: 'Er. S. Tripathy',
      email: 's.tripathy@bmc.gov.in',
      phone: '+91 94370 21980',
      role: 'dept_officer',
      department_id: 'dept-roads',
      designation: 'Superintending Engineer (Works)',
      avatar: null,
      created_at: '2026-08-05T08:00:00Z'
    },
    {
      id: 'user-field-1',
      name: 'Amit Kumar Rout',
      email: 'amit.rout@field.bmc.gov.in',
      phone: '+91 94374 55012',
      role: 'field_officer',
      department_id: 'dept-roads',
      designation: 'Senior Field Supervisor (Ward 12-16 Unit)',
      avatar: null,
      created_at: '2026-08-10T08:00:00Z'
    },
    {
      id: 'user-field-2',
      name: 'Manoj Behera',
      email: 'manoj.behera@field.bmc.gov.in',
      phone: '+91 98612 88410',
      role: 'field_officer',
      department_id: 'dept-sanitation',
      designation: 'Sanitation Rapid Response Lead (North Zone)',
      avatar: null,
      created_at: '2026-08-10T08:00:00Z'
    }
  ];

  const insertProfile = db.prepare(`
    INSERT INTO profiles (id, name, email, phone, role, department_id, designation, avatar, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  profiles.forEach(p => {
    insertProfile.run(p.id, p.name, p.email, p.phone, p.role, p.department_id, p.designation, p.avatar, p.created_at);
  });

  // 3. Seed Officers
  const officers = [
    {
      id: 'officer-1',
      profile_id: 'user-field-1',
      department_id: 'dept-roads',
      name: 'Amit Kumar Rout',
      designation: 'Senior Field Supervisor',
      zone: 'Central Zone (Ward 12-16)',
      phone: '+91 94374 55012',
      active_tasks: 4,
      status: 'available'
    },
    {
      id: 'officer-2',
      profile_id: 'user-field-2',
      department_id: 'dept-sanitation',
      name: 'Manoj Behera',
      designation: 'Sanitation Rapid Response Lead',
      zone: 'North Zone (Ward 1-10)',
      phone: '+91 98612 88410',
      active_tasks: 3,
      status: 'available'
    },
    {
      id: 'officer-3',
      profile_id: null,
      department_id: 'dept-drainage',
      name: 'Tapan Mohanty',
      designation: 'Drainage Jetting Machine Operator',
      zone: 'South Zone (Ward 20-35)',
      phone: '+91 94380 99120',
      active_tasks: 5,
      status: 'busy'
    },
    {
      id: 'officer-4',
      profile_id: null,
      department_id: 'dept-electrical',
      name: 'Bikash Das',
      designation: 'Electrical Lineman & Light Tech',
      zone: 'Central Zone (Ward 15-28)',
      phone: '+91 98611 33290',
      active_tasks: 2,
      status: 'available'
    }
  ];

  const insertOfficer = db.prepare(`
    INSERT INTO officers (id, profile_id, department_id, name, designation, zone, phone, active_tasks, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  officers.forEach(o => {
    insertOfficer.run(o.id, o.profile_id, o.department_id, o.name, o.designation, o.zone, o.phone, o.active_tasks, o.status);
  });

  // 4. Seed Infrastructure Entities (CivicDNA)
  const infrastructure = [
    {
      id: 'ASSET-RD-702',
      name: 'Janpath Road - Master Canteen to Ram Mandir Arterial Stretch',
      type: 'road',
      locality: 'Saheed Nagar / Unit 3',
      ward_no: 30,
      latitude: 20.2845,
      longitude: 85.8430,
      install_year: 2018,
      last_repaired_date: '2026-06-15',
      total_failures: 4,
      health_index: 54.5,
      preventive_maintenance_recommended: 1,
      notes: 'Sub-base soil compaction issue caused by recurring utility trenching. Prone to deep potholing under heavy commercial bus traffic.'
    },
    {
      id: 'ASSET-DR-410',
      name: 'Rasulgarh Culvert & Siphon Main Drainage Channel No. 10',
      type: 'drainage_culvert',
      locality: 'Rasulgarh Industrial Area',
      ward_no: 14,
      latitude: 20.3012,
      longitude: 85.8655,
      install_year: 2016,
      last_repaired_date: '2026-07-02',
      total_failures: 5,
      health_index: 42.0,
      preventive_maintenance_recommended: 1,
      notes: 'Natural gradient bottleneck. Industrial waste and plastic deposition choke the concrete grating, creating a major flash flood risk on NH-16 service lane.'
    },
    {
      id: 'ASSET-SW-115',
      name: 'Patia KIIT Square Community Secondary Waste Transfer Hub',
      type: 'waste_depot',
      locality: 'Patia',
      ward_no: 6,
      latitude: 20.3540,
      longitude: 85.8180,
      install_year: 2020,
      last_repaired_date: '2026-09-18',
      total_failures: 6,
      health_index: 61.0,
      preventive_maintenance_recommended: 1,
      notes: 'Compact bin capacity overwhelmed by university food stalls and tech park eateries during evening hours. Needs automated compactor installation.'
    },
    {
      id: 'ASSET-SL-884',
      name: 'Nayapalli IRC Village High-Mast Junction & Streetlight Grid',
      type: 'transformer',
      locality: 'Nayapalli',
      ward_no: 26,
      latitude: 20.2980,
      longitude: 85.8190,
      install_year: 2021,
      last_repaired_date: '2026-08-20',
      total_failures: 3,
      health_index: 73.5,
      preventive_maintenance_recommended: 0,
      notes: 'Frequent neutral disconnect during monsoon moisture. Junction box seals need IP67 waterproof replacement.'
    },
    {
      id: 'ASSET-WT-305',
      name: 'Khandagiri Foothills Feeder Pipeline Sluice Valve 4B',
      type: 'water_pipeline',
      locality: 'Khandagiri',
      ward_no: 22,
      latitude: 20.2610,
      longitude: 85.7820,
      install_year: 2017,
      last_repaired_date: '2026-05-10',
      total_failures: 3,
      health_index: 68.0,
      preventive_maintenance_recommended: 0,
      notes: 'High water pressure surge from Naraj intake causes flanged joint leakages periodically.'
    }
  ];

  const insertInfra = db.prepare(`
    INSERT INTO infrastructure_entities (id, name, type, locality, ward_no, latitude, longitude, install_year, last_repaired_date, total_failures, health_index, preventive_maintenance_recommended, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  infrastructure.forEach(inf => {
    insertInfra.run(inf.id, inf.name, inf.type, inf.locality, inf.ward_no, inf.latitude, inf.longitude, inf.install_year, inf.last_repaired_date, inf.total_failures, inf.health_index, inf.preventive_maintenance_recommended, inf.notes);
  });

  // 5. Seed Infrastructure History
  const infraHistory = [
    {
      id: 'IH-01',
      infrastructure_id: 'ASSET-RD-702',
      complaint_id: 'NS-2026-1001',
      repair_date: '2026-06-15',
      contractor: 'M/s Kalinga Bitumen Infrastructure Ltd.',
      cost_estimate_inr: 85000,
      failure_cause: 'Heavy monsoon downpour eroded top asphalt layer after unauthorized fiber optic cable digging.',
      evidence_photo_url: '/assets/civic-road-damage.jpg'
    },
    {
      id: 'IH-02',
      infrastructure_id: 'ASSET-RD-702',
      complaint_id: 'NS-2026-1002',
      repair_date: '2026-02-10',
      contractor: 'BMC Departmental Quick Response Patch Unit',
      cost_estimate_inr: 32000,
      failure_cause: 'Cold mix patch peeled off under city bus braking friction near Ram Mandir signal.',
      evidence_photo_url: '/assets/civic-road-damage.jpg'
    },
    {
      id: 'IH-03',
      infrastructure_id: 'ASSET-DR-410',
      complaint_id: 'NS-2026-1008',
      repair_date: '2026-07-02',
      contractor: 'Utkal Hydro Engineering Works',
      cost_estimate_inr: 120000,
      failure_cause: 'Severe siltation and plastic bag clogs inside the 1200mm siphon box culvert.',
      evidence_photo_url: '/assets/civic-garbage-accumulation.jpg'
    }
  ];

  const insertInfraHist = db.prepare(`
    INSERT INTO infrastructure_history (id, infrastructure_id, complaint_id, repair_date, contractor, cost_estimate_inr, failure_cause, evidence_photo_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  infraHistory.forEach(ih => {
    insertInfraHist.run(ih.id, ih.infrastructure_id, ih.complaint_id, ih.repair_date, ih.contractor, ih.cost_estimate_inr, ih.failure_cause, ih.evidence_photo_url);
  });

  // 6. Seed Complaints with authentic photographic evidence
  const now = new Date();
  const pastHours = (h) => new Date(now.getTime() - h * 3600 * 1000).toISOString();
  const futureHours = (h) => new Date(now.getTime() + h * 3600 * 1000).toISOString();

  const complaints = [
    {
      id: 'NS-2026-1041',
      tracking_number: 'NS-2026-1041',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_phone: '+91 94371 88201',
      category: 'Road damage / potholes',
      subcategory: 'Dangerous deep pothole on arterial road',
      title: 'Dangerous 1.5ft deep crater on Janpath near Ram Mandir Traffic Junction',
      description: 'Massive crater on the left lane heading towards Master Canteen. Two two-wheelers skidded last evening during the rain. Deep pothole with exposed sharp gravel.',
      original_language: 'English',
      audio_url: null,
      transcription: null,
      latitude: 20.2842,
      longitude: 85.8431,
      location_address: 'Janpath Rd, opp. Ram Mandir, Saheed Nagar, Ward 30, Bhubaneswar 751007',
      landmark: 'Near Ram Mandir Traffic Signal',
      locality: 'Saheed Nagar',
      ward_no: 30,
      location_confidence: 0.98,
      status: 'In Progress',
      priority: 'High',
      priority_score: 92,
      priority_reasons: JSON.stringify([
        'High collision and skidding risk for two-wheelers on high-speed arterial road',
        'Directly affects over 4,000 peak hour commuters per hour',
        'Persistent infrastructure failure (CivicDNA records show 4 previous pothole patches at this exact coordinate)'
      ]),
      department_id: 'dept-roads',
      assigned_officer_id: 'officer-1',
      sla_deadline: futureHours(6),
      sla_hours: 48,
      is_overdue: 0,
      parent_incident_id: null,
      community_confirmations_count: 18,
      affected_citizens_estimate: 450,
      infrastructure_asset_id: 'ASSET-RD-702',
      initial_photo_url: '/assets/civic-road-damage.jpg',
      resolution_photo_url: null,
      resolution_notes: null,
      resolved_at: null,
      verified_at: null,
      is_disputed: 0,
      dispute_reason: null,
      created_at: pastHours(42),
      updated_at: pastHours(3)
    },
    {
      id: 'NS-2026-1042',
      tracking_number: 'NS-2026-1042',
      citizen_id: 'user-citizen-2',
      citizen_name: 'Rajesh Mohanty',
      citizen_phone: '+91 98610 44321',
      category: 'Road damage / potholes',
      subcategory: 'Road cave-in near signal',
      title: 'Road broken in front of Ram Mandir gate',
      description: 'Huge hole in the road just 20 meters ahead of the Ram Mandir crossing. Autos swerving dangerously into incoming traffic lane.',
      original_language: 'English',
      audio_url: null,
      transcription: null,
      latitude: 20.2844,
      longitude: 85.8433,
      location_address: 'Opposite Ram Mandir Gate, Janpath, Bhubaneswar',
      landmark: 'Opposite Ram Mandir Gate',
      locality: 'Saheed Nagar',
      ward_no: 30,
      location_confidence: 0.92,
      status: 'In Progress',
      priority: 'High',
      priority_score: 88,
      priority_reasons: JSON.stringify([
        'Confirmed duplicate of parent incident NS-2026-1041 via CivicEcho algorithm (24m spatial proximity)',
        'High safety threat to auto-rickshaws and pedestrians'
      ]),
      department_id: 'dept-roads',
      assigned_officer_id: 'officer-1',
      sla_deadline: futureHours(6),
      sla_hours: 48,
      is_overdue: 0,
      parent_incident_id: 'NS-2026-1041',
      community_confirmations_count: 7,
      affected_citizens_estimate: 210,
      infrastructure_asset_id: 'ASSET-RD-702',
      initial_photo_url: '/assets/civic-road-damage.jpg',
      resolution_photo_url: null,
      resolution_notes: null,
      resolved_at: null,
      verified_at: null,
      is_disputed: 0,
      dispute_reason: null,
      created_at: pastHours(36),
      updated_at: pastHours(3)
    },
    {
      id: 'NS-2026-1025',
      tracking_number: 'NS-2026-1025',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_phone: '+91 94371 88201',
      category: 'Drainage blockage',
      subcategory: 'Industrial canal culvert choke',
      title: 'Complete silt choke of main stormwater siphon near Rasulgarh flyover service road',
      description: 'Solid plastic and silt blockages have completely plugged the concrete box drain. Stormwater is backing up onto the NH-16 service lane and entering local warehouse compounds.',
      original_language: 'Odia',
      audio_url: '/audio/sample-odia-drainage.mp3',
      transcription: 'ରସୁଲଗଡ଼ ପୋଲ ତଳେ ବଡ଼ ଡ୍ରେନ ସମ୍ପୂର୍ଣ୍ଣ ବନ୍ଦ ହୋଇଯାଇଛି। ପାଣି ଜମି ରାସ୍ତାରେ ଚାଲିବା ଅସମ୍ଭବ ହୋଇପଡ଼ିଛି।',
      latitude: 20.3015,
      longitude: 85.8658,
      location_address: 'NH-16 Service Road, Near Cuttack Road Junction, Rasulgarh, Ward 14, Bhubaneswar',
      landmark: 'Near Rasulgarh Overbridge Pillar 14',
      locality: 'Rasulgarh',
      ward_no: 14,
      location_confidence: 0.95,
      status: 'Escalated',
      priority: 'High',
      priority_score: 95,
      priority_reasons: JSON.stringify([
        'Critical flash flood hazard on National Highway corridor',
        'Overdue SLA by 14 hours (CivicForecast breach alert triggered)',
        'Epicenter of CivicPulse Hotspot HP-2026-01'
      ]),
      department_id: 'dept-drainage',
      assigned_officer_id: 'officer-3',
      sla_deadline: pastHours(14),
      sla_hours: 36,
      is_overdue: 1,
      parent_incident_id: null,
      community_confirmations_count: 29,
      affected_citizens_estimate: 850,
      infrastructure_asset_id: 'ASSET-DR-410',
      initial_photo_url: '/assets/civic-garbage-accumulation.jpg',
      resolution_photo_url: null,
      resolution_notes: null,
      resolved_at: null,
      verified_at: null,
      is_disputed: 0,
      dispute_reason: null,
      created_at: pastHours(50),
      updated_at: pastHours(2)
    },
    {
      id: 'NS-2026-1004',
      tracking_number: 'NS-2026-1004',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_phone: '+91 94371 88201',
      category: 'Damaged public infrastructure',
      subcategory: 'Broken concrete drain slab on heritage footpath',
      title: 'Cracked concrete slab with gaping hole on Bindu Sagar parikrama path',
      description: 'Heavy tourist traffic area. Footpath slab had collapsed into the 5-foot deep open stormwater drain. Pilgrim children and senior citizens were at serious injury risk.',
      original_language: 'English',
      audio_url: null,
      transcription: null,
      latitude: 20.2405,
      longitude: 85.8340,
      location_address: 'Bindu Sagar South Bank, Old Town, Ward 58, Bhubaneswar 751002',
      landmark: 'Near Ananta Vasudeva Temple Ghat',
      locality: 'Old Town',
      ward_no: 58,
      location_confidence: 0.99,
      status: 'Verified / Closed',
      priority: 'High',
      priority_score: 86,
      priority_reasons: JSON.stringify([
        'High pedestrian hazard in temple heritage zone with elderly pilgrims',
        'Direct fall hazard into 5ft deep open drain'
      ]),
      department_id: 'dept-publicworks',
      assigned_officer_id: 'officer-1',
      sla_deadline: pastHours(24),
      sla_hours: 48,
      is_overdue: 0,
      parent_incident_id: null,
      community_confirmations_count: 15,
      affected_citizens_estimate: 350,
      infrastructure_asset_id: null,
      initial_photo_url: '/assets/civic-garbage-accumulation.jpg',
      resolution_photo_url: '/assets/civic-road-damage.jpg',
      resolution_notes: 'Replaced collapsed cover with 100mm reinforced precast concrete slab and bitumen edge-sealing. Completed by Unit 12 Field Team under Supervisor Amit Rout.',
      resolved_at: pastHours(18),
      verified_at: pastHours(6),
      is_disputed: 0,
      dispute_reason: null,
      created_at: pastHours(60),
      updated_at: pastHours(6)
    },
    {
      id: 'NS-2026-1009',
      tracking_number: 'NS-2026-1009',
      citizen_id: 'user-citizen-2',
      citizen_name: 'Rajesh Mohanty',
      citizen_phone: '+91 98610 44321',
      category: 'Sanitation issues',
      subcategory: 'Public toilet complex water blockage',
      title: 'Severe drainage overflow and unhygienic conditions at Unit 9 Market Community Toilet',
      description: 'Sewage backup flowing into the walkway outside the vegetable market complex. All three cubicles unusable. Immediate sanitation hazard.',
      original_language: 'English',
      audio_url: null,
      transcription: null,
      latitude: 20.2760,
      longitude: 85.8280,
      location_address: 'Bhubaneswar Central Haat, Unit 9, Ward 33, Bhubaneswar',
      landmark: 'Behind Unit 9 Govt Boys High School',
      locality: 'Unit 9',
      ward_no: 33,
      location_confidence: 0.94,
      status: 'Resolution Submitted',
      priority: 'Medium',
      priority_score: 68,
      priority_reasons: JSON.stringify([
        'Community sanitation and public health compliance',
        'Directly impacts 400+ market vendors and visitors daily'
      ]),
      department_id: 'dept-sanitation',
      assigned_officer_id: 'officer-2',
      sla_deadline: futureHours(14),
      sla_hours: 24,
      is_overdue: 0,
      parent_incident_id: null,
      community_confirmations_count: 8,
      affected_citizens_estimate: 240,
      infrastructure_asset_id: null,
      initial_photo_url: '/assets/civic-garbage-accumulation.jpg',
      resolution_photo_url: '/assets/civic-sanitation-problem.jpg',
      resolution_notes: 'Super-sucker suction vehicle deployed. Cleared 25kg obstruction from main outbound sewer line. Thorough chemical sanitization and washing completed.',
      resolved_at: pastHours(2),
      verified_at: null,
      is_disputed: 0,
      dispute_reason: null,
      created_at: pastHours(22),
      updated_at: pastHours(2)
    },
    {
      id: 'NS-2026-1015',
      tracking_number: 'NS-2026-1015',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_phone: '+91 94371 88201',
      category: 'Damaged public infrastructure',
      subcategory: 'Bus shelter tin sheet dangling',
      title: 'Galvanized tin sheet dangling precariously from Damana Square Mo Bus shelter',
      description: 'High winds loosened the corrugated iron roofing sheet. It is flapping violently over commuters waiting for Route 10 bus.',
      original_language: 'English',
      audio_url: null,
      transcription: null,
      latitude: 20.3225,
      longitude: 85.8195,
      location_address: 'Damana Square, Chandrasekharpur, Ward 11, Bhubaneswar',
      landmark: 'Damana Mo Bus Stop No. 12',
      locality: 'Chandrasekharpur',
      ward_no: 11,
      location_confidence: 0.97,
      status: 'Disputed',
      priority: 'High',
      priority_score: 82,
      priority_reasons: JSON.stringify([
        'Critical injury threat from sharp metallic sheet in windy squall',
        'Citizen disputed previous closure stating only rope tying was done without replacing rusted bolts'
      ]),
      department_id: 'dept-publicworks',
      assigned_officer_id: 'officer-1',
      sla_deadline: futureHours(18),
      sla_hours: 48,
      is_overdue: 0,
      parent_incident_id: null,
      community_confirmations_count: 11,
      affected_citizens_estimate: 280,
      infrastructure_asset_id: null,
      initial_photo_url: '/assets/civic-road-damage.jpg',
      resolution_photo_url: '/assets/civic-sanitation-problem.jpg',
      resolution_notes: 'Initial contractor used nylon binding wire. Citizen inspected and rejected work.',
      resolved_at: null,
      verified_at: null,
      is_disputed: 1,
      dispute_reason: 'Rusted tin sheet was simply tied with plastic cord instead of new structural welding. It started flapping again during today morning rain.',
      created_at: pastHours(72),
      updated_at: pastHours(5)
    }
  ];

  const insertComplaint = db.prepare(`
    INSERT INTO complaints (
      id, tracking_number, citizen_id, citizen_name, citizen_phone, category, subcategory,
      title, description, original_language, audio_url, transcription, latitude, longitude,
      location_address, landmark, locality, ward_no, location_confidence, status, priority,
      priority_score, priority_reasons, department_id, assigned_officer_id, sla_deadline,
      sla_hours, is_overdue, parent_incident_id, community_confirmations_count, affected_citizens_estimate,
      infrastructure_asset_id, initial_photo_url, resolution_photo_url, resolution_notes,
      resolved_at, verified_at, is_disputed, dispute_reason, created_at, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `);

  complaints.forEach(c => {
    insertComplaint.run(
      c.id, c.tracking_number, c.citizen_id, c.citizen_name, c.citizen_phone, c.category, c.subcategory,
      c.title, c.description, c.original_language, c.audio_url, c.transcription, c.latitude, c.longitude,
      c.location_address, c.landmark, c.locality, c.ward_no, c.location_confidence, c.status, c.priority,
      c.priority_score, c.priority_reasons, c.department_id, c.assigned_officer_id, c.sla_deadline,
      c.sla_hours, c.is_overdue, c.parent_incident_id, c.community_confirmations_count, c.affected_citizens_estimate,
      c.infrastructure_asset_id, c.initial_photo_url, c.resolution_photo_url, c.resolution_notes,
      c.resolved_at, c.verified_at, c.is_disputed, c.dispute_reason, c.created_at, c.updated_at
    );
  });

  seedFeedbackAndWeather(db);
  console.log('[DB] Seeding completed successfully.');
}

function seedFeedbackAndWeather(db) {
  const now = new Date();
  const pastHours = (h) => new Date(now.getTime() - h * 3600 * 1000).toISOString();

  // 1. Seed Citizen Feedback
  const feedbacks = [
    {
      id: 'FB-01',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_email: 'priyadarshini.jena@odisha.in',
      complaint_id: 'NS-2026-1004',
      feedback_type: 'resolution',
      rating: 5,
      message: 'The concrete cover replacement on the Bindu Sagar footpath was completed very quickly before the festival crowds arrived. The field team sealed the edges properly. Very satisfied with the transparent photo evidence.',
      attachment_url: null,
      status: 'Closed',
      admin_response: 'Thank you for your verification! The Public Works division has recorded this positive rating.',
      created_at: pastHours(5),
      updated_at: pastHours(4)
    },
    {
      id: 'FB-02',
      citizen_id: 'user-citizen-1',
      citizen_name: 'Priyadarshini Jena',
      citizen_email: 'priyadarshini.jena@odisha.in',
      complaint_id: 'NS-2026-1015',
      feedback_type: 'resolution',
      rating: 2,
      message: 'The contractor merely tied a plastic cord around the flapping tin roof instead of welding new structural bolts. During rain this morning it began flapping dangerously again.',
      attachment_url: null,
      status: 'Under Review',
      admin_response: 'Superintending Engineer has issued re-work order to replace with 4x galvanized structural bolts.',
      created_at: pastHours(4),
      updated_at: pastHours(2)
    },
    {
      id: 'FB-03',
      citizen_id: 'user-citizen-2',
      citizen_name: 'Rajesh Mohanty',
      citizen_email: 'rajesh.mohanty@gmail.com',
      complaint_id: null,
      feedback_type: 'platform',
      rating: 5,
      message: 'The voice recording in Odia and Hindi is fantastic! Being able to speak my issue instead of filling out long government forms is a huge breakthrough for ordinary citizens.',
      attachment_url: null,
      status: 'Responded',
      admin_response: 'Glad to hear! Nagar Sarthi AI is continually improving dialect recognition for Odisha municipal regions.',
      created_at: pastHours(12),
      updated_at: pastHours(6)
    }
  ];

  const insertFeedback = db.prepare(`
    INSERT INTO citizen_feedback (id, citizen_id, citizen_name, citizen_email, complaint_id, feedback_type, rating, message, attachment_url, status, admin_response, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  feedbacks.forEach(f => {
    insertFeedback.run(f.id, f.citizen_id, f.citizen_name, f.citizen_email, f.complaint_id, f.feedback_type, f.rating, f.message, f.attachment_url, f.status, f.admin_response, f.created_at, f.updated_at);
  });

  // 2. Seed Weather-Aware Alerts
  const weatherAlerts = [
    {
      id: 'WEATHER-01',
      title: 'IMD Heavy Rainfall Alert (65mm) — Stormwater Vulnerability Advisory',
      severity: 'CRITICAL',
      condition: 'Localized Pre-Monsoon Cloudburst',
      precipitation_forecast_mm: 65.0,
      affected_localities: JSON.stringify(['Rasulgarh', 'Saheed Nagar', 'Mancheswar']),
      infrastructure_risk: 'Stormwater siphon choke and road sub-base erosion at low-gradient culverts',
      predicted_impact: 'Severe flash waterlogging risk along NH-16 service road and Janpath intersection within next 12 hours.',
      preventive_advisory: 'Pre-position excavator and high-capacity super-sucker pump at Rasulgarh Siphon ASSET-DR-410. Deploy traffic advisory at Saheed Nagar underpass.',
      active: 1,
      created_at: pastHours(2)
    }
  ];

  const insertWeather = db.prepare(`
    INSERT INTO weather_alerts (id, title, severity, condition, precipitation_forecast_mm, affected_localities, infrastructure_risk, predicted_impact, preventive_advisory, active, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  weatherAlerts.forEach(w => {
    insertWeather.run(w.id, w.title, w.severity, w.condition, w.precipitation_forecast_mm, w.affected_localities, w.infrastructure_risk, w.predicted_impact, w.preventive_advisory, w.active, w.created_at);
  });
}

module.exports = {
  seedDatabase
};
