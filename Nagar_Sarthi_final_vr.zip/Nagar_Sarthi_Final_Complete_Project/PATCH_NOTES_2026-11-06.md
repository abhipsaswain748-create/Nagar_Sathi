# Targeted fixes — 6 November 2026

Only the requested screenshot, branding and hotspot-display corrections were applied.

- Replaced the CivicProof before/after sample panel with the three civic photographs supplied by the user.
- Added new cache-busted copies of the exact supplied Nagar Sarthi logo and updated navbar, footer, citizen login, administrator login and favicon references. Replaced the stale legacy SVG logo as well.
- Increased hotspot visibility with solid red outlines and translucent red fills, added centre markers, and enabled hotspot/community overlays by default on the Civic Map.
- Changed recurrence/hotspot clustering to use actual same-domain geographic distance (300 m), avoiding grid-boundary misses.
- Added an honest empty state when there are not yet enough reports to qualify as a hotspot; no hotspot locations are fabricated.


## Civic Map population density and danger-dot update

- Added a ward-level population-density overlay to the public and staff Civic Maps.
- The overlay requests ward boundaries, population counts and polygon area from the Bhubaneswar One / BMC ArcGIS ward-boundary service (layer 4), then calculates people per square kilometre from population divided by mapped ward area.
- Ward polygons are colour-coded by relative density quartiles; selecting a ward shows population, area and calculated density.
- Added a dedicated, default-visible danger layer with pulsing red dots for all Critical and High priority complaint records, separate from the regular category/priority markers.
- Recurring hotspot circles and community incident overlays remain available.
- If the official GIS endpoint cannot be reached, the map falls back only to the published iFOREST finding for Wards 21 and 26 (>700 persons/hectare), and only plots those fallback rings when complaint records provide a ward location. The fallback is labelled as approximate and is not presented as a full ward-density dataset.

Data references:
- Bhubaneswar One / BMC ArcGIS Ward Boundary layer 4: https://bhubaneswarone.in/arcgis/rest/services/BhubaneswarOne/AdministrativeBoundary/MapServer/4
- iFOREST, Bhubaneswar report, ward-wise population-density analysis (Wards 21 and 26 reported above 700 persons/hectare): https://iforest.global/wp-content/uploads/2025/09/IHCAP-Bhubaneswar_Report-for-upload-29082025.pdf
- BMC City Disaster Management Plan 2024–25, demographic context: https://cms.bhubaneswarone.in/uploadDocuments/content/City_Disaster_Management_Plan_BMC_2024.pdf


## v4 — Multilingual reliability and dashboard clarity
- Fixed reversible DOM translation by retaining each text node and translatable attribute’s original source string. Users can switch languages repeatedly in either direction, including back to English.
- Extended translation handling to document-head metadata, image alt text, placeholders, dynamically inserted elements, and map labels.
- Added Hindi and Odia catalogue entries for population-density and danger-layer labels.
- Added a fixed-source, same-origin server proxy for Bhubaneswar One ward GIS data to avoid browser CORS restrictions. The source may still be unavailable when the host network or upstream service is offline.
- Added a population-density overview to the admin dashboard, including the published high-density classification for Wards 21 and 26 and a direct GIS map link.
- Existing photos and branding assets were retained; asset paths were checked against the ZIP contents.
