# Nagar Sarthi

AI-assisted civic grievance platform · Hackathon PS-09 CivicFix · Theme: Civic Tech & Digital Governance · Team: The Phantom Stack

Citizens report civic problems by text or voice in English, Hindi or Odia, with photographs and a location. Municipal staff review, assign, and resolve each complaint with photographic evidence. The complaint closes only after the citizen confirms the problem is fixed, or it goes back for review if they dispute it.

```
Citizen reports → AI suggests a category (citizen confirms) → community grouping → admin assignment
→ field inspection → completion photograph → admin approval → citizen confirms or disputes → feedback
```

## Requirements

- Node.js **22.5 or newer** (uses the built-in `node:sqlite`; no `npm install` needed to run).
- A modern browser. Voice input needs **HTTPS or `localhost`** (see Voice below).

## Start

**Windows (one click):** Double-click `START_NAGAR_SARTHI.bat` in this folder. It checks Node.js, starts the server, waits until it is ready, and opens the website in your default browser. Keep the separate **Nagar Sarthi Server** window open while using the app. If Node.js is missing or too old, install Node.js 22.5 or newer from https://nodejs.org/ and run the launcher again.

```bash
cp .env.example .env      # optional; defaults work for a local demo
npm start                 # or: node server/index.js   (Windows: start.bat, macOS/Linux: ./start.sh)
```

Open http://localhost:3000. On first start the SQLite database (`server/nagar_sarthi.db`) is created and seeded with demonstration data. `npm run reset-db` deletes it so it is re-seeded on the next start.

## Demo accounts (demonstration only)

| Portal | Role | Email | Password |
|---|---|---|---|
| Citizen Login | Citizen | priyadarshini.jena@odisha.in | Citizen@2026 |
| Citizen Login | Citizen | rajesh.mohanty@gmail.com | Citizen@2026 |
| Administrator Portal | Administrator | commissioner.bmc@bhubaneswar.gov.in | Staff@2026 |
| Administrator Portal | Department Official (Roads) | s.tripathy@bmc.gov.in | Staff@2026 |
| Administrator Portal | Field Worker (Roads) | amit.rout@field.bmc.gov.in | Staff@2026 |
| Administrator Portal | Field Worker (Sanitation) | manoj.behera@field.bmc.gov.in | Staff@2026 |

Passwords come from `DEMO_CITIZEN_PASSWORD` / `DEMO_STAFF_PASSWORD` and are stored as scrypt hashes. See [`DEMO_LOGIN_CREDENTIALS.md`](DEMO_LOGIN_CREDENTIALS.md) for the administrator login URL and recovery steps. **Before any real deployment set `DISABLE_DEMO_ACCOUNTS=true`** and create real accounts. Seeded complaints, feedback and photos are labelled "Demo data" in the interface; they are not municipal records.

## Roles and permissions (enforced on the server)

| Role | Can | Cannot |
|---|---|---|
| Citizen | register, report, upload complaint/dispute/feedback photos, see own complaints, reply to information requests, confirm or dispute a resolution, give feedback, confirm other people's public problems | see other citizens' private complaints, assign, change priority or status, upload official evidence, open admin APIs |
| Administrator | everything in the Administrator Portal for all departments, including incident regrouping | close a complaint on the citizen's behalf |
| Department Official | the same for complaints of their own department only | see or move complaints of other departments |
| Field Worker | see assigned tasks, upload inspection / work-in-progress / completion photographs, add remarks | see unassigned tasks, set statuses, close complaints |

Status transitions are validated by the server: completion evidence moves a complaint to *Resolution Submitted*; an administrator approves it to *Resolved (awaiting citizen verification)* only when a completion photograph exists; only the citizen can move it to *Verified / Closed* or *Disputed*; a dispute can be *Reopened* with a recorded reason.

## Main features

- **Homepage**: original layout and the four cards (Report an Issue, Track Progress, Civic Echo Community, Nagar Sarthi AI) kept; separate *Select a Civic Issue Domain* section (11 domains); *Administrator Portal* button top right (in the menu on small screens); pilot badge removed.
- **Reporting**: 5 steps (describe → domain → location → photos → review). The chosen domain is carried in the URL and survives login and language changes. AI suggestion can be accepted, changed or reconsidered; the stored record says whether the citizen chose, accepted or overrode it.
- **Photos**: JPEG/PNG/WEBP, max 5 MB, checked by file content, JPEG location metadata removed, stored outside `public/` and served only after a permission check. Private by default; a citizen can allow the first photo on the public map.
- **Evidence**: before / inspection / during work / after / dispute comparison on every complaint.
- **Tracking**: status tabs (Pending, Reviewed, Assigned, In Progress, Resolved, Disputed, Reopened), real timeline, municipality updates, verification and information-request replies.
- **Administrator Portal**: overview with filters, complaint management (search, sort, pages), full complaint page (review, assign department / field worker, priority with reason, request information, remarks internal or public, escalate, approve or return completion, reopen, reject), SLA & escalation board, departments, field workers, feedback inbox with responses and corrective actions, civic intelligence, GIS map and audit log.
- **Civic map**: Leaflet with marker clustering, filters (domain, status, severity, date, department for staff), street and satellite layers, recurring-hotspot and community-incident layers, legend, list view and an error state. The public map offsets locations by about 100 m and never shows names.
- **Civic Echo Community**: shared incidents, recurring issue history with rule-based maintenance flags, hotspots, public reports and "I face this problem too".
- **Notifications**: bell with unread count, dropdown, mark one / all read; generated for submission, review, assignment, work start, evidence, verification request, dispute, reopening, escalation, information request and feedback responses.
- **Languages**: English, Hindi, Odia across every screen. Choice saved in the browser and in the user profile.

## Translation system

`public/js/i18n.js` uses the English text as the key (gettext style). Translations live in `tools/i18n/*.tsv` (columns: English, Hindi, Odia) and are compiled to `public/js/i18n/hi.js` and `or.js`:

```bash
npm run build:i18n
```

Every rendered screen passes through the catalogue; a MutationObserver translates content added later (toasts, dialogs, map pop-ups). Citizen-written text is marked `translate="no"` and is never altered. The Odia and Hindi text was written for this project and should be reviewed by a native speaker before public use.

## Voice input

1. The citizen chooses the spoken language explicitly (English `en-IN`, Hindi `hi-IN`, Odia `or-IN`); it is independent of the website language.
2. The browser's Web Speech API is used when available (Chrome, Edge). Which languages it accepts depends on the browser.
3. If the browser has no speech service, or reports that the language is not supported or its service is unreachable, the citizen can use the **server fallback**: the page records 16 kHz mono WAV (max 55 s) and `/api/speech/transcribe` sends it to **Azure AI Speech (REST API for short audio)**. Set `AZURE_SPEECH_KEY` and `AZURE_SPEECH_REGION`. Without them the app says that server recognition is not configured.
4. The transcript is always editable and must be confirmed. No transcript, recording or confidence value is ever simulated.

Browsers only allow the microphone on secure pages: `http://localhost` works for local testing; a phone opening `http://192.168.x.x:3000` will be blocked. Use HTTPS (for example a reverse proxy with a certificate, or a tunnel) for phone testing.

## Weather-synchronised risk

`/api/weather/risk` fetches a 3-day forecast from Open-Meteo (no key; free for non-commercial use; CC BY 4.0 attribution) for `DEFAULT_LATITUDE`/`DEFAULT_LONGITUDE`, cached for 30 minutes. Localities with 2 or more waterlogging/drainage complaints in the last 12 months are flagged when forecast rain reaches `RAIN_RISK_THRESHOLD_MM`. If the service cannot be reached the interface shows "unavailable"; no weather values are invented. Set `WEATHER_DISABLED=true` to turn it off.

## AI assistant

Without configuration the assistant is rule-based and labelled as such. It answers in the selected language, looks up only complaints the logged-in user may see, explains SLA, verification and feedback, and can prepare (never submit) a report. Optional: `ANTHROPIC_API_KEY` lets an external model reword the answer; facts still come only from the database.

## Tests

```bash
npm test
```

- `test/security.test.js`: unauthenticated access, removed persona switch, portal separation, HttpOnly cookie and logout invalidation, citizen blocked from admin APIs, ownership, field-worker and department scope, SQL-injection strings, upload type/size/purpose/private access, oversized requests, static path traversal, public-map privacy, login rate limiting.
- `test/workflow.test.js`: complete lifecycle including invalid transitions, priority reasons, information request and reply, inspection and completion evidence, admin approval, citizen dispute with photo, reopening, rework, confirmation, timeline, feedback and official response, notifications privacy, AI grounding, registration and language persistence.
- `test/i18n.test.js`: Hindi and Odia catalogues complete, correct scripts, and every `t('...')` string present.

Each test file starts its own server with a temporary database and upload folder, so the demo database is untouched.

Browser checks (optional, need Python + Playwright): `test/e2e/crawl.py` visits every screen for every role and reports JavaScript errors, horizontal overflow and untranslated text; `test/e2e/interact.py` opens dialogs, forms and the voice recorder.

## Configuration

See `.env.example`. Never commit a real `.env`.

## Rebuilding the CSS

The stylesheet `public/styles/tailwind.css` is pre-built (no CDN needed). After changing classes in the JavaScript views run `npm run build:css` (downloads Tailwind CLI 3.4.17 once through npx).

## Deployment notes

- Serve over HTTPS (needed for microphone and device location; set `COOKIE_SECURE=true` or send `X-Forwarded-Proto: https` from the proxy).
- Set `DISABLE_DEMO_ACCOUNTS=true`, back up `server/nagar_sarthi.db` and the `uploads/` folder.
- Open-Meteo's free tier is for non-commercial use; a commercial deployment needs their paid plan. The Esri satellite layer and OpenStreetMap tiles have their own usage policies.

## Known limitations

- Real speech recognition was not tested end to end in the development environment (no microphone and no Azure key). Odia support in a given browser's built-in speech service is not guaranteed; the Azure fallback lists `or-IN`.
- Live weather could not be reached from the development environment; only the "unavailable" state was tested.
- Password reset by email needs an email service and is not implemented; the login page explains how to get help.
- Demo complaint titles and descriptions are in English because they represent citizen-written text, which is never machine-translated.
- AI classification is keyword based (rule based), not a trained model.
- No live GPS tracking of field workers.
- The previous "CivicRoute" route-bundling screen was removed; it had no real data behind it.


## Latest revision notes

- The official supplied Nagar Sarthi logo is used by the shared navigation and application branding.
- The supplied road-damage, garbage-accumulation and sanitation photographs are stored locally under `public/assets/` and used in the homepage civic examples and seeded demonstration evidence. These are demonstration photographs, not live municipal records.
- Civic map markers now use a consistent priority palette: Critical (red), High (orange), Medium (amber), Low (green), Unassessed (grey). Complaint status remains separate from priority, so a resolved complaint retains its priority colour.
- The map severity filter includes Critical and Unassessed.
- The citizen homepage retains its existing four quick actions and separate civic-domain selection. The Administrator Portal remains a separate top-navigation entry.
- See `DEMO_LOGIN_CREDENTIALS.md` for local administrator access and safe database reset instructions.


### Civic Map layers
The Civic Map includes a ward-level population-density choropleth (official Bhubaneswar One/BMC ward GIS attributes), and a separate pulsing red danger-dot layer for Critical and High complaints. Density values are calculated from the ward population and mapped ward area returned by the GIS service. The map keeps complaint locations and recurring hotspots as separate layers.


## Multilingual and map update (6 November 2026)
- Hindi and Odia translations now preserve each element’s original source text, so switching English → Hindi → Odia → English works repeatedly without leaving the previous language behind.
- Language changes also cover page metadata, placeholders, image alt text, map legends, and dynamically added interface text.
- The Civic Map requests ward population data through a same-origin server endpoint to avoid browser CORS blocks. If the municipal GIS source is offline, the map retains its clearly labelled high-density ward fallback rather than inventing live population counts.
- The administrative dashboard includes a concise population-density overview and a direct link to the GIS map.
