# Nagar Sarthi — Local Jury Demo Login

These are **local demonstration-only credentials** created by the database seed process.

## Administrator Portal

- URL: `http://localhost:3000/#admin-login`
- Email: `commissioner.bmc@bhubaneswar.gov.in`
- Password: `Staff@2026`
- Role: Municipal Administrator

## Login steps

1. Start the project using `start.bat` on Windows.
2. Open `http://localhost:3000`.
3. Select **Administrator Portal** in the top navigation, or open `http://localhost:3000/#admin-login`.
4. Enter the email and password above.
5. Select **Secure login**. A successful login should open the administrator command dashboard.

## If login does not work

1. Confirm the server is running and the terminal has no database startup error.
2. Confirm `.env` does not set `DISABLE_DEMO_ACCOUNTS=true`.
3. For a fresh demo database only, stop the server and run `npm run reset-db`, then start it again. This deletes the local demo database and re-seeds it.
4. Do not reset a database containing records you need to keep.

The seeded demo password is configured through `DEMO_STAFF_PASSWORD`; its default is `Staff@2026`. Passwords are stored as scrypt hashes, not plaintext.

**Security:** These credentials are for a local jury demonstration only. Do not use them on a public production deployment. Set `DISABLE_DEMO_ACCOUNTS=true` and provision separate administrator accounts before deployment.
