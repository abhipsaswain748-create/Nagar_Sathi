// Account settings: profile, language (saved to profile), theme, password change, personal data export
import { state } from '../state.js';
import { api } from '../api.js';
import { Icons } from '../icons.js';
import { LANGUAGES, getLanguage, t } from '../i18n.js';
import { esc, iconSm, roleLabel } from '../ui.js';
import { showToast } from '../components/toast.js';

export async function renderSettingsView() {
  const user = state.currentUser;
  const dark = document.documentElement.classList.contains('dark');
  window.__afterRender = wire;
  return `<div class="max-w-4xl mx-auto px-4 py-8 w-full space-y-5">
    <h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Account settings</h1>
    <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold mb-3">Profile</h2>
      <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
        <div><dt class="text-[11px] text-slate-500">Name</dt><dd class="font-semibold" translate="no">${esc(user.name)}</dd></div>
        <div><dt class="text-[11px] text-slate-500">Email</dt><dd translate="no">${esc(user.email)}</dd></div>
        <div><dt class="text-[11px] text-slate-500">Role</dt><dd>${roleLabel(user.role)}</dd></div>
        <div><dt class="text-[11px] text-slate-500">Mobile number</dt><dd translate="no">${esc(user.phone || '-')}</dd></div>
      </dl></section>
    <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold mb-1">Language</h2>
      <p class="text-xs text-slate-500 mb-3">Used for the whole website and the AI assistant. It is saved to your account and on this device.</p>
      <div class="grid grid-cols-3 gap-2">${LANGUAGES.map(l => `<button class="py-2.5 rounded-xl border text-sm font-semibold ${getLanguage() === l.code ? 'border-teal-600 bg-teal-50 text-teal-900' : 'border-slate-300'}" aria-pressed="${getLanguage() === l.code}" onclick="window.switchLanguage('${l.code}')" translate="no">${l.label}</button>`).join('')}</div></section>
    <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold mb-3">Display</h2>
      <div class="grid grid-cols-2 gap-2">
        <button class="py-2.5 rounded-xl border text-sm font-semibold flex items-center justify-center gap-2 ${!dark ? 'border-teal-600 bg-teal-50' : 'border-slate-300'}" onclick="window.setThemeMode(false)">${iconSm(Icons.sun, 16)}<span>Light theme</span></button>
        <button class="py-2.5 rounded-xl border text-sm font-semibold flex items-center justify-center gap-2 ${dark ? 'border-teal-600 bg-teal-50' : 'border-slate-300'}" onclick="window.setThemeMode(true)">${iconSm(Icons.moon, 16)}<span>Dark theme</span></button></div></section>
    <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold mb-3">Change password</h2>
      <form id="pw-form" class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end" novalidate>
        <div><label class="ns-label" for="pw-cur">Current password</label><input id="pw-cur" type="password" autocomplete="current-password" class="ns-input" /></div>
        <div><label class="ns-label" for="pw-new">New password</label><input id="pw-new" type="password" autocomplete="new-password" class="ns-input" /></div>
        <button class="btn-primary text-xs py-2.5 px-4">Update password</button></form>
      <p class="text-[11px] text-slate-500 mt-2">At least 8 characters, with letters and numbers.</p></section>
    ${user.role === 'citizen' ? `<section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold mb-1">${iconSm(Icons.shield, 16)} <span>Your data</span></h2>
      <p class="text-xs text-slate-500 mb-3">Download a copy of your profile and the complaints you submitted (JSON file).</p>
      <button class="btn-secondary text-xs py-2 px-4" onclick="window.downloadCitizenDataRecord()">${iconSm(Icons.fileText, 14)}<span>Download my data</span></button></section>` : ''}
  </div>`;
}

function wire() {
  const f = document.getElementById('pw-form');
  if (f) f.onsubmit = async e => {
    e.preventDefault();
    try { await api.changePassword(document.getElementById('pw-cur').value, document.getElementById('pw-new').value); showToast(t('Password updated'), 'success'); f.reset(); }
    catch (ex) { showToast(t(ex.message), 'error'); }
  };
}

window.setThemeMode = dark => {
  document.documentElement.classList.toggle('dark', dark);
  try { localStorage.setItem('ns_theme', dark ? 'dark' : 'light'); } catch (e) {}
  window.rerender();
};

window.downloadCitizenDataRecord = async () => {
  try {
    const u = state.currentUser;
    const res = await api.getComplaints();
    const blob = new Blob([JSON.stringify({ profile: { id: u.id, name: u.name, email: u.email, phone: u.phone }, exported_at: new Date().toISOString(), complaints: res.data }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = `nagar_sarthi_my_data.json`;
    document.body.appendChild(a); a.click(); a.remove();
    showToast(t('Your data file was downloaded.'), 'success');
  } catch (e) { showToast(t(e.message), 'error'); }
};
