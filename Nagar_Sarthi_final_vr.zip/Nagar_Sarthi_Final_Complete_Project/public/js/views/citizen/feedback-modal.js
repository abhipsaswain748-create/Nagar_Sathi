// Citizen Feedback dashboard: submit, pending, my feedback/history, disputed resolutions
import { api } from '../../api.js';
import { Icons } from '../../icons.js';
import { t, fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, emptyState, iconSm, mountUploader } from '../../ui.js';
import { showToast } from '../../components/toast.js';

const TYPES = [['resolution', 'Resolution of my complaint'], ['incomplete_work', 'Incomplete work'], ['repeated_issue', 'Repeated issue'], ['service', 'Service experience'], ['suggestion', 'Suggestion for improvement'], ['platform', 'Website / app experience']];
const FSTATUS = { 'New': 'Received', 'Under Review': 'Under Review', 'Responded': 'Responded', 'Action Taken': 'Action Taken', 'Closed': 'Closed' };

function stars(name, value = 0, label = 'Rating') {
  return `<div class="flex gap-1" role="radiogroup" aria-label="${label}">${[1, 2, 3, 4, 5].map(n => `<label class="cursor-pointer">
    <input type="radio" name="${name}" value="${n}" class="sr-only peer" ${value === n ? 'checked' : ''} />
    <span class="block w-8 h-8 rounded-lg border border-slate-300 text-center leading-8 text-sm font-bold peer-checked:bg-amber-400 peer-checked:border-amber-500 peer-focus-visible:ring-2 peer-focus-visible:ring-teal-600" translate="no">${n}</span>
    <span class="sr-only">${n} / 5</span></label>`).join('')}</div>`;
}
const val = n => { const el = document.querySelector(`input[name="${n}"]:checked`); return el ? Number(el.value) : null; };

export async function renderFeedbackView(params = {}) {
  const tab = params.tab || (params.complaint ? 'submit' : 'submit');
  const [fb, mine] = await Promise.all([api.getFeedback(), api.getComplaints()]);
  const disputed = mine.data.filter(c => c.status === 'Disputed' || c.status === 'Reopened');
  const tabs = [['submit', 'Submit Feedback'], ['pending', `Pending Feedback`, fb.pending.length], ['mine', 'My Submitted Feedback', fb.data.length], ['resolved', 'Resolved Complaint Feedback', fb.data.filter(f => f.complaint_id).length], ['disputed', 'Disputed Resolutions', disputed.length], ['history', 'Feedback History']];
  let content = '';
  if (tab === 'submit') {
    const eligible = mine.data.filter(c => ['Resolved', 'Verified / Closed', 'Disputed', 'Reopened', 'In Progress', 'Resolution Submitted'].includes(c.status));
    content = `<form id="fb-form" class="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5" novalidate>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div><label for="fb-type" class="ns-label">Type of feedback *</label><select id="fb-type" class="ns-input">${TYPES.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></div>
        <div><label for="fb-complaint" class="ns-label">Complaint (required for resolution and incomplete work)</label>
          <select id="fb-complaint" class="ns-input"><option value="">No specific complaint</option>${eligible.map(c => `<option value="${esc(c.id)}" ${params.complaint === c.id ? 'selected' : ''} translate="no">${esc(c.id)} · ${esc(c.title.slice(0, 50))}</option>`).join('')}</select></div>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div><span class="ns-label">Overall rating *</span>${stars('fb-rating', 0, 'Overall rating')}</div>
        <div><span class="ns-label">Quality of the resolution</span>${stars('fb-res', 0, 'Quality of the resolution')}</div>
        <div><span class="ns-label">Department's service</span>${stars('fb-dept', 0, "Department's service")}</div>
      </div>
      <fieldset><legend class="ns-label">Was the work satisfactory?</legend><div class="flex flex-wrap gap-3 text-sm">
        ${[['yes', 'Yes'], ['partly', 'Partly'], ['no', 'No']].map(([v, l]) => `<label class="flex items-center gap-1.5"><input type="radio" name="fb-sat" value="${v}" /> <span>${l}</span></label>`).join('')}</div></fieldset>
      <div><label for="fb-msg" class="ns-label">Your comments *</label><textarea id="fb-msg" rows="4" class="ns-input" maxlength="2000"></textarea></div>
      <div><label for="fb-sugg" class="ns-label">Suggestion for improvement (optional)</label><textarea id="fb-sugg" rows="2" class="ns-input" maxlength="1000"></textarea></div>
      <div class="flex flex-col sm:flex-row gap-3 text-sm">
        <label class="flex items-center gap-2"><input type="checkbox" id="fb-incomplete" /> <span>The work was incomplete</span></label>
        <label class="flex items-center gap-2"><input type="checkbox" id="fb-repeat" /> <span>This problem keeps coming back</span></label></div>
      <div><span class="ns-label">Supporting photograph (optional)</span><div id="fb-up"></div></div>
      <p class="text-[11px] text-slate-500">Your feedback is visible only to you and authorised municipal staff. It is never published without your consent.</p>
      <p id="fb-err" class="hidden text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2" role="alert"></p>
      <button class="btn-teal py-2.5 px-6 text-sm font-bold">Submit feedback</button></form>`;
    window.__afterRender = wireForm;
  } else if (tab === 'pending') {
    content = fb.pending.length ? `<div class="space-y-3">${fb.pending.map(c => `<div class="bg-white rounded-xl border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-2">
      <div><div class="text-[11px] text-slate-500">${id(c.id)} · ${date(c.updated_at, false)}</div><div class="text-sm font-semibold">${u(c.title)}</div>${statusPill(c.status)}</div>
      <button class="btn-primary text-xs py-2 px-3" onclick="window.navigate('feedback', {tab: 'submit', complaint: '${esc(c.id)}'})">Give feedback</button></div>`).join('')}</div>`
      : emptyState('No complaints are waiting for your feedback.');
  } else if (tab === 'disputed') {
    content = disputed.length ? `<div class="space-y-3">${disputed.map(c => `<div class="bg-white rounded-xl border border-red-200 p-4">
      <div class="flex flex-wrap items-center justify-between gap-2"><div><div class="text-[11px] text-slate-500">${id(c.id)}</div><div class="text-sm font-semibold">${u(c.title)}</div></div>${statusPill(c.status)}</div>
      ${c.dispute_reason ? `<p class="text-xs text-slate-700 mt-2"><strong>Your reason:</strong> ${u(c.dispute_reason)}</p>` : ''}
      <button class="text-xs font-bold text-teal-700 mt-2" onclick="window.navigate('complaint-detail', {id: '${esc(c.id)}'})">Open complaint →</button></div>`).join('')}</div>`
      : emptyState('You have no disputed resolutions.');
  } else {
    let list = fb.data;
    if (tab === 'resolved') list = list.filter(f => f.complaint_id);
    content = list.length ? `<div class="space-y-3">${list.map(f => `<article class="bg-white rounded-xl border border-slate-200 p-4">
      <div class="flex flex-wrap items-center justify-between gap-2"><div class="text-[11px] text-slate-500">${date(f.created_at)} · ${(TYPES.find(x => x[0] === f.feedback_type) || ['', f.feedback_type])[1]}${f.complaint_id ? ` · ${id(f.complaint_id)}` : ''}</div>
        <span class="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200">${FSTATUS[f.status] || esc(f.status)}</span></div>
      <div class="text-amber-500 text-sm mt-1" aria-label="${f.rating} / 5" translate="no">${'★'.repeat(f.rating)}${'☆'.repeat(5 - f.rating)}</div>
      <p class="text-sm text-slate-800 mt-1">${u(f.message)}</p>
      ${f.attachment_url ? `<img src="${esc(f.attachment_url)}" alt="Feedback photograph" class="w-28 h-20 object-cover rounded-lg mt-2 border" />` : ''}
      ${f.admin_response ? `<div class="mt-2 text-xs bg-teal-50 border border-teal-200 rounded-lg p-2"><strong>Official response:</strong> ${u(f.admin_response)}</div>` : ''}
      ${f.action_taken ? `<div class="mt-1 text-xs bg-emerald-50 border border-emerald-200 rounded-lg p-2"><strong>Action taken:</strong> ${u(f.action_taken)}</div>` : ''}
    </article>`).join('')}</div>` : emptyState('No feedback yet.');
  }
  return `<div class="max-w-5xl mx-auto px-4 py-8 w-full">
    <h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Citizen Feedback</h1>
    <p class="text-xs sm:text-sm text-slate-500 mt-1 mb-5">Rate resolved work, report incomplete work or repeated problems, and see official responses.</p>
    <div class="grid grid-cols-3 gap-3 mb-5">
      <div class="bg-white rounded-xl border border-slate-200 p-3"><div class="text-[11px] text-slate-500">Submitted</div><div class="text-xl font-extrabold" translate="no">${fmtNum(fb.stats.total)}</div></div>
      <div class="bg-white rounded-xl border border-slate-200 p-3"><div class="text-[11px] text-slate-500">Waiting for a response</div><div class="text-xl font-extrabold" translate="no">${fmtNum(fb.stats.awaiting)}</div></div>
      <div class="bg-white rounded-xl border border-slate-200 p-3"><div class="text-[11px] text-slate-500">Pending Feedback</div><div class="text-xl font-extrabold" translate="no">${fmtNum(fb.pending.length)}</div></div>
    </div>
    <div class="flex gap-1.5 overflow-x-auto pb-2 mb-5" role="tablist">${tabs.map(([k, l, n]) => `<button role="tab" aria-selected="${k === tab}" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${k === tab ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200'}" onclick="window.navigate('feedback', {tab: '${k}'})">${l}${n !== undefined ? ` <span translate="no">(${fmtNum(n)})</span>` : ''}</button>`).join('')}</div>
    ${content}</div>`;
}

let up = null;
function wireForm() {
  up = mountUploader(document.getElementById('fb-up'), { purpose: 'feedback', max: 1 });
  document.getElementById('fb-form').onsubmit = async e => {
    e.preventDefault();
    const err = document.getElementById('fb-err'); err.classList.add('hidden');
    const sat = document.querySelector('input[name="fb-sat"]:checked');
    const body = {
      feedback_type: document.getElementById('fb-type').value, complaint_id: document.getElementById('fb-complaint').value || null,
      rating: val('fb-rating'), resolution_rating: val('fb-res'), department_rating: val('fb-dept'), work_satisfactory: sat ? sat.value : null,
      message: document.getElementById('fb-msg').value.trim(), improvement_suggestion: document.getElementById('fb-sugg').value.trim(),
      incomplete_work: document.getElementById('fb-incomplete').checked, repeated_issue: document.getElementById('fb-repeat').checked,
      media_id: up.getIds()[0] || null
    };
    if (!body.rating) { err.textContent = t('Give an overall rating from 1 to 5.'); err.classList.remove('hidden'); return; }
    if (!body.message) { err.textContent = t('Write a short comment.'); err.classList.remove('hidden'); return; }
    if (up.busy()) { err.textContent = t('Please wait until the photos finish uploading.'); err.classList.remove('hidden'); return; }
    try { await api.submitFeedback(body); showToast(t('Thank you. Your feedback was submitted.'), 'success'); window.navigate('feedback', { tab: 'mine' }); }
    catch (ex) { err.textContent = t(ex.message); err.classList.remove('hidden'); }
  };
}
