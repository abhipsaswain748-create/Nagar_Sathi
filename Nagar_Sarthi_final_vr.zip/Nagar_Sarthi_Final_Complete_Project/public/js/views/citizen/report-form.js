// Guided complaint reporting: describe (text or voice) → civic issue domain (manual or AI suggestion
// that the citizen confirms) → location → photographs → review and submit.
// The selected domain comes from the URL (#report-issue?category=...), so it survives navigation,
// login redirects and language changes. It is never silently replaced.
import { api } from '../../api.js';
import { Icons, getCategoryIcon } from '../../icons.js';
import { t, translateDOM } from '../../i18n.js';
import { esc, u, DOMAINS, domainOf, iconSm, mountUploader } from '../../ui.js';
import { openVoiceModal } from '../../components/voice-modal.js';
import { MapPicker } from '../../components/map-picker.js';
import { showToast } from '../../components/toast.js';

const STEPS = ['Describe the problem', 'Civic issue domain', 'Location', 'Photographs', 'Review and submit'];
let draft = null;
let step = 1;
let uploader = null;
let picker = null;

function freshDraft() {
  return {
    title: '', description: '', original_language: 'English', transcription: null, voice_engine: null,
    category: null, category_source: null, ai: null, ai_excluded: [],
    latitude: null, longitude: null, location_address: '', landmark: '', locality: '', ward_no: 0, location_confidence: 0.8, location_source: null,
    photos: [], photos_public: false
  };
}

export async function renderReportFormView(params = {}) {
  if (!draft) { draft = freshDraft(); step = 1; }
  if (params.category && DOMAINS.some(d => d.category === params.category) && draft.category_source !== 'ai') {
    if (draft.category !== params.category) { draft.category = params.category; draft.category_source = 'manual'; }
  }
  const pending = sessionStorage.getItem('ns_report_draft');
  if (pending) {
    sessionStorage.removeItem('ns_report_draft');
    try {
      const p = JSON.parse(pending);
      draft.description = p.description || draft.description;
      if (p.language) { draft.original_language = p.language; draft.transcription = p.transcription || null; draft.voice_engine = 'voice'; }
      draft.ai = null;
    } catch (e) {}
  }
  window.__afterRender = () => paintStep();
  return `
  <div class="max-w-3xl mx-auto px-4 py-8 w-full">
    <div class="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div><h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Report an Issue</h1>
        <p class="text-xs sm:text-sm text-slate-500 mt-1">Type or speak your complaint in English, Hindi or Odia. Nothing is submitted until you confirm on the last step.</p></div>
      <button class="text-xs font-semibold text-slate-500 hover:text-red-700" onclick="window.reportStartOver()">Start over</button>
    </div>
    <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-sm mb-6">
      <ol class="grid grid-cols-5 gap-1" id="rf-steps"></ol>
    </div>
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-8" id="rf-body"></div>
  </div>`;
}

function stepper() {
  return STEPS.map((s, i) => {
    const n = i + 1;
    const cls = n < step ? 'bg-teal-600' : n === step ? 'bg-[#15324B]' : 'bg-slate-200';
    return `<li class="text-center" ${n === step ? 'aria-current="step"' : ''}><div class="h-1.5 rounded-full ${cls}"></div>
      <span class="hidden sm:block text-[11px] mt-1.5 ${n === step ? 'font-bold text-slate-900' : 'text-slate-500'}">${s}</span></li>`;
  }).join('') + `<li class="col-span-5 sm:hidden text-xs font-bold text-slate-800 mt-1">${t('Step {0} of 5').replace('{0}', step)}: ${t(STEPS[step - 1])}</li>`;
}

function domainButtons(selected) {
  return `<div class="grid grid-cols-1 sm:grid-cols-2 gap-2" role="radiogroup" aria-label="Civic issue domain">${DOMAINS.map(d => {
    const on = d.category === selected;
    return `<button type="button" role="radio" aria-checked="${on}" class="flex items-center gap-3 text-left p-3 rounded-xl border ${on ? 'border-teal-600 bg-teal-50 ring-2 ring-teal-600' : 'border-slate-200 hover:border-teal-400'}" onclick="window.rfPickDomain('${esc(d.category)}')">
      <span class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${on ? 'bg-teal-600 text-white' : 'bg-slate-100 text-teal-800'}">${d.icon}</span>
      <span><span class="block text-sm font-bold text-slate-900">${d.title}</span><span class="block text-[11px] text-slate-500">${d.category}</span></span></button>`;
  }).join('')}</div>`;
}

function body() {
  if (step === 1) return `
    <h2 class="text-lg font-bold text-slate-900">1. Describe the problem</h2>
    ${draft.category ? `<p class="mt-2 text-xs bg-teal-50 border border-teal-200 text-teal-900 rounded-lg px-3 py-2 inline-flex items-center gap-2">${iconSm(getCategoryIcon(draft.category), 14)}<span>Selected domain:</span> <strong>${esc(domainOf(draft.category).title)}</strong></p>` : ''}
    <div class="mt-4 bg-gradient-to-r from-teal-50 to-cyan-50 border border-teal-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
      <div class="flex items-center gap-3"><div class="w-11 h-11 rounded-xl bg-teal-600 text-white flex items-center justify-center flex-shrink-0">${Icons.microphone}</div>
        <div><div class="text-sm font-bold text-slate-900">Speak instead of typing</div><div class="text-xs text-slate-600">Choose English, Hindi or Odia, record, then check the transcript.</div></div></div>
      <button class="btn-teal py-2.5 px-4 text-xs font-bold whitespace-nowrap" onclick="window.rfVoice()">${Icons.microphone}<span>Record voice</span></button>
    </div>
    ${draft.voice_engine ? `<p class="text-[11px] text-slate-500 mt-2">Transcript from voice. Please check it.</p>` : ''}
    <div class="mt-5"><label for="rf-title" class="ns-label">Short title (optional)</label>
      <input id="rf-title" class="ns-input" maxlength="200" value="${esc(draft.title)}" placeholder="e.g. Deep pothole on Janpath near Ram Mandir" /></div>
    <div class="mt-4"><label for="rf-desc" class="ns-label">What is the problem? *</label>
      <textarea id="rf-desc" rows="5" class="ns-input" maxlength="4000" placeholder="What is broken, since when, and is it dangerous for people or vehicles?">${esc(draft.description)}</textarea>
      <p id="rf-desc-err" class="hidden text-xs text-red-700 mt-1" role="alert">Please describe the problem (at least a few words).</p></div>
    <div class="mt-4"><label for="rf-lang" class="ns-label">Language of your description</label>
      <select id="rf-lang" class="ns-input">${['English', 'Hindi', 'Odia'].map(l => `<option value="${l}" ${draft.original_language === l ? 'selected' : ''} translate="no">${{ English: 'English', Hindi: 'हिन्दी', Odia: 'ଓଡ଼ିଆ' }[l]}</option>`).join('')}</select></div>
    ${nav(false, 'Continue')}`;

  if (step === 2) {
    const ai = draft.ai;
    const aiBox = ai ? (ai.category && !ai.uncertain ? `
        <p class="text-sm text-white">Suggested domain: <strong>${esc(domainOf(ai.category).title)}</strong> <span class="text-slate-300 text-xs">(${esc(ai.category)})</span></p>
        ${ai.evidence && ai.evidence.length ? `<p class="text-[11px] text-slate-300 mt-1">Based on these words in your description: <span translate="no">${ai.evidence.map(esc).join(', ')}</span></p>` : ''}
        ${ai.missing && ai.missing.includes('location') ? '<p class="text-[11px] text-amber-200 mt-1">Missing information: an exact location. You will add it in the next step.</p>' : ''}
        <div class="flex flex-wrap gap-2 mt-3">
          ${draft.category === ai.category ? '<span class="text-xs font-bold text-emerald-300">Accepted</span>' : `<button class="btn-teal text-xs py-1.5 px-3" onclick="window.rfAcceptAI()">Accept suggested domain</button>`}
          <button class="text-xs font-bold text-white border border-white/30 rounded-lg py-1.5 px-3 hover:bg-white/10" onclick="window.rfReconsider()">Ask AI to reconsider</button>
          <span class="text-[11px] text-slate-300 self-center">or choose a domain yourself below</span></div>`
      : `<p class="text-sm text-amber-200">The AI is not sure which domain fits this description. Please choose the domain yourself below.</p>
         ${ai.alternatives && ai.alternatives.length ? `<p class="text-[11px] text-slate-300 mt-1">Possible: ${ai.alternatives.map(c => esc(domainOf(c).title)).join(', ')}</p>` : ''}`)
      : '<p class="text-sm text-slate-300" role="status">Analysing your description...</p>';
    return `
    <h2 class="text-lg font-bold text-slate-900">2. Civic issue domain</h2>
    <p class="text-xs text-slate-500 mt-1">Choose the domain yourself, or use the AI suggestion. The AI only suggests; your choice is what is saved.</p>
    <div class="mt-4 bg-slate-900 rounded-2xl p-4 border border-slate-800">
      <div class="flex items-center gap-2 mb-2 text-teal-300 text-xs font-bold">${iconSm(Icons.aiSparkle, 14)}<span>Nagar Sarthi AI suggestion</span><span class="text-[10px] font-normal text-slate-400">(keyword rules, suggestion only)</span></div>
      <div aria-live="polite">${aiBox}</div>
    </div>
    <div class="mt-5">${domainButtons(draft.category)}</div>
    <p id="rf-cat-err" class="hidden text-xs text-red-700 mt-2" role="alert">Please choose a civic issue domain.</p>
    ${nav(true, 'Continue')}`;
  }

  if (step === 3) return `
    <h2 class="text-lg font-bold text-slate-900">3. Location</h2>
    <p class="text-xs text-slate-500 mt-1">Search a landmark, drag the pin, or use your device location. Your device location is requested only when you press the button.</p>
    <div class="flex flex-col sm:flex-row gap-2 mt-4">
      <div class="flex-1"><label for="rf-landmark" class="sr-only">Landmark</label>
        <input id="rf-landmark" class="ns-input" value="${esc(draft.landmark)}" placeholder="Landmark, e.g. Near Ram Mandir, KIIT Square" /></div>
      <button class="btn-teal text-xs py-2 px-3 whitespace-nowrap" onclick="window.rfFindLandmark()">${iconSm(Icons.search, 14)}<span>Find landmark</span></button>
      <button class="btn-secondary text-xs py-2 px-3 whitespace-nowrap" onclick="window.rfGPS()">${iconSm(Icons.mapPin, 14)}<span>Use my current location</span></button>
    </div>
    <div class="relative rounded-2xl overflow-hidden border border-slate-300 mt-3"><div id="rf-map" style="height: 320px; width: 100%;"></div></div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
      <div class="sm:col-span-2"><label for="rf-address" class="ns-label">Address or description of the place *</label>
        <input id="rf-address" class="ns-input" maxlength="300" value="${esc(draft.location_address)}" placeholder="Street, area, ward" /></div>
      <div><label for="rf-locality" class="ns-label">Locality / area</label><input id="rf-locality" class="ns-input" maxlength="120" value="${esc(draft.locality)}" /></div>
      <div><span class="ns-label">Pin position</span><p id="rf-coords" class="text-xs text-slate-600 py-2" translate="no">${Number.isFinite(draft.latitude) ? `${draft.latitude.toFixed(5)}, ${draft.longitude.toFixed(5)}` : '-'}</p></div>
    </div>
    <p id="rf-loc-err" class="hidden text-xs text-red-700 mt-2" role="alert">Set the location: place the pin on the map or find a landmark, and enter the address.</p>
    ${nav(true, 'Continue')}`;

  if (step === 4) return `
    <h2 class="text-lg font-bold text-slate-900">4. Photographs</h2>
    <p class="text-xs text-slate-500 mt-1">Add up to 4 clear photographs of the problem. Photos are optional but help the field team.</p>
    <div id="rf-uploader" class="mt-4"></div>
    <label class="flex items-start gap-2 mt-4 text-xs text-slate-700"><input type="checkbox" id="rf-public" class="mt-0.5" ${draft.photos_public ? 'checked' : ''} />
      <span>Allow my first photograph to be shown on the public civic map (without my name). If you leave this unticked, photos are seen only by you and municipal staff.</span></label>
    <div class="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600">${iconSm(Icons.shield, 14)} <span>How photos are used: they are attached to this complaint, visible to you and authorised municipal staff, and used as the "before" evidence when the work is checked.</span></div>
    ${nav(true, 'Continue')}`;

  return `
    <h2 class="text-lg font-bold text-slate-900">5. Review and submit</h2>
    <dl class="mt-4 bg-slate-50 rounded-2xl border border-slate-200 p-5 space-y-3 text-sm">
      <div><dt class="text-[11px] font-bold text-slate-500">Civic issue domain</dt><dd class="font-semibold text-slate-900 flex flex-wrap items-center gap-2">${iconSm(getCategoryIcon(draft.category), 16)}${esc(domainOf(draft.category).title)}
        <span class="text-[11px] font-normal text-slate-500">${draft.category_source === 'ai' ? 'AI suggestion accepted by you' : draft.category_source === 'ai_overridden' ? 'Chosen by you instead of the AI suggestion' : 'Chosen by you'}</span>
        <button class="text-xs text-teal-700 underline" onclick="window.rfGo(2)">Change</button></dd></div>
      <div><dt class="text-[11px] font-bold text-slate-500">Title</dt><dd>${draft.title ? u(draft.title) : '<span class="text-slate-500">Generated from the description</span>'}</dd></div>
      <div><dt class="text-[11px] font-bold text-slate-500">Description</dt><dd class="whitespace-pre-line">${u(draft.description)}</dd></div>
      <div><dt class="text-[11px] font-bold text-slate-500">Location</dt><dd>${u(draft.location_address)}${draft.landmark ? ` · ${u(draft.landmark)}` : ''} <button class="text-xs text-teal-700 underline" onclick="window.rfGo(3)">Change</button></dd></div>
      <div><dt class="text-[11px] font-bold text-slate-500">Photographs</dt><dd>${draft.photos.length ? `<div class="flex gap-2 flex-wrap mt-1">${draft.photos.map(p => `<img src="${esc(p.url)}" alt="Attached photograph" class="w-20 h-16 object-cover rounded-lg border" />`).join('')}</div>` : '<span class="text-slate-500">No photographs</span>'}</dd></div>
    </dl>
    <div class="mt-4 p-3 bg-teal-50 border border-teal-200 rounded-xl text-[11px] text-teal-900">${iconSm(Icons.shield, 14)} <span>Your name and phone number are visible only to municipal staff. The public map shows an approximate location (about 100 m) without your name.</span></div>
    <div class="pt-5 mt-5 border-t border-slate-100 flex justify-between gap-2">
      <button class="btn-secondary py-2.5 px-5 text-xs font-bold" onclick="window.rfGo(4)">Back</button>
      <button id="rf-submit" class="btn-teal py-3 px-6 text-sm font-extrabold" onclick="window.rfSubmit()">Confirm and submit complaint</button>
    </div>`;
}

function nav(back, next) {
  return `<div class="pt-5 mt-6 border-t border-slate-100 flex justify-between gap-2">
    ${back ? `<button class="btn-secondary py-2.5 px-5 text-xs font-bold" onclick="window.rfGo(${step - 1})">Back</button>` : '<span></span>'}
    <button class="btn-primary py-2.5 px-6 text-xs font-bold" onclick="window.rfNext()">${next} ${iconSm(Icons.arrowRight, 14)}</button></div>`;
}

function paintStep() {
  const b = document.getElementById('rf-body'); const s = document.getElementById('rf-steps');
  if (!b) return;
  s.innerHTML = stepper();
  b.innerHTML = body();
  translateDOM(s); translateDOM(b);
  if (step === 2 && !draft.ai) runAI(draft.ai_excluded);
  if (step === 3) setupMap();
  if (step === 4) {
    uploader = mountUploader(document.getElementById('rf-uploader'), { purpose: 'complaint', max: 4, initial: draft.photos });
    translateDOM(document.getElementById('rf-uploader'));
  }
}

function setupMap() {
  picker = new MapPicker('rf-map', {
    lat: Number.isFinite(draft.latitude) ? draft.latitude : undefined, lon: Number.isFinite(draft.longitude) ? draft.longitude : undefined,
    onLocationChange: loc => {
      draft.latitude = loc.latitude; draft.longitude = loc.longitude; draft.location_source = loc.source;
      if (loc.confidence) draft.location_confidence = loc.confidence;
      if (loc.address) { draft.location_address = loc.address; const a = document.getElementById('rf-address'); if (a) a.value = loc.address; }
      const c = document.getElementById('rf-coords'); if (c) c.textContent = `${loc.latitude.toFixed(5)}, ${loc.longitude.toFixed(5)}`;
    }
  });
  setTimeout(() => picker.init(), 50);
}

async function runAI(exclude = []) {
  const text = `${draft.title} ${draft.description}`.trim();
  try {
    const r = await api.classify(text, exclude);
    draft.ai = r.data;
    if (r.data.location && !Number.isFinite(draft.latitude)) {
      draft.latitude = r.data.location.lat; draft.longitude = r.data.location.lon;
      draft.landmark = r.data.location.landmark; draft.locality = r.data.location.locality;
      draft.ward_no = r.data.location.ward; draft.location_address = r.data.location.address || '';
      draft.location_source = 'ai-landmark';
    }
  } catch (e) { draft.ai = { category: null, uncertain: true, alternatives: [] }; showToast(t(e.message), 'error'); }
  if (step === 2) paintStep();
}

function collect() {
  if (step === 1) {
    draft.title = document.getElementById('rf-title').value.trim();
    const desc = document.getElementById('rf-desc').value.trim();
    if (desc !== draft.description) { draft.ai = null; draft.ai_excluded = []; }
    draft.description = desc;
    draft.original_language = document.getElementById('rf-lang').value;
    if (desc.split(/\s+/).filter(Boolean).length < 3) { document.getElementById('rf-desc-err').classList.remove('hidden'); document.getElementById('rf-desc').focus(); return false; }
  }
  if (step === 2 && !draft.category) { document.getElementById('rf-cat-err').classList.remove('hidden'); return false; }
  if (step === 3) {
    draft.landmark = document.getElementById('rf-landmark').value.trim();
    draft.location_address = document.getElementById('rf-address').value.trim();
    draft.locality = document.getElementById('rf-locality').value.trim();
    if (!Number.isFinite(draft.latitude) || !draft.location_address) { document.getElementById('rf-loc-err').classList.remove('hidden'); return false; }
  }
  if (step === 4) {
    if (uploader && uploader.busy()) { showToast(t('Please wait until the photos finish uploading.'), 'warning'); return false; }
    draft.photos = uploader ? uploader.getItems() : [];
    draft.photos_public = document.getElementById('rf-public').checked;
  }
  return true;
}

window.rfNext = () => { if (!collect()) return; step = Math.min(5, step + 1); paintStep(); window.scrollTo({ top: 0 }); };
window.rfGo = n => { if (n > step && !collect()) return; if (n < step && step !== 3) { try { collect(); } catch (e) {} } step = n; paintStep(); };
window.rfPickDomain = cat => {
  draft.category = cat;
  draft.category_source = draft.ai && draft.ai.category ? (draft.ai.category === cat ? 'ai' : 'ai_overridden') : 'manual';
  paintStep();
};
window.rfAcceptAI = () => { if (draft.ai && draft.ai.category) { draft.category = draft.ai.category; draft.category_source = 'ai'; paintStep(); } };
window.rfReconsider = () => {
  if (draft.ai && draft.ai.category) draft.ai_excluded.push(draft.ai.category);
  draft.ai = null; paintStep();
};
window.rfVoice = () => openVoiceModal(res => {
  const d = document.getElementById('rf-desc');
  const existing = d ? d.value.trim() : draft.description;
  draft.description = existing ? `${existing}\n${res.transcript}` : res.transcript;
  draft.original_language = res.language; draft.transcription = res.transcript; draft.voice_engine = res.engine;
  draft.ai = null;
  const ti = document.getElementById('rf-title'); if (ti) draft.title = ti.value.trim();
  paintStep();
});
window.rfFindLandmark = async () => {
  const v = document.getElementById('rf-landmark').value.trim();
  if (!v) { showToast(t('Type a landmark first.'), 'warning'); return; }
  const d = picker && await picker.resolveVagueLandmark(v);
  if (d) { draft.landmark = d.landmark; draft.locality = d.locality; draft.ward_no = d.ward; const l = document.getElementById('rf-locality'); if (l) l.value = d.locality; }
};
window.rfGPS = () => picker && picker.detectGPS();
window.reportStartOver = () => { if (confirm(t('Discard this report and start again?'))) { draft = freshDraft(); step = 1; paintStep(); } };

window.rfSubmit = async () => {
  const btn = document.getElementById('rf-submit');
  btn.disabled = true; btn.textContent = t('Submitting...');
  try {
    const r = await api.createComplaint({
      title: draft.title, description: draft.description, category: draft.category, category_source: draft.category_source || 'manual',
      ai_suggested_category: draft.ai && draft.ai.category ? draft.ai.category : null, ai_confidence: draft.ai ? draft.ai.confidence : null,
      original_language: draft.original_language, transcription: draft.transcription,
      latitude: draft.latitude, longitude: draft.longitude, location_address: draft.location_address, landmark: draft.landmark,
      locality: draft.locality, ward_no: draft.ward_no, location_confidence: draft.location_confidence,
      media_ids: draft.photos.map(p => p.id), photos_public: draft.photos_public
    });
    draft = null; step = 1;
    showToast(t('Complaint submitted. Your complaint ID is {0}.').replace('{0}', r.complaintId), 'success', 7000);
    window.refreshNotifications && window.refreshNotifications();
    window.navigate('complaint-detail', { id: r.complaintId });
  } catch (e) {
    showToast(t(e.message), 'error', 7000);
    btn.disabled = false; btn.textContent = t('Confirm and submit complaint');
  }
};
