// Track Progress: the logged-in citizen's own complaints, grouped by status
import { api } from '../../api.js';
import { Icons } from '../../icons.js';
import { esc, u, id, date, statusPill, slaPill, categoryChip, STATUS_GROUPS, emptyState, iconSm } from '../../ui.js';
import { fmtNum } from '../../i18n.js';

const STAGES = ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolution Submitted', 'Resolved', 'Verified / Closed'];
function progressPct(s) {
  if (s === 'Rejected') return 100;
  const map = { Disputed: 4, Reopened: 2, Escalated: 3 };
  const i = map[s] !== undefined ? map[s] : STAGES.indexOf(s);
  return Math.round(((i < 0 ? 0 : i) + 1) / STAGES.length * 100);
}

export async function renderMyComplaintsView(params = {}) {
  const r = await api.getComplaints();
  const all = r.data;
  const group = STATUS_GROUPS.find(g => g.key === params.group) || STATUS_GROUPS[0];
  const list = group.statuses ? all.filter(c => group.statuses.includes(c.status)) : all;
  const q = (params.q || '').toLowerCase();
  const shown = q ? list.filter(c => (c.id + ' ' + c.title + ' ' + c.locality).toLowerCase().includes(q)) : list;
  return `
  <div class="max-w-6xl mx-auto px-4 py-8 w-full">
    <div class="flex flex-wrap items-end justify-between gap-3 mb-5">
      <div><h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Track Progress</h1>
        <p class="text-xs sm:text-sm text-slate-500 mt-1">Every complaint you submitted, with its real status history.</p></div>
      <button class="btn-teal py-2.5 px-4 text-xs font-bold" onclick="window.navigate('report-issue')">${iconSm(Icons.microphone, 16)}<span>Report an Issue</span></button>
    </div>
    <div class="flex gap-1.5 overflow-x-auto pb-2 mb-4" role="tablist" aria-label="Filter by status">
      ${STATUS_GROUPS.map(g => { const n = g.statuses ? all.filter(c => g.statuses.includes(c.status)).length : all.length; if (g.key === 'rejected' && !n) return '';
        return `<button role="tab" aria-selected="${g.key === group.key}" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${g.key === group.key ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200 hover:border-teal-500'}" onclick="window.navigate('my-complaints', {group: '${g.key}'})">${g.label} <span translate="no">(${fmtNum(n)})</span></button>`; }).join('')}
    </div>
    <form class="mb-4" onsubmit="event.preventDefault(); window.navigate('my-complaints', {group: '${group.key}', q: this.q.value})">
      <label for="mc-q" class="sr-only">Search</label>
      <input id="mc-q" name="q" value="${esc(params.q || '')}" class="ns-input max-w-sm" placeholder="Search by ID, title or area" />
    </form>
    ${shown.length ? `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">${shown.map(c => `
      <article class="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col gap-3">
        <div class="flex items-start justify-between gap-2">
          <div class="min-w-0"><div class="text-[11px] text-slate-500">${id(c.id)}</div>
            <h2 class="font-bold text-sm text-slate-900 mt-0.5">${u(c.title)}</h2>${categoryChip(c.category)}</div>
          ${statusPill(c.status)}</div>
        <dl class="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
          <dt class="text-slate-500">Location</dt><dd class="text-slate-800">${u(c.locality)}</dd>
          <dt class="text-slate-500">Submitted</dt><dd>${date(c.created_at, false)}</dd>
          <dt class="text-slate-500">Department</dt><dd class="text-slate-800">${c.department_name ? u(c.department_name) : '<span>Not assigned yet</span>'}</dd>
          <dt class="text-slate-500">Last updated</dt><dd>${date(c.updated_at)}</dd>
          <dt class="text-slate-500">Deadline</dt><dd>${date(c.sla_deadline)}</dd>
        </dl>
        <div><div class="flex justify-between text-[11px] text-slate-500 mb-1"><span>Progress</span>${slaPill(c.sla_state)}</div>
          <div class="h-2 bg-slate-100 rounded-full overflow-hidden" role="progressbar" aria-valuenow="${progressPct(c.status)}" aria-valuemin="0" aria-valuemax="100" aria-label="Progress"><div class="h-2 bg-teal-600" style="width:${progressPct(c.status)}%"></div></div></div>
        ${c.status === 'Resolved' ? '<p class="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-2">Please verify whether the issue is actually resolved.</p>' : ''}
        ${c.info_requested ? '<p class="text-xs font-bold text-sky-800 bg-sky-50 border border-sky-200 rounded-lg p-2">The administration asked for more information.</p>' : ''}
        <button class="btn-secondary text-xs py-2 justify-center" onclick="window.navigate('complaint-detail', {id: '${esc(c.id)}'})">View details and timeline</button>
      </article>`).join('')}</div>`
      : emptyState('No complaints in this list.', all.length ? 'Choose another status filter.' : 'Use Report an Issue to submit your first complaint.')}
  </div>`;
}
