// Complaint details for the citizen who reported it (staff use the admin view).
// Shows real recorded events only, before/during/after evidence, verification and information requests.
import { api } from '../../api.js';
import { state } from '../../state.js';
import { Icons } from '../../icons.js';
import { t } from '../../i18n.js';
import { esc, u, soft, id, date, statusPill, slaPill, categoryChip, evidenceComparison, timeline, mountUploader, iconSm, ACTION_LABEL, domainOf, roleLabel } from '../../ui.js';
import { showToast } from '../../components/toast.js';

const STAGES = [
  ['Submitted', ['Submitted']], ['Reviewed', ['Under Review']], ['Assigned', ['Assigned']], ['Work in Progress', ['In Progress']],
  ['Resolution Submitted', ['Resolution Submitted']], ['Citizen Verification', ['Resolved']], ['Closed', ['Verified / Closed']]
];

export async function renderComplaintDetailView(params) {
  if (state.isStaff()) { setTimeout(() => window.navigate('admin-complaint', { id: params.id }), 0); return ''; }
  const { data: c } = await api.getComplaint(params.id);
  const reached = new Set(c.timeline.map(e => e.to_status));
  const disputed = c.status === 'Disputed' || c.status === 'Reopened';
  window.__afterRender = () => wire(c);
  return `
  <div class="max-w-5xl mx-auto px-4 py-8 w-full space-y-5">
    <button class="text-xs font-semibold text-slate-500 hover:text-slate-800" onclick="window.navigate('my-complaints')">← Back to Track Progress</button>
    <header class="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6">
      <div class="flex flex-wrap items-start justify-between gap-3">
        <div class="min-w-0"><div class="text-xs text-slate-500">${id(c.id)} · <span>Submitted</span> ${date(c.created_at)}</div>
          <h1 class="text-xl sm:text-2xl font-extrabold text-[#15324B] font-heading mt-1">${u(c.title)}</h1>
          <div class="flex flex-wrap items-center gap-2 mt-2">${categoryChip(c.category)} <span class="text-[11px] text-slate-500">(${esc(domainOf(c.category).title)})</span></div></div>
        <div class="flex flex-col items-end gap-1.5">${statusPill(c.status)}${slaPill(c.sla_state)}</div>
      </div>
      <p class="text-sm text-slate-700 mt-4 whitespace-pre-line">${u(c.description)}</p>
      ${c.original_language !== 'English' ? `<p class="text-[11px] text-slate-500 mt-1">Original language: ${esc(c.original_language)}. Your text is kept exactly as you wrote it.</p>` : ''}
      <dl class="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 text-xs">
        <div><dt class="text-slate-500">Location</dt><dd class="font-semibold text-slate-800">${u(c.location_address)}</dd></div>
        <div><dt class="text-slate-500">Department</dt><dd class="font-semibold text-slate-800">${c.department_name ? u(c.department_name) : '<span>Not assigned yet</span>'}</dd></div>
        <div><dt class="text-slate-500">Target resolution (SLA deadline)</dt><dd class="font-semibold text-slate-800">${date(c.sla_deadline)}</dd></div>
      </dl>
    </header>

    <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="prog-h">
      <h2 id="prog-h" class="text-sm font-bold text-slate-900 mb-3">Progress</h2>
      <ol class="grid grid-cols-2 sm:grid-cols-7 gap-2">
        ${STAGES.map(([label, sts]) => { const done = sts.some(s => reached.has(s)); const cur = sts.includes(c.status);
          return `<li class="text-center p-2 rounded-xl border ${cur ? 'border-teal-600 bg-teal-50' : done ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-slate-50'}">
            <span class="block mx-auto w-6 h-6 rounded-full text-[11px] font-bold leading-6 ${done || cur ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-500'}">${done || cur ? '✓' : ''}</span>
            <span class="block text-[11px] mt-1 ${cur ? 'font-bold text-teal-900' : 'text-slate-600'}">${label}</span>${done || cur ? '' : '<span class="sr-only">Not reached</span>'}</li>`; }).join('')}
      </ol>
      ${disputed ? `<p class="mt-3 text-xs text-red-800 bg-red-50 border border-red-200 rounded-lg p-2">${c.status === 'Disputed' ? 'You disputed the resolution. The administration is reviewing it.' : 'This complaint was reopened for more work.'}</p>` : ''}
    </section>

    ${c.can_verify ? `<section id="verify-box" class="bg-amber-50 border-2 border-amber-400 rounded-2xl p-5" aria-labelledby="ver-h">
      <h2 id="ver-h" class="text-base font-bold text-amber-900">Has the issue actually been resolved?</h2>
      <p class="text-xs text-amber-900 mt-1">The authority marked this complaint resolved. Compare the photographs below, then answer.</p>
      <div class="flex flex-wrap gap-2 mt-3">
        <button class="btn-teal text-sm py-2.5 px-4" onclick="window.cdVerify(true)">${iconSm(Icons.checkCircle, 16)}<span>Yes, the issue is resolved</span></button>
        <button class="btn-secondary text-sm py-2.5 px-4 border-red-300 text-red-800" onclick="document.getElementById('dispute-form').classList.remove('hidden')">${iconSm(Icons.x, 16)}<span>No, the issue still exists</span></button>
      </div>
      <div id="dispute-form" class="hidden mt-4 bg-white rounded-xl p-4 border border-amber-200">
        <label for="dispute-reason" class="ns-label">What is still wrong? *</label>
        <textarea id="dispute-reason" rows="3" class="ns-input"></textarea>
        <span class="ns-label mt-3">Supporting photograph (optional)</span><div id="dispute-up"></div>
        <button class="btn-primary text-xs py-2 px-4 mt-3" onclick="window.cdVerify(false)">Send dispute for review</button>
      </div></section>` : ''}

    ${c.info_requested ? `<section class="bg-sky-50 border border-sky-300 rounded-2xl p-5" aria-labelledby="info-h">
      <h2 id="info-h" class="text-sm font-bold text-sky-900">The administration needs more information</h2>
      ${c.actions.filter(a => a.action_type === 'info_requested').slice(-1).map(a => `<p class="text-xs text-sky-900 mt-1">${soft(a.details)}</p>`).join('')}
      <label for="info-reply" class="ns-label mt-3">Your reply</label><textarea id="info-reply" rows="3" class="ns-input"></textarea>
      <span class="ns-label mt-3">Add a photograph (optional)</span><div id="info-up"></div>
      <button class="btn-primary text-xs py-2 px-4 mt-3" onclick="window.cdReply()">Send reply</button></section>` : ''}

    <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="ev-h">
      <h2 id="ev-h" class="text-sm font-bold text-slate-900 mb-3">Photographs: before, during and after</h2>
      ${evidenceComparison(c.attachments)}
    </section>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="tl-h"><h2 id="tl-h" class="text-sm font-bold text-slate-900 mb-3">Status timeline</h2>${timeline(c.timeline)}</section>
      <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="up-h"><h2 id="up-h" class="text-sm font-bold text-slate-900 mb-3">Updates from the municipality</h2>
        ${c.actions.length ? `<ul class="space-y-3">${c.actions.slice().reverse().map(a => `<li class="text-xs border-l-2 border-teal-500 pl-3">
          <div class="font-bold text-slate-800">${ACTION_LABEL[a.action_type] || esc(a.action_type)}</div><div class="text-slate-700">${soft(a.details)}</div>
          <div class="text-[11px] text-slate-500">${u(a.actor_name)} · ${roleLabel(a.actor_role)} · ${date(a.created_at)}</div></li>`).join('')}</ul>` : '<p class="text-xs text-slate-500">No updates yet.</p>'}
      </section>
    </div>

    ${c.can_give_feedback ? `<div class="bg-white rounded-2xl border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-3">
      <p class="text-sm text-slate-700">${c.feedback.length ? 'Thank you, you already gave feedback on this complaint.' : 'How was the resolution? Your feedback helps the department improve.'}</p>
      ${c.feedback.length ? '' : `<button class="btn-primary text-xs py-2 px-4" onclick="window.navigate('feedback', {complaint: '${esc(c.id)}'})">Give feedback</button>`}</div>` : ''}
  </div>`;
}

let disputeUp = null, infoUp = null;
function wire(c) {
  const d = document.getElementById('dispute-up'); if (d) disputeUp = mountUploader(d, { purpose: 'dispute', max: 2 });
  const i = document.getElementById('info-up'); if (i) infoUp = mountUploader(i, { purpose: 'complaint', max: 2 });
  window.cdVerify = async ok => {
    try {
      if (!ok) {
        const reason = document.getElementById('dispute-reason').value.trim();
        if (!reason) { showToast(t('Tell us what is still wrong.'), 'warning'); return; }
        if (disputeUp && disputeUp.busy()) { showToast(t('Please wait until the photos finish uploading.'), 'warning'); return; }
        const r = await api.verify(c.id, false, reason, disputeUp ? disputeUp.getIds() : []);
        showToast(t(r.message), 'success');
      } else {
        if (!confirm(t('Confirm that the problem is fixed? This will close the complaint.'))) return;
        const r = await api.verify(c.id, true);
        showToast(t(r.message), 'success');
      }
      window.refreshNotifications && window.refreshNotifications();
      window.rerender();
    } catch (e) { showToast(t(e.message), 'error'); }
  };
  window.cdReply = async () => {
    const msg = document.getElementById('info-reply').value.trim();
    try { await api.respondInfo(c.id, msg, infoUp ? infoUp.getIds() : []); showToast(t('Reply sent'), 'success'); window.rerender(); }
    catch (e) { showToast(t(e.message), 'error'); }
  };
}
