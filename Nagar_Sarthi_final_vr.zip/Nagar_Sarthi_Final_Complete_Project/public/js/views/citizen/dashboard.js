// Citizen dashboard: one-click voice reporting, action items, status summary and recent complaints
import { api } from '../../api.js';
import { state } from '../../state.js';
import { Icons } from '../../icons.js';
import { esc, u, id, date, statusPill, categoryChip, STATUS_GROUPS, iconSm, emptyState } from '../../ui.js';
import { fmtNum } from '../../i18n.js';
import { openVoiceModal } from '../../components/voice-modal.js';

export async function renderCitizenDashboardView() {
  const r = await api.getComplaints();
  const list = r.data;
  const needVerify = list.filter(c => c.status === 'Resolved');
  const needInfo = list.filter(c => c.info_requested);
  const count = g => g.statuses ? list.filter(c => g.statuses.includes(c.status)).length : list.length;
  const first = esc(state.currentUser.name.split(' ')[0]);
  return `
  <div class="max-w-6xl mx-auto px-4 py-8 w-full space-y-6">
    <div class="bg-gradient-to-r from-[#122B40] to-[#1B3B52] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-5">
      <div><p class="text-xs text-teal-300 font-semibold">My Dashboard</p>
        <h1 class="text-2xl sm:text-3xl font-extrabold font-heading mt-1">Welcome, <span translate="no">${first}</span></h1>
        <p class="text-sm text-slate-300 mt-1">Report a problem by voice or text, and follow every step until it is fixed.</p></div>
      <div class="flex flex-wrap gap-3">
        <button class="btn-teal py-3 px-5 text-sm font-bold shadow-lg" onclick="window.dashVoice()">${Icons.microphone}<span>Report by voice</span></button>
        <button class="btn-secondary py-3 px-5 text-sm font-bold bg-white/10 text-white border-white/20 hover:bg-white/20" onclick="window.navigate('report-issue')">${Icons.fileText}<span>Report by text</span></button>
      </div>
    </div>

    ${needVerify.length || needInfo.length ? `<section class="bg-amber-50 border border-amber-300 rounded-2xl p-5" aria-labelledby="todo-h">
      <h2 id="todo-h" class="text-sm font-bold text-amber-900 flex items-center gap-2">${iconSm(Icons.alertTriangle, 16)}<span>Needs your action</span></h2>
      <ul class="mt-3 space-y-2">
        ${needVerify.map(c => `<li class="flex flex-wrap items-center justify-between gap-2 bg-white rounded-xl p-3 border border-amber-200">
          <span class="text-xs"><strong>Please verify the resolution</strong> · ${id(c.id)} · ${u(c.title)}</span>
          <button class="btn-primary text-xs py-1.5 px-3" onclick="window.navigate('complaint-detail', {id: '${esc(c.id)}'})">Verify now</button></li>`).join('')}
        ${needInfo.map(c => `<li class="flex flex-wrap items-center justify-between gap-2 bg-white rounded-xl p-3 border border-amber-200">
          <span class="text-xs"><strong>More information requested</strong> · ${id(c.id)} · ${u(c.title)}</span>
          <button class="btn-secondary text-xs py-1.5 px-3" onclick="window.navigate('complaint-detail', {id: '${esc(c.id)}'})">Reply</button></li>`).join('')}
      </ul></section>` : ''}

    <section aria-labelledby="sum-h">
      <h2 id="sum-h" class="text-base font-bold text-slate-900 mb-3">My complaints by status</h2>
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        ${STATUS_GROUPS.filter(g => g.key !== 'rejected').map(g => `<button class="bg-white rounded-xl border border-slate-200 p-3 text-left hover:border-teal-500" onclick="window.navigate('my-complaints', {group: '${g.key}'})">
          <div class="text-[11px] font-semibold text-slate-500">${g.label}</div><div class="text-2xl font-extrabold text-[#15324B]" translate="no">${fmtNum(count(g))}</div></button>`).join('')}
      </div>
    </section>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <section class="lg:col-span-2" aria-labelledby="rec-h">
        <div class="flex items-center justify-between mb-3"><h2 id="rec-h" class="text-base font-bold text-slate-900">Recent complaints</h2>
          <button class="text-xs font-bold text-teal-700" onclick="window.navigate('my-complaints')">View all →</button></div>
        ${list.length ? `<div class="space-y-3">${list.slice(0, 5).map(c => `<button class="w-full text-left bg-white rounded-xl border border-slate-200 p-4 hover:border-teal-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2" onclick="window.navigate('complaint-detail', {id: '${esc(c.id)}'})">
            <span class="min-w-0"><span class="text-[11px] text-slate-500">${id(c.id)} · ${date(c.created_at, false)}</span>
            <span class="block font-semibold text-sm text-slate-900 truncate">${u(c.title)}</span>${categoryChip(c.category)}</span>${statusPill(c.status)}</button>`).join('')}</div>`
          : emptyState('You have not reported any problem yet.', 'Use Report by voice or Report by text to submit your first complaint.')}
      </section>
      <aside class="space-y-3" aria-label="Shortcuts">
        ${[['my-complaints', Icons.clock, 'Track Progress', 'Status timeline of every complaint'], ['feedback', Icons.star, 'Feedback', 'Rate resolved work and report problems'],
           ['community-issues', Icons.civicEcho, 'Civic Echo Community', 'Shared and recurring local problems'], ['public-map', Icons.map, 'Civic Map', 'Public reports on the map']].map(([r, ic, ti, d]) =>
          `<button class="w-full text-left bg-white rounded-xl border border-slate-200 p-4 hover:border-teal-500 flex items-center gap-3" onclick="window.navigate('${r}')">
            <span class="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0">${ic}</span><span><span class="block text-sm font-bold text-slate-900">${ti}</span><span class="block text-xs text-slate-500">${d}</span></span></button>`).join('')}
        <button class="w-full text-left bg-white rounded-xl border border-slate-200 p-4 hover:border-teal-500 flex items-center gap-3" onclick="window.toggleAIDrawer(true)">
          <span class="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-800 flex items-center justify-center flex-shrink-0">${Icons.aiSparkle}</span><span><span class="block text-sm font-bold text-slate-900">Nagar Sarthi AI</span><span class="block text-xs text-slate-500">Ask about reporting and your complaints</span></span></button>
      </aside>
    </div>
  </div>`;
}

window.dashVoice = () => openVoiceModal(result => {
  sessionStorage.setItem('ns_report_draft', JSON.stringify({ description: result.transcript, language: result.language, transcription: result.transcript }));
  window.navigate('report-issue');
});
