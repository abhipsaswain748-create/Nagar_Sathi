// Civic Echo Community: shared incidents, recurring issue history, hotspots and public reports.
// Only public, aggregated information is shown (no names, approximate locations).
import { api } from '../../api.js';
import { state } from '../../state.js';
import { Icons } from '../../icons.js';
import { t, fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, categoryChip, demoBadge, emptyState, iconSm, DOMAINS } from '../../ui.js';
import { showToast } from '../../components/toast.js';

export async function renderCommunityView(params = {}) {
  const tab = params.tab || 'incidents';
  const cat = params.category || 'all';
  const [inc, rec, hot, pub] = await Promise.all([api.incidents(), api.recurring({ category: cat }), api.hotspots({ category: cat, days: params.days || 90 }), api.publicMap({ category: cat })]);
  const tabs = [['incidents', 'Shared incidents', inc.data.length], ['recurring', 'Recurring issue history', rec.data.length], ['hotspots', 'Civic hotspots', hot.data.length], ['reports', 'Public reports', pub.data.length]];
  let content = '';
  if (tab === 'incidents') {
    const list = cat === 'all' ? inc.data : inc.data.filter(g => g.category === cat);
    content = `<p class="text-xs text-slate-500 mb-3">${esc(t(inc.meta.rule))}</p>` + (list.length ? `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">${list.map(g => `
      <article class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="flex items-start justify-between gap-2"><div><div class="text-[11px] text-slate-500">${id(g.incident_id)} ${demoBadge(g.is_demo)}</div>
          <h3 class="text-sm font-bold text-slate-900 mt-0.5">${esc(t(g.title))}</h3>${categoryChip(g.category)}</div>${statusPill(g.status)}</div>
        <dl class="grid grid-cols-2 gap-2 mt-3 text-[11px]">
          <div><dt class="text-slate-500">Approximate area</dt><dd class="font-semibold">${esc(t(g.area))}</dd></div>
          <div><dt class="text-slate-500">Department</dt><dd class="font-semibold">${g.department ? esc(t(g.department)) : '-'}</dd></div>
          <div><dt class="text-slate-500">Related complaints</dt><dd class="font-bold text-[#15324B] text-base" translate="no">${fmtNum(g.related_complaints)}</dd></div>
          <div><dt class="text-slate-500">Citizens reporting</dt><dd class="font-bold text-[#15324B] text-base" translate="no">${fmtNum(g.citizens_reporting)}</dd></div>
          <div><dt class="text-slate-500">First report</dt><dd>${date(g.earliest, false)}</dd></div><div><dt class="text-slate-500">Latest report</dt><dd>${date(g.latest, false)}</dd></div>
        </dl>
        ${state.isCitizen() ? `<button class="btn-secondary text-xs py-1.5 px-3 mt-3" onclick="window.echoConfirm('${esc(g.lead_complaint)}')">${iconSm(Icons.thumbsUp, 14)}<span>I face this problem too</span></button>` : ''}
      </article>`).join('')}</div>` : emptyState('No shared incidents right now.'));
  } else if (tab === 'recurring') {
    content = `<p class="text-xs text-slate-500 mb-3">${esc(t(rec.meta.method))}</p>` + (rec.data.length ? `<div class="space-y-3">${rec.data.map(r => `
      <article class="bg-white rounded-2xl border ${r.flag_preventive_maintenance ? 'border-amber-300' : 'border-slate-200'} p-4">
        <div class="flex flex-wrap items-start justify-between gap-2"><div>${categoryChip(r.category)} ${demoBadge(r.is_demo)}<h3 class="text-sm font-bold text-slate-900 mt-1">${u(r.area)}</h3></div>
          <div class="text-right"><div class="text-2xl font-extrabold text-[#15324B]" translate="no">${fmtNum(r.total_reports)}</div><div class="text-[11px] text-slate-500">reports in total</div></div></div>
        <dl class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 text-[11px]">
          <div><dt class="text-slate-500">Last 12 months</dt><dd class="font-semibold" translate="no">${fmtNum(r.reports_last_12_months)}</dd></div>
          <div><dt class="text-slate-500">First reported</dt><dd>${date(r.first_reported, false)}</dd></div>
          <div><dt class="text-slate-500">Last reported</dt><dd>${date(r.last_reported, false)}</dd></div>
          <div><dt class="text-slate-500">Previous resolutions</dt><dd>${r.previous_resolutions.length ? r.previous_resolutions.map(d => date(d, false)).join(', ') : '-'}</dd></div>
          <div class="col-span-2"><dt class="text-slate-500">Current status</dt><dd class="font-semibold">${r.currently_open ? statusPill(r.current_status) : '<span>No open complaint</span>'}</dd></div>
        </dl>
        ${r.flag_preventive_maintenance ? `<p class="mt-3 text-xs bg-amber-50 border border-amber-200 text-amber-900 rounded-lg p-2"><strong>Recommendation (rule-based, not an inspection):</strong> preventive maintenance. <span>${esc(t(r.flag_reason))}</span></p>` : ''}
      </article>`).join('')}</div>` : emptyState('No recurring problems found for this filter.'));
  } else if (tab === 'hotspots') {
    content = `<div class="flex flex-wrap items-center gap-2 mb-3 text-xs"><span class="text-slate-500">${esc(t(hot.meta.method))}</span>
      <label for="hs-days" class="ml-auto font-semibold">Period</label><select id="hs-days" class="ns-input w-auto py-1" onchange="window.navigate('community-issues', {tab: 'hotspots', category: '${esc(cat)}', days: this.value})">
      ${[30, 90, 365].map(d => `<option value="${d}" ${+hot.meta.days === d ? 'selected' : ''}>${t('Last {0} days').replace('{0}', d)}</option>`).join('')}</select></div>
      <div id="hs-map" class="h-72 rounded-2xl border border-slate-200 mb-4 relative"></div>` +
      (hot.data.length ? `<div class="overflow-x-auto"><table class="ns-table bg-white rounded-xl"><thead><tr><th>Area</th><th>Domain</th><th>Complaints</th><th>Open</th><th>High / Medium / Low</th></tr></thead><tbody>
        ${hot.data.map(h => `<tr><td data-label="Area">${u(h.area)} ${demoBadge(h.is_demo)}</td><td data-label="Domain">${categoryChip(h.category)}</td><td data-label="Complaints" translate="no">${fmtNum(h.count)}</td><td data-label="Open" translate="no">${fmtNum(h.open)}</td><td data-label="High / Medium / Low" translate="no">${h.severity.High} / ${h.severity.Medium} / ${h.severity.Low}</td></tr>`).join('')}</tbody></table></div>`
        : emptyState('No hotspots in this period.'));
    window.__afterRender = () => drawHotspots(hot.data);
  } else {
    content = pub.data.length ? `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">${pub.data.filter(p => !['Verified / Closed'].includes(p.status)).map(p => `
      <article class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="flex items-start justify-between gap-2"><div class="min-w-0"><div class="text-[11px] text-slate-500">${id(p.id)} · ${date(p.created_at, false)} ${demoBadge(p.is_demo)}</div>
          <h3 class="text-sm font-bold text-slate-900 mt-0.5">${u(p.title)}</h3>${categoryChip(p.category)}</div>${statusPill(p.status)}</div>
        <p class="text-[11px] text-slate-500 mt-2">${u(p.locality)} · <span>Related reports</span>: <span translate="no">${fmtNum(p.related_reports)}</span></p>
        ${state.isCitizen() ? `<button class="btn-secondary text-xs py-1.5 px-3 mt-3" onclick="window.echoConfirm('${esc(p.id)}')">${iconSm(Icons.thumbsUp, 14)}<span>I face this problem too</span></button>` : ''}
      </article>`).join('')}</div>` : emptyState('No public reports.');
  }
  return `
  <div class="max-w-6xl mx-auto px-4 py-8 w-full">
    <div class="flex flex-wrap items-end justify-between gap-3 mb-5">
      <div><h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Civic Echo Community</h1>
        <p class="text-xs sm:text-sm text-slate-500 mt-1">Problems affecting many people, places where the same problem keeps coming back, and current hotspots. Names and exact addresses are never shown.</p></div>
      <div class="flex items-center gap-2"><label for="ce-cat" class="text-xs font-semibold">Domain</label>
        <select id="ce-cat" class="ns-input w-auto py-1.5 text-xs" onchange="window.navigate('community-issues', {tab: '${tab}', category: this.value})">
          <option value="all">All domains</option>${DOMAINS.map(d => `<option value="${esc(d.category)}" ${cat === d.category ? 'selected' : ''}>${d.title}</option>`).join('')}</select></div>
    </div>
    ${!state.currentUser ? '<p class="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 mb-4">Log in as a citizen to confirm problems you also face.</p>' : ''}
    <div class="flex gap-1.5 overflow-x-auto pb-2 mb-5" role="tablist">
      ${tabs.map(([k, l, n]) => `<button role="tab" aria-selected="${k === tab}" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${k === tab ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200'}" onclick="window.navigate('community-issues', {tab: '${k}', category: '${esc(cat)}'})">${l} <span translate="no">(${fmtNum(n)})</span></button>`).join('')}
    </div>
    ${content}
  </div>`;
}

function drawHotspots(list) {
  const el = document.getElementById('hs-map');
  if (!el || typeof L === 'undefined') return;
  import('../../components/map-picker.js').then(({ addBaseLayers }) => {
    const map = L.map(el).setView([20.2961, 85.8245], 12);
    addBaseLayers(map);
    if (!list.length) {
      el.insertAdjacentHTML('beforeend', '<div class="absolute top-3 left-3 z-[500] rounded-lg bg-white/95 border border-slate-200 px-3 py-2 text-xs text-slate-600 shadow">No qualifying hotspot clusters in this period yet. A hotspot appears when at least two same-domain reports are recorded within approximately 300 m.</div>');
      return;
    }
    const bounds = [];
    list.forEach(h => {
      const point = [Number(h.latitude), Number(h.longitude)];
      if (!Number.isFinite(point[0]) || !Number.isFinite(point[1])) return;
      bounds.push(point);
      const radius = Math.min(520, 180 + Number(h.count || 2) * 55);
      const popup = `<strong>${esc(t(h.category))}</strong><br>${esc(h.area)}<br>${esc(t('Complaints'))}: ${Number(h.count)}`;
      L.circle(point, { radius, color: '#b91c1c', weight: 4, opacity: 1, fillColor: '#ef4444', fillOpacity: 0.34, className: 'ns-hotspot-zone' })
        .addTo(map).bindPopup(popup);
      L.circleMarker(point, { radius: 7, color: '#fff', weight: 2, fillColor: '#b91c1c', fillOpacity: 1 })
        .addTo(map).bindPopup(popup);
    });
    if (bounds.length) map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
  }).catch(() => {
    el.innerHTML = '<div class="h-full flex items-center justify-center p-4 text-sm text-red-700">The hotspot map could not be loaded. Please use the hotspot list below.</div>';
  });
}

window.echoConfirm = async idv => {
  try { const r = await api.confirm(idv, 'affected'); showToast(t(r.message), 'success'); window.rerender(); }
  catch (e) { showToast(t(e.message), 'error'); }
};
