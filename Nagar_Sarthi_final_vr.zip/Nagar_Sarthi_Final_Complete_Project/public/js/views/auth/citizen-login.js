// Citizen login & registration (separate from the staff Administrator Portal)
import { api } from '../../api.js';
import { Icons } from '../../icons.js';
import { LANGUAGES, getLanguage, t } from '../../i18n.js';
import { iconSm } from '../../ui.js';
import { state } from '../../state.js';

export async function renderCitizenLoginView(params = {}) {
  if (state.currentUser) { setTimeout(() => window.goHomeForRole(), 0); return ''; }
  const register = params.mode === 'register';
  const lang = getLanguage();
  window.__afterRender = () => wire(register);
  return `
  <div class="flex-1 flex items-center justify-center px-4 py-10 bg-gradient-to-b from-[#EAF3F2] to-[#F3F6F8]">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8">
      <div class="flex items-center justify-between mb-6">
        <img src="/assets/nagar-sarthi-brand-official-v2.jpg?v=20261106-2" alt="Nagar Sarthi" class="h-12 w-auto max-w-[230px] object-contain" />
        <label class="sr-only" for="login-lang">Language</label>
        <select id="login-lang" translate="no" class="bg-slate-100 border border-slate-300 text-xs font-semibold rounded-lg py-1.5 px-2" onchange="window.switchLanguage(this.value)">
          ${LANGUAGES.map(l => `<option value="${l.code}" ${l.code === lang ? 'selected' : ''}>${l.label}</option>`).join('')}
        </select>
      </div>
      <div class="inline-flex items-center gap-1.5 text-[11px] font-bold text-teal-800 bg-teal-50 border border-teal-200 px-2 py-0.5 rounded-full">${iconSm(Icons.user, 12)}<span>Citizen Portal</span></div>
      <h1 class="text-2xl font-extrabold text-[#15324B] font-heading mt-2">${register ? 'Create a citizen account' : 'Citizen Login'}</h1>
      <p class="text-xs text-slate-500 mt-1">${register ? 'Register to report civic problems and track their progress.' : 'Log in to report civic problems and track your complaints.'}</p>
      <div class="grid grid-cols-2 gap-1 bg-slate-100 p-1 rounded-xl mt-5 text-sm font-semibold" role="tablist">
        <button role="tab" aria-selected="${!register}" class="py-2 rounded-lg ${!register ? 'bg-white shadow text-teal-800' : 'text-slate-600'}" onclick="window.navigate('citizen-login')">Log in</button>
        <button role="tab" aria-selected="${register}" class="py-2 rounded-lg ${register ? 'bg-white shadow text-teal-800' : 'text-slate-600'}" onclick="window.navigate('citizen-register')">Register</button>
      </div>
      <form id="cit-form" class="space-y-4 mt-5" novalidate>
        ${register ? `<div><label class="ns-label" for="f-name">Full name *</label><input id="f-name" class="ns-input" autocomplete="name" required /></div>
          <div><label class="ns-label" for="f-phone">Mobile number (optional)</label><input id="f-phone" class="ns-input" type="tel" autocomplete="tel" inputmode="tel" /></div>` : ''}
        <div><label class="ns-label" for="f-email">Email *</label><input id="f-email" class="ns-input" type="email" autocomplete="email" required /></div>
        <div><label class="ns-label" for="f-pass">Password *</label>
          <div class="relative"><input id="f-pass" class="ns-input pr-11" type="password" autocomplete="${register ? 'new-password' : 'current-password'}" required />
          <button type="button" class="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-500" aria-label="Show password" onclick="window.togglePw('f-pass', this)">${iconSm(Icons.eye, 18)}</button></div>
          ${register ? '<p class="text-[11px] text-slate-500 mt-1">At least 8 characters, with letters and numbers.</p>' : ''}</div>
        <p id="f-err" class="hidden text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2" role="alert"></p>
        <button id="f-submit" class="btn-teal w-full py-3 text-sm font-bold justify-center">${register ? 'Create account' : 'Log in'}</button>
      </form>
      ${!register ? `<details class="mt-4 text-xs text-slate-600"><summary class="cursor-pointer font-semibold text-teal-700">Forgot password?</summary>
        <p class="mt-2">Password reset by email needs an email service, which is not configured in this deployment. Please contact the municipal help desk to verify your identity and reset your password. If you are logged in, you can change your password in Account settings.</p></details>` : ''}
      <div class="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
        <span>Municipal staff?</span><button class="font-bold text-[#15324B] hover:underline" onclick="window.navigate('admin-login')">Go to Administrator Portal</button>
      </div>
    </div>
  </div>`;
}

window.togglePw = (id, btn) => {
  const el = document.getElementById(id);
  const show = el.type === 'password';
  el.type = show ? 'text' : 'password';
  btn.setAttribute('aria-label', t(show ? 'Hide password' : 'Show password'));
  btn.innerHTML = iconSm(show ? Icons.eyeOff : Icons.eye, 18);
};

function wire(register) {
  const form = document.getElementById('cit-form');
  if (!form) return;
  form.onsubmit = async e => {
    e.preventDefault();
    const err = document.getElementById('f-err');
    const btn = document.getElementById('f-submit');
    err.classList.add('hidden');
    const email = document.getElementById('f-email').value.trim();
    const password = document.getElementById('f-pass').value;
    const show = m => { err.textContent = t(m); err.classList.remove('hidden'); };
    if (!email || !password) return show('Enter your email and password.');
    if (register && !document.getElementById('f-name').value.trim()) return show('Name, email and password are required.');
    btn.disabled = true;
    try {
      const r = register
        ? await api.register({ name: document.getElementById('f-name').value.trim(), phone: document.getElementById('f-phone').value.trim(), email, password, language: getLanguage() })
        : await api.citizenLogin(email, password, getLanguage());
      await window.afterLogin(r.user);
    } catch (ex) { show(ex.message); }
    finally { btn.disabled = false; }
  };
}
