// Administrator / staff login. Role comes from the server account, never from the browser.
import { api } from '../../api.js';
import { Icons } from '../../icons.js';
import { LANGUAGES, getLanguage, t } from '../../i18n.js';
import { iconSm } from '../../ui.js';
import { state } from '../../state.js';

export async function renderAdminLoginView() {
  if (state.isStaff()) { setTimeout(() => window.goHomeForRole(), 0); return ''; }
  const lang = getLanguage();
  window.__afterRender = wire;
  return `
  <div class="flex-1 flex items-center justify-center px-4 py-10 bg-gradient-to-b from-[#122B40] to-[#1B3B52]">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-300 p-6 sm:p-8">
      <div class="flex items-center justify-between mb-6">
        <img src="/assets/nagar-sarthi-brand-official-v2.jpg?v=20261106-2" alt="Nagar Sarthi" class="h-12 w-auto max-w-[230px] object-contain" />
        <label class="sr-only" for="adm-lang">Language</label>
        <select id="adm-lang" translate="no" class="bg-slate-100 border border-slate-300 text-xs font-semibold rounded-lg py-1.5 px-2" onchange="window.switchLanguage(this.value)">
          ${LANGUAGES.map(l => `<option value="${l.code}" ${l.code === lang ? 'selected' : ''}>${l.label}</option>`).join('')}
        </select>
      </div>
      <div class="inline-flex items-center gap-1.5 text-[11px] font-bold text-white bg-[#15324B] px-2 py-0.5 rounded-full">${iconSm(Icons.shield, 12)}<span>Administrator Portal</span></div>
      <h1 class="text-2xl font-extrabold text-[#15324B] font-heading mt-2">Staff Login</h1>
      <p class="text-xs text-slate-500 mt-1">For municipal administrators, department officials and field workers. Your access depends on the role assigned to your account.</p>
      ${state.isCitizen() ? '<p class="mt-4 text-xs bg-amber-50 border border-amber-300 text-amber-900 rounded-lg p-2" role="alert">You are logged in as a citizen. Citizen accounts cannot open the Administrator Portal. Log out first to sign in with a staff account.</p>' : ''}
      <form id="adm-form" class="space-y-4 mt-5" novalidate>
        <div><label class="ns-label" for="a-email">Official email *</label><input id="a-email" class="ns-input" type="email" autocomplete="username" required /></div>
        <div><label class="ns-label" for="a-pass">Password *</label>
          <div class="relative"><input id="a-pass" class="ns-input pr-11" type="password" autocomplete="current-password" required />
          <button type="button" class="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-500" aria-label="Show password" onclick="window.togglePw('a-pass', this)">${iconSm(Icons.eye, 18)}</button></div></div>
        <p id="a-err" class="hidden text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2" role="alert"></p>
        <button id="a-submit" class="btn-primary w-full py-3 text-sm font-bold justify-center">${iconSm(Icons.lock, 16)}<span>Secure login</span></button>
      </form>
      <p class="text-[11px] text-slate-500 mt-4">Staff accounts are created by an administrator. Sessions expire automatically and every action is recorded in the audit log.</p>
      <div class="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
        <span>Are you a citizen?</span><button class="font-bold text-teal-700 hover:underline" onclick="window.navigate('citizen-login')">Citizen Login</button>
      </div>
    </div>
  </div>`;
}

function wire() {
  const form = document.getElementById('adm-form');
  if (!form) return;
  if (!window.togglePw) import('./citizen-login.js');
  form.onsubmit = async e => {
    e.preventDefault();
    const err = document.getElementById('a-err');
    const btn = document.getElementById('a-submit');
    err.classList.add('hidden');
    const email = document.getElementById('a-email').value.trim();
    const password = document.getElementById('a-pass').value;
    if (!email || !password) { err.textContent = t('Enter your email and password.'); err.classList.remove('hidden'); return; }
    btn.disabled = true;
    try { const r = await api.staffLogin(email, password, getLanguage()); await window.afterLogin(r.user); }
    catch (ex) { err.textContent = t(ex.message); err.classList.remove('hidden'); }
    finally { btn.disabled = false; }
  };
}
