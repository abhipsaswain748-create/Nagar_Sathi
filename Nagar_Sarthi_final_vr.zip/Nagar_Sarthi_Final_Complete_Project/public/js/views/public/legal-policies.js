// Legal, privacy and help information. Statements describe what this software actually does.
// (Earlier text claimed formal DPDP/CERT-In/WCAG "compliance" and IMD weather data; those claims
//  were not verified and have been replaced with factual descriptions.)
import { Icons } from '../../icons.js';
import { iconSm } from '../../ui.js';

const TABS = [
  ['privacy', 'Privacy Policy'], ['terms', 'Terms of Use'], ['data', 'Data Protection'], ['accessibility', 'Accessibility'],
  ['attributions', 'Copyright & Attributions'], ['security', 'Security'], ['cookies', 'Cookies & Sessions'], ['disclaimer', 'AI & Forecast Disclaimer'], ['faq', 'Help & FAQ']
];

const CONTENT = {
  privacy: ['Privacy Policy', [
    'We collect only what is needed to handle a civic complaint: your name, email, optional mobile number, the complaint description, location, and any photographs you upload.',
    'Your name and contact details are visible only to authorised municipal staff, never on public pages.',
    'Complaint photographs are private by default. A photograph appears on the public map only if you tick the option to allow it.',
    'Location data embedded inside JPEG photo files is removed when the photo is uploaded.',
    'On the public map, locations are shifted by about 100 metres so that homes cannot be identified.',
    'Feedback is private and visible only to you and authorised staff.'
  ]],
  terms: ['Terms of Use', [
    'Reports should describe real civic problems such as roads, water, drainage, waste, street lighting, parks or public safety.',
    'Do not submit false, abusive or defamatory content, or photographs of people that are not needed to show the problem.',
    'Community confirmations should only be added for problems that you also face.',
    'Deadlines shown in this demonstration are configurable target times set per department, not legal deadlines.'
  ]],
  data: ['Data Protection', [
    'This project is designed with the principles of India\'s Digital Personal Data Protection Act, 2023 in mind: purpose limitation, data minimisation and access control. It has not been formally audited for legal compliance.',
    'Logged-in citizens can download their profile and complaints from Account settings.',
    'To correct or delete personal data, contact the municipal help desk. An automated deletion workflow is not part of this version.'
  ]],
  accessibility: ['Accessibility', [
    'The interface uses semantic headings, labelled form fields, visible keyboard focus and text labels in addition to colour for statuses.',
    'Content is available in English, Hindi and Odia, and complaints can be dictated by voice where the browser or configured speech service supports it.',
    'Accessibility has been checked during development but not formally audited against WCAG. Please report any barrier through the Feedback page.'
  ]],
  attributions: ['Copyright & Attributions', [
    'Software © 2026 The Phantom Stack, Problem Statement PS-09 CivicFix.',
    'Street map tiles: © OpenStreetMap contributors (Open Database License).',
    'Satellite layer: Esri World Imagery (archived imagery, not real-time).',
    'Weather forecasts: Open-Meteo (open-meteo.com), licensed under CC BY 4.0.',
    'Mapping library: Leaflet and Leaflet.markercluster (BSD/MIT licences).',
    'Project showcase photographs supplied for this demonstration are illustrative examples, not live municipal complaint records.'
  ]],
  security: ['Security', [
    'Passwords are stored as salted scrypt hashes. Sessions use HttpOnly cookies that expire automatically and are deleted on logout.',
    'Every protected request is checked on the server for the user\'s role, ownership of the complaint and department scope.',
    'Database queries use parameter binding. Uploads are limited in size and checked by file content.',
    'Every significant action is written to an audit log with the actor, time and a hash.',
    'To report a security problem, contact the project team.'
  ]],
  cookies: ['Cookies & Sessions', [
    'One essential session cookie keeps you logged in. It is not used for advertising or tracking.',
    'Your language and theme choices are saved in your browser\'s local storage.'
  ]],
  disclaimer: ['AI & Forecast Disclaimer', [
    'Nagar Sarthi AI suggests a category from the words in your description. It is a suggestion only: you confirm or change it before submitting.',
    'Without an external AI key, the assistant is rule-based and says so. Facts it gives about complaints come from the database only.',
    'Weather risk flags combine an Open-Meteo forecast with past complaint records. They are estimates, not certain predictions, and are not official IMD warnings.',
    'Recurring-issue and hotspot recommendations are rule-based and do not replace a physical inspection.'
  ]],
  faq: ['Help & FAQ', [
    'How do I report by voice? Open Report an Issue, press Record voice, choose the language you will speak, record, then check and edit the transcript.',
    'Why does the microphone not work? Browsers allow the microphone only on HTTPS pages or on localhost. Check the microphone permission in your browser settings.',
    'How do I confirm a problem someone else reported? Open Civic Echo Community and press "I face this problem too".',
    'How is work verified? When the authority marks your complaint resolved with a completion photograph, you are asked whether the issue is actually resolved. Choose Yes to close it, or No with a reason to send it back.'
  ]]
};

export async function renderLegalPoliciesView(params = {}) {
  const tab = CONTENT[params.tab] ? params.tab : 'privacy';
  const [title, paras] = CONTENT[tab];
  return `<div class="max-w-5xl mx-auto px-4 py-8 w-full space-y-6">
    <div class="bg-gradient-to-r from-[#122B40] via-[#15324B] to-[#1B3B52] text-white p-6 sm:p-8 rounded-2xl">
      <div class="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-xs font-semibold mb-2 border border-teal-400/30">${iconSm(Icons.shield, 14)}<span>Legal & Policies</span></div>
      <h1 class="text-2xl sm:text-3xl font-extrabold font-heading">Legal, Privacy and Help</h1>
      <p class="text-xs sm:text-sm text-slate-300 mt-1">How Nagar Sarthi handles your information, and how to use it.</p></div>
    <div class="flex flex-wrap gap-1.5" role="tablist">${TABS.map(([k, l]) => `<button role="tab" aria-selected="${k === tab}" class="px-3 py-1.5 rounded-xl text-xs font-semibold ${k === tab ? 'bg-[#15324B] text-white' : 'bg-white text-slate-600 border border-slate-200'}" onclick="window.navigate('legal-policies', {tab: '${k}'})">${l}</button>`).join('')}</div>
    <section class="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200"><h2 class="text-lg font-bold text-slate-900 mb-3">${title}</h2>
      <ul class="space-y-2 text-sm text-slate-700 list-disc pl-5">${paras.map(p => `<li>${p}</li>`).join('')}</ul></section></div>`;
}
