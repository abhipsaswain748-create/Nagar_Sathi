// About Nagar Sarthi View
// Authoritative, Professional, and Proud Presentation of the Civic Governance Ecosystem
import { Icons } from '../../icons.js';

export async function renderAboutView() {
  return `
    <div class="max-w-5xl mx-auto px-4 py-12 w-full space-y-10">
      
      <!-- Hero Header -->
      <div class="text-center space-y-4 max-w-3xl mx-auto">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold">
          <span class="w-2 h-2 rounded-full bg-teal-600"></span>
          <span>Civic Tech & Digital Governance Initiative</span>
        </div>
        <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#15324B] font-heading tracking-tight">
          About Nagar Sarthi
        </h1>
        <p class="text-base sm:text-lg text-slate-600 font-medium leading-relaxed">
          "Your City. Your Voice. Our Collective Responsibility."
        </p>
        <p class="text-xs sm:text-sm text-slate-500 max-w-2xl mx-auto leading-relaxed">
          Nagar Sarthi, meaning "City Charioteer", is an intelligent, interconnected civic governance ecosystem designed to transform how citizens report infrastructure defects, how municipal authorities plan and execute repairs, and how cities prevent recurring failures through institutional memory.
        </p>
      </div>

      <!-- Core Identity & Terminology -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <div class="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div class="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200">
            ${Icons.shield}
          </div>
          <h3 class="text-lg font-bold text-slate-900 font-heading">Core Identity</h3>
          <ul class="text-xs text-slate-600 space-y-2 leading-relaxed">
            <li><strong class="text-slate-800">Problem Statement:</strong> <span translate="no">PS-09 CivicFix</span></li>
            <li><strong class="text-slate-800">Theme:</strong> Civic Tech & Digital Governance</li>
            <li><strong class="text-slate-800">Public Platform:</strong> Nagar Sarthi</li>
            <li><strong class="text-slate-800">Intelligence Layer:</strong> Nagar Sarthi AI</li>
            <li><strong class="text-slate-800">Development Team:</strong> <span translate="no">The Phantom Stack</span></li>
          </ul>
        </div>

        <div class="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
            ${Icons.mapPin}
          </div>
          <h3 class="text-lg font-bold text-slate-900 font-heading">Demonstration Context</h3>
          <p class="text-xs text-slate-600 leading-relaxed">
            The demonstration uses Bhubaneswar, Odisha as its geographic context, with sample complaints placed at well-known localities such as Janpath, Rasulgarh and Patia. All seeded records are demonstration data, not municipal records.</p>
          <div class="text-[11px] text-teal-700 font-semibold pt-1">
            ✓ Modular architecture designed for seamless adaptation to any Indian municipality or smart city.
          </div>
        </div>

      </div>

      <!-- Architectural Pillars -->
      <div class="space-y-4">
        <h2 class="text-xl font-bold text-[#15324B] font-heading">The Four Ecosystem Pillars</h2>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
            <div class="text-teal-700 font-bold text-xs uppercase tracking-wider">Pillar 1</div>
            <h4 class="font-bold text-sm text-slate-900 font-heading">Inclusive Citizen Intake</h4>
            <p class="text-xs text-slate-500 leading-relaxed">
              Reporting by text or voice in Odia, Hindi and English, landmark search, photo evidence, and one-click Civic Echo community confirmations.
            </p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
            <div class="text-blue-700 font-bold text-xs uppercase tracking-wider">Pillar 2</div>
            <h4 class="font-bold text-sm text-slate-900 font-heading">Intelligent Operations</h4>
            <p class="text-xs text-slate-500 leading-relaxed">
              Administrator review with recorded reasons, duplicate grouping, department and field-worker assignment, and SLA deadline monitoring with escalation.
            </p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
            <div class="text-indigo-700 font-bold text-xs uppercase tracking-wider">Pillar 3</div>
            <h4 class="font-bold text-sm text-slate-900 font-heading">Field Accountability</h4>
            <p class="text-xs text-slate-500 leading-relaxed">
              Inspection, work-in-progress and completion photographs from the field, and citizen verification before closure.
            </p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
            <div class="text-amber-700 font-bold text-xs uppercase tracking-wider">Pillar 4</div>
            <h4 class="font-bold text-sm text-slate-900 font-heading">Civic Memory & Sentinels</h4>
            <p class="text-xs text-slate-500 leading-relaxed">
              Recurring-issue history, hotspot detection, weather-synchronised risk flags, and an audit log of every action.
            </p>
          </div>

        </div>
      </div>

      <!-- Development Team Card -->
      <div class="bg-gradient-to-r from-[#122B40] via-[#15324B] to-[#1B3B52] text-white p-8 rounded-2xl shadow-lg space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-700/80 pb-6">
          <div>
            <span class="text-teal-300 font-bold text-xs uppercase tracking-wider">Engineering & Design</span>
            <h3 class="text-2xl font-extrabold font-heading mt-1" translate="no">The Phantom Stack</h3>
            <p class="text-xs text-slate-300 mt-1">Dedicated to building transparent, intelligent, and human-centric civic technology.</p>
          </div>
          <div class="px-4 py-2 rounded-xl bg-teal-500/20 border border-teal-400/30 text-teal-200 text-xs font-bold font-mono">
            <span translate="no">PS-09 CivicFix</span>
          </div>
        </div>

        <div>
          <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Core Team Members</h4>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            
            <div class="bg-white/10 rounded-xl p-4 border border-white/10 backdrop-blur-sm">
              <div class="w-10 h-10 rounded-full bg-teal-600/40 text-teal-300 flex items-center justify-center font-bold text-sm mb-2 border border-teal-400/30">
                SM
              </div>
              <div class="font-bold text-sm text-white" translate="no">Susobhana Mohanty</div>
            </div>

            <div class="bg-white/10 rounded-xl p-4 border border-white/10 backdrop-blur-sm">
              <div class="w-10 h-10 rounded-full bg-blue-600/40 text-blue-300 flex items-center justify-center font-bold text-sm mb-2 border border-blue-400/30">
                AM
              </div>
              <div class="font-bold text-sm text-white" translate="no">Anannya Mohanty</div>
            </div>

            <div class="bg-white/10 rounded-xl p-4 border border-white/10 backdrop-blur-sm">
              <div class="w-10 h-10 rounded-full bg-indigo-600/40 text-indigo-300 flex items-center justify-center font-bold text-sm mb-2 border border-indigo-400/30">
                SS
              </div>
              <div class="font-bold text-sm text-white" translate="no">Saishree Satpathy</div>
            </div>

            <div class="bg-white/10 rounded-xl p-4 border border-white/10 backdrop-blur-sm">
              <div class="w-10 h-10 rounded-full bg-cyan-600/40 text-cyan-300 flex items-center justify-center font-bold text-sm mb-2 border border-cyan-400/30">
                AS
              </div>
              <div class="font-bold text-sm text-white" translate="no">Abhipsa Swain</div>
            </div>

          </div>
        </div>

        <div class="pt-4 border-t border-slate-700/80 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div>Built with privacy-first open-source components.</div>
          <div class="flex items-center gap-3">
            <button class="hover:text-white transition font-semibold" onclick="window.navigate('legal-policies')">Legal & Policies</button>
            <span>•</span>
            <button class="hover:text-white transition font-semibold" onclick="window.navigate('public-map')">Civic Map</button>
            <span>•</span>
            <button class="hover:text-white transition font-semibold" onclick="window.navigate('report-issue')">Report Grievance</button>
          </div>
        </div>

      </div>

    </div>
  `;
}
