// Public Landing Page View
// Preserves Core Brand Identity & 4 Action Cards while adding "Explore Civic Issue Categories"
// and Proactive Weather-Aware Flood Predictive Sentinel
import { state } from '../../state.js';
import { api } from '../../api.js';
import { Icons } from '../../icons.js';
import { DOMAINS, esc, iconSm, date } from '../../ui.js';
import { fmtNum } from '../../i18n.js';

export async function renderLandingView() {
  let stats = null, weather = null;
  const [sr, wr] = await Promise.allSettled([api.publicStats(), api.weatherRisk()]);
  if (sr.status === 'fulfilled') stats = sr.value.data;
  if (wr.status === 'fulfilled') weather = wr.value.data;
  const civicTaxonomy = DOMAINS;
  const loggedIn = !!state.currentUser;
  const today = weather && weather.forecast ? weather.forecast.daily[0] : null;
  const maxRain = weather && weather.forecast ? Math.max(...weather.forecast.daily.map(d => d.precipitation_mm || 0)) : null;

  return `
    <!-- Hero Section -->
    <section class="relative bg-gradient-to-b from-[#122B40] via-[#15324B] to-[#1B3B52] text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <!-- Subtle Urban Grid Background Graphic -->
      <div class="absolute inset-0 opacity-10 pointer-events-none" style="background-image: radial-gradient(#168C86 1px, transparent 1px); background-size: 24px 24px;"></div>

      <div class="max-w-6xl mx-auto relative z-10 text-center">
        
        <!-- Status Pill -->
        <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-950/80 border border-teal-500/40 text-teal-300 text-xs font-semibold mb-6 shadow-sm">
          <span class="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
          <span>AI-Powered Civic Governance Platform</span>
        </div>

        <!-- Headline -->
        <h1 class="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-heading leading-tight max-w-4xl mx-auto">
          Your City Deserves Better.<br class="hidden sm:inline" />
          <span class="bg-gradient-to-r from-teal-300 via-sky-200 to-white bg-clip-text text-transparent">
            Your Voice Makes It Happen.
          </span>
        </h1>

        <!-- Supporting Text -->
        <p class="mt-5 text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Nagar Sarthi transforms civic complaints into collective intelligence, collective intelligence into accountable action, and accountable action into smarter cities.
        </p>

        <!-- Primary Action Buttons -->
        <div class="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
          <button class="btn-teal py-3 px-6 text-sm font-bold shadow-xl" onclick="window.navigate('report-issue')">
            ${Icons.microphone}
            <span>Report an Issue (Voice or Text)</span>
          </button>
          <button class="btn-secondary py-3 px-6 text-sm font-bold bg-white/10 text-white border-white/20 hover:bg-white/20" onclick="window.navigate('my-complaints')">
            ${Icons.clock}
            <span>Track My Complaint</span>
          </button>
          <button class="btn-secondary py-3 px-5 text-sm font-bold bg-white/10 text-white border-white/20 hover:bg-white/20" onclick="window.navigate('public-map')">
            ${Icons.mapPin}
            <span>View Civic Map</span>
          </button>
        </div>

      </div>
    </section>

    <!-- Weather-synchronised civic risk (live forecast when reachable; honest unavailable state otherwise) -->
    <section class="max-w-6xl mx-auto px-4 -mt-6 mb-6 relative z-20">
      <div class="bg-gradient-to-r from-sky-900 to-[#122B40] text-white rounded-2xl shadow-lg border border-sky-600/40 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-300 flex items-center justify-center flex-shrink-0 border border-sky-400/30">${Icons.cloudRain}</div>
          <div>
            <div class="flex flex-wrap items-center gap-2">
              <span class="text-[10px] font-bold uppercase tracking-wider bg-sky-500/30 text-sky-200 px-2 py-0.5 rounded">Weather-Synchronised Risk</span>
              ${weather && weather.available
                ? `<span class="text-xs font-bold text-sky-200">${weather.alerts.length ? 'Rainfall risk in areas with repeated waterlogging complaints' : 'No rainfall risk flagged for the next 3 days'}</span>`
                : '<span class="text-xs font-bold text-amber-200">Live weather data is unavailable right now</span>'}
            </div>
            <p class="text-xs text-slate-300 mt-0.5">
              ${weather && weather.available
                ? `<span>Forecast maximum rainfall (3 days):</span> <span translate="no">${esc(fmtNum(maxRain))} mm</span>${today ? ` · <span>Today</span>: <span translate="no">${esc(fmtNum(today.precipitation_mm))} mm, ${esc(fmtNum(today.max_temp_c))}°C</span>` : ''}${weather.alerts.length ? ` · <span>Localities to inspect</span>: <span translate="no">${weather.alerts.map(a => esc(a.locality)).join(', ')}</span>` : ''}. <span>Source: Open-Meteo</span>, <span>retrieved</span> ${date(weather.forecast.retrieved_at)}.`
                : 'The forecast service could not be reached, so no weather-based risk is shown. No weather values are invented.'}
            </p>
          </div>
        </div>
        <button class="btn-secondary text-xs py-2 px-3.5 bg-white/10 hover:bg-white/20 text-white border-white/20 whitespace-nowrap self-start sm:self-center" onclick="window.navigate('${state.isAdmin() ? 'intelligence' : 'public-map'}')">
          ${state.isAdmin() ? 'Open civic intelligence' : 'View civic map'} →
        </button>
      </div>
    </section>

    <!-- Real-Time Municipal Pulse Statistics Ribbon -->
    <section class="max-w-6xl mx-auto px-4 relative z-20">
      <div class="bg-white rounded-2xl shadow-xl border border-slate-200/80 p-5 sm:p-6 grid grid-cols-2 md:grid-cols-4 gap-4 divide-y md:divide-y-0 md:divide-x divide-slate-100">
        
        <div class="text-center px-2">
          <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Reported</div>
          <div class="text-2xl sm:text-3xl font-extrabold text-[#15324B] mt-1 tabular-nums">${stats ? fmtNum(stats.total) : '-'}</div>
          <div class="text-[11px] text-teal-700 font-medium mt-0.5">Complaints on record</div>
        </div>

        <div class="text-center px-2 pt-3 md:pt-0">
          <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Operations</div>
          <div class="text-2xl sm:text-3xl font-extrabold text-blue-800 mt-1 tabular-nums">${stats ? fmtNum(stats.active) : '-'}</div>
          <div class="text-[11px] text-slate-500 font-medium mt-0.5">Not yet closed</div>
        </div>

        <div class="text-center px-2 pt-3 md:pt-0">
          <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Verified by Citizens</div>
          <div class="text-2xl sm:text-3xl font-extrabold text-emerald-700 mt-1 tabular-nums">${stats ? fmtNum(stats.verified) : '-'}</div>
          <div class="text-[11px] text-emerald-600 font-medium mt-0.5">Confirmed by the reporter</div>
        </div>

        <div class="text-center px-2 pt-3 md:pt-0">
          <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">SLA Compliance</div>
          <div class="text-2xl sm:text-3xl font-extrabold text-teal-700 mt-1 tabular-nums">${stats && stats.slaCompliancePct !== null ? fmtNum(stats.slaCompliancePct) + '%' : '-'}</div>
          <div class="text-[11px] text-slate-500 font-medium mt-0.5">Of resolved complaints</div>
        </div>

      </div>
      ${stats && stats.includesDemo ? '<p class="text-[11px] text-slate-500 text-center mt-2">Figures include demonstration records seeded for the hackathon.</p>' : ''}
    </section>

    <!-- 4 Primary Action Cards (Preserved Exactly) -->
    <section class="max-w-6xl mx-auto px-4 py-16">
      <div class="text-center max-w-2xl mx-auto mb-10">
        <h2 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Citizen-First Public Services</h2>
        <p class="text-xs sm:text-sm text-slate-600 mt-2">Designed for maximum accessibility with Voice, GPS, and Nagar Sarthi AI support.</p>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <!-- Card 1 -->
        <div role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}" class="ns-card ns-card-interactive p-6 flex flex-col justify-between cursor-pointer" onclick="window.navigate('report-issue')">
          <div>
            <div class="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200 mb-4">
              ${Icons.microphone}
            </div>
            <h3 class="font-bold text-base text-slate-900 font-heading">Report an Issue</h3>
            <p class="text-xs text-slate-600 mt-2 leading-relaxed">Speak or type your problem in English, Hindi or Odia, add photos and a location. AI suggests a category that you confirm.</p>
          </div>
          <div class="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-teal-700">
            <span>${loggedIn ? 'Start report' : 'Log in to report'}</span>
            <span class="ml-1">${Icons.arrowRight}</span>
          </div>
        </div>

        <!-- Card 2 -->
        <div role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}" class="ns-card ns-card-interactive p-6 flex flex-col justify-between cursor-pointer" onclick="window.navigate('my-complaints')">
          <div>
            <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200 mb-4">
              ${Icons.clock}
            </div>
            <h3 class="font-bold text-base text-slate-900 font-heading">Track Progress</h3>
            <p class="text-xs text-slate-600 mt-2 leading-relaxed">Transparent progress timeline from submission to assignment, field work, and verified resolution.</p>
          </div>
          <div class="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-blue-700">
            <span>${loggedIn ? 'Open my complaints' : 'Log in to track'}</span>
            <span class="ml-1">${Icons.arrowRight}</span>
          </div>
        </div>

        <!-- Card 3 -->
        <div role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}" class="ns-card ns-card-interactive p-6 flex flex-col justify-between cursor-pointer" onclick="window.navigate('community-issues')">
          <div>
            <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-200 mb-4">
              ${Icons.civicEcho}
            </div>
            <h3 class="font-bold text-base text-slate-900 font-heading">Civic Echo Community</h3>
            <p class="text-xs text-slate-600 mt-2 leading-relaxed">See shared and recurring problems in your area and add your confirmation to them.</p>
          </div>
          <div class="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-indigo-700">
            <span>Join Community Voice</span>
            <span class="ml-1">${Icons.arrowRight}</span>
          </div>
        </div>

        <!-- Card 4 -->
        <div role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}" class="ns-card ns-card-interactive p-6 flex flex-col justify-between cursor-pointer" onclick="window.toggleAIDrawer()">
          <div>
            <div class="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-800 flex items-center justify-center border border-cyan-200 mb-4">
              ${Icons.aiSparkle}
            </div>
            <h3 class="font-bold text-base text-slate-900 font-heading">Nagar Sarthi AI</h3>
            <p class="text-xs text-slate-600 mt-2 leading-relaxed">Ask in English, Hindi or Odia about reporting, categories, your complaint status, deadlines and verification.</p>
          </div>
          <div class="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-cyan-800">
            <span>Open AI Assistant</span>
            <span class="ml-1">${Icons.arrowRight}</span>
          </div>
        </div>

      </div>
    </section>

    <!-- NEW DEDICATED SECTION: Explore Civic Issue Categories -->
    <section class="bg-slate-100/80 border-y border-slate-200 py-16 px-4">
      <div class="max-w-6xl mx-auto">
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <span class="text-xs font-bold text-teal-700 uppercase tracking-wider">Civic Issue Domains</span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading mt-1" id="domains">Select a Civic Issue Domain</h2>
          </div>
          <p class="text-xs text-slate-500 max-w-md leading-relaxed">
            Choose a domain to start a report with that category already selected. You can still change it on the form. Not sure? Just describe the problem and Nagar Sarthi AI will suggest one.
          </p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          ${civicTaxonomy.map(item => `
            <button type="button" class="text-left bg-white p-6 rounded-2xl border border-slate-200 hover:border-teal-500 hover:shadow-lg transition cursor-pointer flex flex-col justify-between group" onclick="window.startReportWithCategory('${item.category}')" aria-label="${esc(item.title)}">
              <div>
                <div class="flex items-center justify-between mb-3">
                  <div class="w-12 h-12 rounded-xl bg-slate-50 group-hover:bg-teal-50 border border-slate-200 group-hover:border-teal-200 flex items-center justify-center text-teal-800 transition">
                    ${item.icon}
                  </div>
                  ${item.urgent ? '<span class="text-[10px] bg-red-100 text-red-800 border border-red-200 font-bold px-2 py-0.5 rounded-full">Safety Hazard</span>' : ''}
                </div>

                <h3 class="font-bold text-base text-slate-900 font-heading group-hover:text-teal-700 transition">${item.title}</h3>
                <p class="text-xs text-slate-500 mt-1 leading-relaxed">${esc(item.desc)}</p>
                
                <!-- Subcategories Pill Box -->
                <div class="mt-4 pt-3 border-t border-slate-100 space-y-1">
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Common Issues:</span>
                  <div class="flex flex-wrap gap-1.5 pt-1">
                    ${item.subs.map(sub => `
                      <span class="text-[10px] bg-slate-100 group-hover:bg-teal-50/50 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                        ${sub}
                      </span>
                    `).join('')}
                  </div>
                </div>
              </div>

              <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-teal-700 group-hover:translate-x-1 transition duration-200">
                <span>Report under this domain</span>
                <span>${Icons.arrowRight}</span>
              </div>
            </button>
          `).join('')}
        </div>
      </div>
    </section>

    <!-- How the Platform Works Journey -->
    <section class="max-w-6xl mx-auto px-4 py-16">
      <div class="text-center max-w-2xl mx-auto mb-12">
        <span class="text-xs font-bold text-teal-700 uppercase tracking-wider">Accountable Lifecycle</span>
        <h2 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading mt-1">From Complaint to Verified Fix</h2>
        <p class="text-xs sm:text-sm text-slate-600 mt-2">Every step is recorded with the time and the responsible person in the audit log.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div class="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-extrabold text-xs flex items-center justify-center mb-4">1</div>
          <h4 class="font-bold text-sm text-slate-900 font-heading">Smart Citizen Intake</h4>
          <p class="text-xs text-slate-600 mt-2 leading-relaxed">Speak, type, or upload photos. Nagar Sarthi AI suggests a category and spots landmarks. You confirm everything before submitting.</p>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div class="w-8 h-8 rounded-full bg-blue-100 text-blue-800 font-extrabold text-xs flex items-center justify-center mb-4">2</div>
          <h4 class="font-bold text-sm text-slate-900 font-heading">Review and Assignment</h4>
          <p class="text-xs text-slate-600 mt-2 leading-relaxed">Administrators review each complaint, set priority with a recorded reason, and assign the responsible department.</p>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div class="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 font-extrabold text-xs flex items-center justify-center mb-4">3</div>
          <h4 class="font-bold text-sm text-slate-900 font-heading">Field Work with Evidence</h4>
          <p class="text-xs text-slate-600 mt-2 leading-relaxed">Field workers upload inspection, work-in-progress and completion photographs from the site.</p>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-xs flex items-center justify-center mb-4">4</div>
          <h4 class="font-bold text-sm text-slate-900 font-heading">Evidence-Based Closure</h4>
          <p class="text-xs text-slate-600 mt-2 leading-relaxed">The complaint is closed only after the citizen confirms the issue is actually resolved, or it goes back for review.</p>
        </div>

      </div>
    </section>

    <!-- Supplied civic issue photographs -->
    <section class="bg-[#122B40] text-white py-16 px-4">
      <div class="max-w-6xl mx-auto">
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div class="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-semibold mb-2">
              ${Icons.civicProof} Civic Issues in Focus
            </div>
            <h2 class="text-2xl sm:text-3xl font-extrabold font-heading">Real Problems. Clear Civic Reporting.</h2>
          </div>
          <p class="text-xs text-slate-300 max-w-md">Examples of the kinds of public issues citizens can report through Nagar Sarthi. These supplied photographs are illustrative project assets, not live municipal complaint records.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
          <article class="bg-[#1B3B52] rounded-2xl p-3 border border-slate-700/80">
            <div class="relative rounded-xl overflow-hidden border border-slate-700">
              <img src="/assets/civic-road-damage-v2.jpg?v=20261106-2" alt="Road damage and an uncovered pothole with loose bricks" class="w-full h-48 sm:h-52 object-cover" loading="lazy" />
              <span class="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-2.5 py-1 rounded">Road damage</span>
            </div>
            <h3 class="font-bold text-sm mt-3">Roads &amp; Transportation</h3>
            <p class="text-xs text-slate-300 mt-1">Potholes and damaged road surfaces that can put road users at risk.</p>
          </article>
          <article class="bg-[#1B3B52] rounded-2xl p-3 border border-slate-700/80">
            <div class="relative rounded-xl overflow-hidden border border-slate-700">
              <img src="/assets/civic-garbage-accumulation-v2.jpg?v=20261106-2" alt="Garbage accumulated on a public street with stray cattle" class="w-full h-48 sm:h-52 object-cover" loading="lazy" />
              <span class="absolute top-3 left-3 bg-orange-500 text-white text-xs font-bold px-2.5 py-1 rounded">Garbage accumulation</span>
            </div>
            <h3 class="font-bold text-sm mt-3">Waste Management</h3>
            <p class="text-xs text-slate-300 mt-1">Uncollected roadside waste affecting cleanliness and public spaces.</p>
          </article>
          <article class="bg-[#1B3B52] rounded-2xl p-3 border border-slate-700/80">
            <div class="relative rounded-xl overflow-hidden border border-slate-700">
              <img src="/assets/civic-sanitation-problem-v2.jpg?v=20261106-2" alt="Large roadside waste accumulation and sanitation concern" class="w-full h-48 sm:h-52 object-cover" loading="lazy" />
              <span class="absolute top-3 left-3 bg-emerald-600 text-white text-xs font-bold px-2.5 py-1 rounded">Public sanitation</span>
            </div>
            <h3 class="font-bold text-sm mt-3">Sanitation &amp; Public Health</h3>
            <p class="text-xs text-slate-300 mt-1">Large waste accumulations that need timely municipal attention.</p>
          </article>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white border-t border-slate-200 py-10 px-4 mt-auto">
      <div class="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div class="flex items-center gap-3">
          <img src="/assets/nagar-sarthi-brand-official-v2.jpg?v=20261106-2" alt="Nagar Sarthi" class="h-9 w-auto max-w-[220px] object-contain" />
          <span>© 2026 Nagar Sarthi Ecosystem. All rights reserved.</span>
        </div>
        <div class="flex flex-wrap gap-4 font-medium">
          <button class="hover:text-teal-700" onclick="window.navigate('about')">About Us</button>
          <button class="hover:text-teal-700" onclick="window.navigate('legal-policies')">Legal & Policies</button>
          <button class="hover:text-teal-700" onclick="window.navigate('legal-policies', {tab: 'privacy'})">Privacy</button>
          <button class="hover:text-teal-700" onclick="window.navigate('admin-login')">Administrator Portal</button>
        </div>
      </div>
    </footer>
  `;
}

window.startReportWithCategory = function(cat) {
  // Category is carried in the URL (#report-issue?category=...) so it survives routing and login
  window.navigate('report-issue', { category: cat });
};
