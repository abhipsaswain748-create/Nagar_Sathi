// Public civic map
import { renderCivicMap } from '../../components/civic-map.js';

export async function renderPublicMapView(params = {}) {
  return `<div class="max-w-7xl mx-auto px-4 py-6 w-full">
    <h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">Civic Map</h1>
    <p class="text-xs sm:text-sm text-slate-500 mt-1 mb-4">Public civic reports from Nagar Sarthi. Names and exact addresses are never shown.</p>
    ${await renderCivicMap(params, { staff: false, route: 'public-map' })}</div>`;
}
