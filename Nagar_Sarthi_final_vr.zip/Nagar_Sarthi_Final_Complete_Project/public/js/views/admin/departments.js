// Department workload and performance (measured from records; no invented statistics)
import { api } from '../../api.js';
import { fmtNum } from '../../i18n.js';
import { esc, emptyState } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';

export async function renderDepartmentsView() {
  const r = await api.deptStats();
  const content = r.data.length ? `<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">${r.data.map(d => `
    <article class="bg-white rounded-2xl border border-slate-200 p-5">
      <div class="flex items-start justify-between gap-2"><div><h2 class="text-sm font-bold text-slate-900">${esc(d.name)}</h2>
        <p class="text-[11px] text-slate-500"><span translate="no">${esc(d.code)}</span> · <span>Default SLA</span> <span translate="no">${d.sla_hours_default} h</span></p></div></div>
      <dl class="grid grid-cols-3 gap-2 mt-4 text-center">
        ${[['Total assigned', d.total], ['Pending', d.pending], ['In progress', d.inProgress], ['Resolved', d.resolved], ['Overdue', d.overdue, d.overdue ? 'text-red-700' : '']].map(([l, n, c]) =>
          `<div class="bg-slate-50 rounded-xl p-2"><dt class="text-[10px] text-slate-500">${l}</dt><dd class="text-lg font-extrabold ${c || 'text-[#15324B]'}" translate="no">${fmtNum(n)}</dd></div>`).join('')}
        <div class="bg-slate-50 rounded-xl p-2"><dt class="text-[10px] text-slate-500">SLA compliance</dt><dd class="text-lg font-extrabold text-teal-700" translate="no">${d.slaCompliancePct === null ? '-' : fmtNum(d.slaCompliancePct) + '%'}</dd></div>
      </dl>
      <p class="text-[11px] text-slate-500 mt-3">${d.avgResolutionHours === null ? 'Average resolution time: not enough resolved complaints yet' : `<span>Average resolution time</span>: <span translate="no">${fmtNum(d.avgResolutionHours)} h</span>`} · <span>based on</span> <span translate="no">${fmtNum(d.sampleSize)}</span> <span>resolved complaints</span></p>
      <div class="flex gap-2 mt-3">
        <button class="btn-secondary text-xs py-1.5 px-3" onclick="window.navigate('complaints-mgmt', {department_id: '${esc(d.id)}'})">View complaints</button>
        <button class="btn-secondary text-xs py-1.5 px-3" onclick="window.navigate('admin-feedback', {department_id: '${esc(d.id)}'})">View feedback</button></div>
    </article>`).join('')}</div>` : emptyState('No departments found.');
  return adminLayout('Department Management', 'Workload and performance per department. Assign or reassign complaints from each complaint page.', content);
}
