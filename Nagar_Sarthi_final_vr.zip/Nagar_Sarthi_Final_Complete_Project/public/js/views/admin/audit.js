// Audit log (read-only; entries are written by the server for every significant action)
import { api } from '../../api.js';
import { esc, u, soft, id, date, roleLabel, emptyState } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';

export async function renderAuditView(params = {}) {
  const r = await api.audit({ complaint_id: params.complaint_id });
  const content = `<form class="flex gap-2 mb-4" onsubmit="event.preventDefault(); window.navigate('audit-log', {complaint_id: this.cid.value.trim()})">
      <label for="au-cid" class="sr-only">Complaint ID</label><input id="au-cid" name="cid" value="${esc(params.complaint_id || '')}" class="ns-input max-w-xs py-1.5" placeholder="Filter by complaint ID" />
      <button class="btn-primary text-xs py-1.5 px-3">Filter</button></form>
    ${r.data.length ? `<div class="bg-white rounded-2xl border border-slate-200 overflow-x-auto"><table class="ns-table"><thead><tr><th>Time</th><th>Event</th><th>Complaint</th><th>Actor</th><th>Details</th><th>Hash</th></tr></thead><tbody>
      ${r.data.map(a => `<tr><td data-label="Time">${date(a.created_at)}</td><td data-label="Event"><span translate="no" class="font-mono text-[11px]">${esc(a.event_type)}</span><div>${soft(a.action)}</div></td>
        <td data-label="Complaint">${a.complaint_id ? `<button class="underline text-teal-700" onclick="window.navigate('admin-complaint', {id: '${esc(a.complaint_id)}'})">${id(a.complaint_id)}</button>` : '-'}</td>
        <td data-label="Actor">${u(a.actor_name)}<div class="text-[11px] text-slate-500">${roleLabel(a.actor_role)}</div></td><td data-label="Details">${soft(a.details || '')}</td>
        <td data-label="Hash"><span translate="no" class="font-mono text-[10px]">${esc(a.hash_signature)}</span></td></tr>`).join('')}</tbody></table></div>` : emptyState('No audit entries.')}`;
  return adminLayout('Audit Log', 'Who did what and when. Entries cannot be edited through the application.', content);
}
