// Field worker management: assigned tasks and latest evidence. No live GPS tracking is collected.
import { api } from '../../api.js';
import { fmtNum, t } from '../../i18n.js';
import { esc, u, id, date, statusPill, slaPill, emptyState } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';

const EV = { inspection: 'Inspection', progress: 'During Work', completion: 'Completion' };

export async function renderFieldWorkersView() {
  const r = await api.fieldWorkers();
  const content = `<p class="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 mb-4">${esc(t(r.note))}</p>` + (r.data.length ? `<div class="space-y-4">${r.data.map(w => `
    <article class="bg-white rounded-2xl border border-slate-200 p-5">
      <div class="flex flex-wrap items-start justify-between gap-2"><div><h2 class="text-sm font-bold text-slate-900">${u(w.name)}</h2>
        <p class="text-[11px] text-slate-500">${u(w.designation || '')} · ${esc(w.department_name || '')} · ${u(w.zone || '')}</p>
        ${w.has_login ? '' : '<p class="text-[11px] text-amber-700">No login account linked yet.</p>'}</div>
        <div class="text-right"><div class="text-2xl font-extrabold text-[#15324B]" translate="no">${fmtNum(w.open)}</div><div class="text-[11px] text-slate-500">open tasks</div></div></div>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
        <div><h3 class="text-xs font-bold text-slate-700 mb-2">Assigned tasks</h3>
          ${w.tasks.length ? `<ul class="space-y-2">${w.tasks.slice(0, 8).map(tk => `<li><button class="w-full text-left text-xs bg-slate-50 rounded-lg p-2 hover:bg-teal-50 flex flex-wrap items-center justify-between gap-2" onclick="window.navigate('admin-complaint', {id: '${esc(tk.id)}'})">
            <span>${id(tk.id)} · ${u(tk.title.slice(0, 60))}</span><span class="flex gap-1">${statusPill(tk.status)}${slaPill(tk.sla_state)}</span></button></li>`).join('')}</ul>` : '<p class="text-xs text-slate-500">No tasks assigned.</p>'}</div>
        <div><h3 class="text-xs font-bold text-slate-700 mb-2">Latest evidence uploaded</h3>
          ${w.evidence.length ? `<div class="grid grid-cols-3 gap-2">${w.evidence.map(e => `<a href="${esc(e.url)}" target="_blank" rel="noopener" class="block text-[10px] text-slate-600">
            <img src="${esc(e.url)}" alt="${EV[e.evidence_type]}" class="w-full h-20 object-cover rounded-lg border" loading="lazy" />
            <span class="font-bold">${EV[e.evidence_type]}</span> · ${id(e.complaint_id)}<br>${date(e.created_at)}</a>`).join('')}</div>` : '<p class="text-xs text-slate-500">No field evidence yet.</p>'}</div>
      </div></article>`).join('')}</div>` : emptyState('No field workers found.'));
  return adminLayout('Field Worker Management', 'Assign field workers from each complaint page. Review their inspection, progress and completion photographs here.', content);
}
