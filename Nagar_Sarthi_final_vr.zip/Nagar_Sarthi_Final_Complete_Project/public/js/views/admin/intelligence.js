// Civic intelligence for administrators: weather-synchronised risk, recurring issues / deterioration,
// hotspots and shared incidents (with grouping correction). Facts and rule-based flags are labelled separately.
import { api } from '../../api.js';
import { state } from '../../state.js';
import { t, fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, categoryChip, demoBadge, emptyState, DOMAINS } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';
import { showToast } from '../../components/toast.js';

export async function renderIntelligenceView(params = {}) {
  const tab = params.tab || 'weather';
  const cat = params.category || 'all';
  let body = '';
  if (tab === 'weather') {
    const w = (await api.weatherRisk()).data;
    body = `<section class="bg-white rounded-2xl border border-slate-200 p-5">
      <div class="flex flex-wrap items-center justify-between gap-2"><h2 class="text-sm font-bold text-slate-900">Weather-Synchronised Risk</h2>
        <span class="text-[11px] text-slate-500">${esc(t(w.source))}</span></div>
      ${w.available ? `<p class="text-[11px] text-slate-500 mt-1"><span>Retrieved</span> ${date(w.forecast.retrieved_at)} · <span>Rain threshold used</span>: <span translate="no">${w.threshold_mm} mm/day</span> (<span>configurable</span>)</p>
        <div class="grid grid-cols-3 gap-3 mt-3">${w.forecast.daily.map(d => `<div class="bg-sky-50 border border-sky-200 rounded-xl p-3 text-xs"><div class="font-bold">${date(d.date, false)}</div>
          <div><span>Rain</span>: <span translate="no">${fmtNum(d.precipitation_mm)} mm</span></div><div><span>Chance of rain</span>: <span translate="no">${d.precipitation_probability_pct ?? '-'}%</span></div><div><span>Max temperature</span>: <span translate="no">${fmtNum(d.max_temp_c)}°C</span></div></div>`).join('')}</div>`
        : `<p class="mt-3 text-xs bg-amber-50 border border-amber-300 text-amber-900 rounded-lg p-2" role="alert">Live weather data is unavailable right now (the forecast service could not be reached). No weather-based alerts are generated and no values are invented.</p>`}
      <h3 class="text-xs font-bold text-slate-700 mt-5 mb-2">Alerts</h3>
      ${w.alerts.length ? `<ul class="space-y-2">${w.alerts.map(a => `<li class="text-xs bg-amber-50 border border-amber-300 rounded-lg p-3"><strong translate="no">${esc(a.locality)}, Ward ${a.ward_no}</strong> ${demoBadge(a.is_demo)} · <span>${a.level === 'elevated' ? 'Elevated risk' : 'Watch'}</span><p class="mt-1">${esc(t(a.reason))}</p></li>`).join('')}</ul>`
        : '<p class="text-xs text-slate-500">No weather risk alerts.</p>'}
      <h3 class="text-xs font-bold text-slate-700 mt-5 mb-2">Localities with repeated waterlogging or drainage complaints (last 12 months)</h3>
      ${w.recurring_localities.length ? `<ul class="text-xs space-y-1">${w.recurring_localities.map(l => `<li><span translate="no">${esc(l.locality)}, Ward ${l.ward_no}</span>: <span translate="no">${l.n}</span> <span>complaints</span> ${demoBadge(l.is_demo)}</li>`).join('')}</ul>` : '<p class="text-xs text-slate-500">None.</p>'}
      <p class="text-[11px] text-slate-500 mt-4">${esc(t(w.disclaimer))}</p></section>`;
  } else if (tab === 'recurring') {
    const r = await api.recurring({ category: cat });
    body = `<p class="text-xs text-slate-500 mb-3">${esc(t(r.meta.method))}</p>` + (r.data.length ? `<div class="bg-white rounded-2xl border border-slate-200 overflow-x-auto"><table class="ns-table"><thead><tr><th>Area</th><th>Domain</th><th>Total reports</th><th>Last 12 months</th><th>First / last report</th><th>Previous resolutions</th><th>Current status</th><th>Deterioration flag</th></tr></thead><tbody>
      ${r.data.map(x => `<tr><td data-label="Area">${u(x.area)} ${demoBadge(x.is_demo)}</td><td data-label="Domain">${categoryChip(x.category)}</td><td data-label="Total reports" translate="no">${fmtNum(x.total_reports)}</td><td data-label="Last 12 months" translate="no">${fmtNum(x.reports_last_12_months)}</td>
        <td data-label="First / last report">${date(x.first_reported, false)} / ${date(x.last_reported, false)}</td><td data-label="Previous resolutions" translate="no">${fmtNum(x.previous_resolutions.length)}</td>
        <td data-label="Current status">${x.currently_open ? statusPill(x.current_status) : '<span>No open complaint</span>'}</td>
        <td data-label="Deterioration flag">${x.flag_preventive_maintenance ? `<span class="text-xs font-bold text-amber-800">Preventive maintenance recommended</span><div class="text-[11px] text-slate-500">${esc(t(x.flag_reason))}</div>` : '-'}</td></tr>`).join('')}</tbody></table></div>` : emptyState('No recurring problems found for this filter.'));
  } else if (tab === 'hotspots') {
    const h = await api.hotspots({ category: cat, days: params.days || 90 });
    body = `<p class="text-xs text-slate-500 mb-3">${esc(t(h.meta.method))} · ${t('Last {0} days').replace('{0}', h.meta.days)}</p>` + (h.data.length ? `<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">${h.data.map(x => `<div class="bg-white rounded-xl border border-slate-200 p-4">
      ${categoryChip(x.category)} ${demoBadge(x.is_demo)}<div class="text-sm font-bold mt-1">${u(x.area)}</div>
      <div class="text-xs mt-2"><span>Complaints</span>: <strong translate="no">${fmtNum(x.count)}</strong> · <span>Open</span>: <strong translate="no">${fmtNum(x.open)}</strong></div>
      <div class="text-[11px] text-slate-500"><span>High / Medium / Low</span>: <span translate="no">${x.severity.High} / ${x.severity.Medium} / ${x.severity.Low}</span></div></div>`).join('')}</div>` : emptyState('No hotspots in this period.'));
  } else {
    const inc = await api.incidents();
    const list = cat === 'all' ? inc.data : inc.data.filter(g => g.category === cat);
    body = `<p class="text-xs text-slate-500 mb-3">${esc(t(inc.meta.rule))}</p>` + (list.length ? `<div class="space-y-3">${list.map(g => `<article class="bg-white rounded-xl border border-slate-200 p-4">
      <div class="flex flex-wrap justify-between gap-2"><div>${id(g.incident_id)} ${demoBadge(g.is_demo)}<div class="text-sm font-bold">${u(g.title)}</div>${categoryChip(g.category)}</div>${statusPill(g.status)}</div>
      <p class="text-xs mt-2"><span>Related complaints</span>: <strong translate="no">${g.related_complaints}</strong> · <span>Citizens reporting</span>: <strong translate="no">${g.citizens_reporting}</strong> · ${u(g.area)}</p>
      <div class="flex flex-wrap gap-2 mt-2">${g.complaint_ids.map(cid => `<span class="inline-flex items-center gap-1 text-[11px] bg-slate-100 rounded px-2 py-0.5">${id(cid)}
        ${cid !== g.lead_complaint && state.currentUser.role === 'admin' ? `<button class="text-red-700 underline" onclick="window.intUnlink('${esc(cid)}')">Remove from group</button>` : ''}</span>`).join('')}</div></article>`).join('')}</div>` : emptyState('No shared incidents right now.'));
  }
  const tabs = [['weather', 'Weather-Synchronised Risk'], ['recurring', 'Recurring issues & deterioration'], ['hotspots', 'Civic hotspots'], ['incidents', 'Shared incidents']];
  const content = `<div class="flex flex-wrap items-center gap-2 mb-4">
      <div class="flex gap-1.5 overflow-x-auto" role="tablist">${tabs.map(([k, l]) => `<button role="tab" aria-selected="${k === tab}" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${k === tab ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200'}" onclick="window.navigate('intelligence', {tab: '${k}', category: '${esc(cat)}'})">${l}</button>`).join('')}</div>
      ${tab !== 'weather' ? `<select aria-label="Domain" class="ns-input w-auto py-1 text-xs ml-auto" onchange="window.navigate('intelligence', {tab: '${tab}', category: this.value})"><option value="all">All domains</option>${DOMAINS.map(d => `<option value="${esc(d.category)}" ${cat === d.category ? 'selected' : ''}>${d.title}</option>`).join('')}</select>` : ''}
    </div>${body}`;
  return adminLayout('Civic Intelligence', 'Historical facts from complaint records, plus clearly labelled rule-based recommendations.', content);
}

window.intUnlink = async cid => {
  try { await api.unlinkIncident(cid); showToast(t('Removed from incident group'), 'success'); window.rerender(); } catch (e) { showToast(t(e.message), 'error'); }
};
