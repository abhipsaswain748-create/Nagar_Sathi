// Administrative Overview (all numbers computed by the server from records in the user's scope)
import { api } from '../../api.js';
import { state } from '../../state.js';
import { fmtNum } from '../../i18n.js';
import { esc, DOMAINS, STATUS_LABEL, demoBadge } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';

export function filterBar(route, params, depts, { status = true, extra = '' } = {}) {
  return `<form class="bg-white rounded-2xl border border-slate-200 p-4 grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mb-5" onsubmit="event.preventDefault(); window.navigate('${route}', Object.fromEntries(new FormData(this)))">
    <div><label class="ns-label" for="ff-from">From</label><input id="ff-from" name="from" type="date" value="${esc(params.from || '')}" class="ns-input py-1.5" /></div>
    <div><label class="ns-label" for="ff-to">To</label><input id="ff-to" name="to" type="date" value="${esc(params.to || '')}" class="ns-input py-1.5" /></div>
    <div><label class="ns-label" for="ff-cat">Domain</label><select id="ff-cat" name="category" class="ns-input py-1.5"><option value="all">All</option>${DOMAINS.map(d => `<option value="${esc(d.category)}" ${params.category === d.category ? 'selected' : ''}>${d.title}</option>`).join('')}</select></div>
    ${state.currentUser.role === 'admin' ? `<div><label class="ns-label" for="ff-dept">Department</label><select id="ff-dept" name="department_id" class="ns-input py-1.5"><option value="all">All</option>${depts.map(d => `<option value="${esc(d.id)}" ${params.department_id === d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>` : ''}
    ${status ? `<div><label class="ns-label" for="ff-status">Status</label><select id="ff-status" name="status" class="ns-input py-1.5"><option value="all">All</option>${Object.keys(STATUS_LABEL).map(s => `<option value="${esc(s)}" ${params.status === s ? 'selected' : ''}>${STATUS_LABEL[s]}</option>`).join('')}</select></div>` : ''}
    <div><label class="ns-label" for="ff-pri">Priority</label><select id="ff-pri" name="priority" class="ns-input py-1.5"><option value="all">All</option>${['High', 'Medium', 'Low'].map(p => `<option value="${p}" ${params.priority === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
    <div><label class="ns-label" for="ff-loc">Locality</label><input id="ff-loc" name="locality" value="${esc(params.locality || '')}" class="ns-input py-1.5" /></div>
    ${extra}
    <div class="col-span-2 md:col-span-4 xl:col-span-7 flex gap-2"><button class="btn-primary text-xs py-2 px-4">Apply filters</button><button type="button" class="btn-secondary text-xs py-2 px-4" onclick="window.navigate('${route}')">Clear</button></div>
  </form>`;
}

function bar(label, n, max, cls = 'bg-teal-600') {
  return `<div class="text-xs"><div class="flex justify-between mb-0.5"><span>${label}</span><span class="font-bold" translate="no">${fmtNum(n)}</span></div>
    <div class="h-2 bg-slate-100 rounded-full"><div class="h-2 rounded-full ${cls}" style="width:${max ? Math.round(n / max * 100) : 0}%"></div></div></div>`;
}

export async function renderAdminDashboardView(params = {}) {
  const [ov, deps] = await Promise.all([api.overview(params), api.departments()]);
  const d = ov.data; const s = d.byStatus;
  const card = (label, n, cls = 'text-[#15324B]', status) => `<button class="bg-white rounded-xl border border-slate-200 p-3 text-left hover:border-teal-500" ${status ? `onclick="window.navigate('complaints-mgmt', {status: '${status}'})"` : 'disabled'}>
    <div class="text-[11px] text-slate-500 font-semibold">${label}</div><div class="text-2xl font-extrabold ${cls}" translate="no">${fmtNum(n || 0)}</div></button>`;
  const catMax = Math.max(0, ...Object.values(d.byCategory)); const depMax = Math.max(0, ...Object.values(d.byDepartment));
  const content = `${filterBar('admin-dashboard', params, deps.data, { status: false })}
    ${d.includesDemo ? `<p class="mb-3">${demoBadge(true)} <span class="text-xs text-slate-500">These figures include seeded demonstration records.</span></p>` : ''}
    <section aria-labelledby="ov-h"><h2 id="ov-h" class="text-sm font-bold text-slate-900 mb-2">Complaints by status</h2>
    <div class="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-7 gap-3">
      ${card('Total complaints', d.total)}${card('New (last 24 hours)', d.new24h, 'text-sky-700')}${card('Pending review', d.pending, 'text-slate-700', 'Submitted')}
      ${card('Under Review', s['Under Review'], 'text-sky-700', 'Under Review')}${card('Assigned', s['Assigned'], 'text-indigo-700', 'Assigned')}${card('In Progress', s['In Progress'], 'text-blue-700', 'In Progress')}
      ${card('Resolution Submitted', s['Resolution Submitted'], 'text-teal-700', 'Resolution Submitted')}${card('Awaiting Citizen Verification', s['Resolved'], 'text-amber-700', 'Resolved')}
      ${card('Verified / Closed', s['Verified / Closed'], 'text-emerald-700', 'Verified / Closed')}${card('Disputed', s['Disputed'], 'text-red-700', 'Disputed')}${card('Reopened', s['Reopened'], 'text-orange-700', 'Reopened')}
      ${card('Escalated', s['Escalated'], 'text-rose-700', 'Escalated')}${card('High priority (open)', d.highPriorityOpen, 'text-red-700')}${card('Rejected', s['Rejected'], 'text-slate-600', 'Rejected')}
    </div></section>
    <section class="mt-6 bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="density-h">
      <div class="flex flex-wrap items-start justify-between gap-3">
        <div class="min-w-0"><h2 id="density-h" class="text-sm font-bold text-slate-900">Population density overview</h2>
          <p class="text-xs text-slate-600 mt-1">Wards 21 and 26 are identified in published analysis as very high-density areas (&gt;700 people per hectare). The GIS map displays ward-level population and calculated people per km² wherever the municipal data service is available.</p>
        </div>
        <button class="btn-primary text-xs py-2 px-4 shrink-0" onclick="window.navigate('gis-command')">Open population density map</button>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
        <div class="rounded-xl border border-red-200 bg-red-50 p-3"><div class="text-[11px] font-semibold text-red-800">Ward 21 · Very high density</div><div class="text-lg font-extrabold text-red-900">&gt;700 <span class="text-xs font-semibold">people / hectare</span></div></div>
        <div class="rounded-xl border border-red-200 bg-red-50 p-3"><div class="text-[11px] font-semibold text-red-800">Ward 26 · Very high density</div><div class="text-lg font-extrabold text-red-900">&gt;700 <span class="text-xs font-semibold">people / hectare</span></div></div>
      </div>
      <p class="text-[10px] text-slate-500 mt-2">Published analysis classification; not a live headcount. Exact ward values are shown in the GIS layer when the official ward dataset is reachable.</p>
    </section>
    <section class="mt-6" aria-labelledby="sla-h"><h2 id="sla-h" class="text-sm font-bold text-slate-900 mb-2">SLA deadlines (from stored deadlines)</h2>
      <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
        ${[['Deadline approaching (24 h)', d.sla.approaching, 'text-yellow-700', 'approaching'], ['Due today', d.sla.dueToday, 'text-orange-700', 'due_today'], ['Overdue (SLA breached)', d.sla.overdue, 'text-red-700', 'overdue'],
           ['Escalated', d.sla.escalated, 'text-rose-700', 'escalated'], ['Resolved within SLA', d.sla.metOnClosed, 'text-emerald-700', null], ['Resolved after deadline', d.sla.closedAfterDeadline, 'text-slate-700', null]].map(([l, n, c, k]) =>
          `<button class="bg-white rounded-xl border border-slate-200 p-3 text-left hover:border-teal-500" ${k ? `onclick="window.navigate('sla-monitor', {sla: '${k}'})"` : 'disabled'}><div class="text-[11px] text-slate-500 font-semibold">${l}</div><div class="text-2xl font-extrabold ${c}" translate="no">${fmtNum(n)}</div></button>`).join('')}
      </div></section>
    <div class="grid grid-cols-1 xl:grid-cols-2 gap-5 mt-6">
      <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="bc-h"><h2 id="bc-h" class="text-sm font-bold text-slate-900 mb-3">By civic issue domain</h2>
        <div class="space-y-2">${Object.entries(d.byCategory).sort((a, b) => b[1] - a[1]).map(([k, n]) => bar(esc(k), n, catMax)).join('') || '<p class="text-xs text-slate-500">No data.</p>'}</div></section>
      <section class="bg-white rounded-2xl border border-slate-200 p-5" aria-labelledby="bd-h"><h2 id="bd-h" class="text-sm font-bold text-slate-900 mb-3">By department</h2>
        <div class="space-y-2">${Object.entries(d.byDepartment).sort((a, b) => b[1] - a[1]).map(([k, n]) => bar(esc(k), n, depMax, 'bg-indigo-600')).join('') || '<p class="text-xs text-slate-500">No data.</p>'}</div></section>
    </div>`;
  return adminLayout('Administrative Overview', 'Live counts from the complaint database, limited to what your role is allowed to see.', content,
    `<button class="btn-primary text-xs py-2 px-4" onclick="window.navigate('complaints-mgmt')">Open complaint management</button>`);
}
