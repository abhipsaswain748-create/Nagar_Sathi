// Administrative feedback inbox: filter, review evidence, respond and record corrective action
import { api } from '../../api.js';
import { state } from '../../state.js';
import { t, fmtNum } from '../../i18n.js';
import { esc, u, id, date, emptyState } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';
import { showToast } from '../../components/toast.js';

const TYPES = { resolution: 'Resolution of my complaint', incomplete_work: 'Incomplete work', repeated_issue: 'Repeated issue', service: 'Service experience', suggestion: 'Suggestion for improvement', platform: 'Website / app experience', technical: 'Website / app experience' };
const STATUSES = ['New', 'Under Review', 'Responded', 'Action Taken', 'Closed'];

export async function renderAdminFeedbackInbox(params = {}) {
  const [r, deps] = await Promise.all([api.getFeedback(params), api.departments()]);
  const s = r.stats;
  const dissatisfied = r.data.filter(f => f.rating <= 2 || f.incomplete_work || f.work_satisfactory === 'no');
  const content = `
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
      ${[['Feedback received', s.total], ['Average rating', s.average === null ? '-' : s.average + ' / 5'], ['Low ratings (1-2)', s.low], ['Awaiting response', s.awaiting]].map(([l, n]) =>
        `<div class="bg-white rounded-xl border border-slate-200 p-3"><div class="text-[11px] text-slate-500 font-semibold">${l}</div><div class="text-2xl font-extrabold text-[#15324B]" translate="no">${typeof n === 'number' ? fmtNum(n) : esc(n)}</div></div>`).join('')}
    </div>
    <form class="bg-white rounded-2xl border border-slate-200 p-4 grid grid-cols-2 md:grid-cols-5 gap-3 mb-4" onsubmit="event.preventDefault(); window.navigate('admin-feedback', Object.fromEntries(new FormData(this)))">
      ${state.currentUser.role === 'admin' ? `<div><label class="ns-label" for="fi-dept">Department</label><select id="fi-dept" name="department_id" class="ns-input py-1.5"><option value="all">All</option>${deps.data.map(d => `<option value="${esc(d.id)}" ${params.department_id === d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>` : ''}
      <div><label class="ns-label" for="fi-cid">Complaint ID</label><input id="fi-cid" name="complaint_id" value="${esc(params.complaint_id || '')}" class="ns-input py-1.5" /></div>
      <div><label class="ns-label" for="fi-rating">Rating</label><select id="fi-rating" name="max_rating" class="ns-input py-1.5"><option value="">All</option><option value="2" ${params.max_rating === '2' ? 'selected' : ''}>2 or less</option><option value="3" ${params.max_rating === '3' ? 'selected' : ''}>3 or less</option></select></div>
      <div><label class="ns-label" for="fi-st">Status</label><select id="fi-st" name="status" class="ns-input py-1.5"><option value="all">All</option>${STATUSES.map(x => `<option value="${x}" ${params.status === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
      <div class="flex items-end gap-2"><button class="btn-primary text-xs py-2 px-3">Apply filters</button><button type="button" class="btn-secondary text-xs py-2 px-3" onclick="window.navigate('admin-feedback')">Clear</button></div>
    </form>
    ${dissatisfied.length ? `<p class="text-xs bg-red-50 border border-red-200 text-red-800 rounded-lg p-2 mb-4"><strong>Dissatisfaction signals:</strong> <span translate="no">${fmtNum(dissatisfied.length)}</span> <span>items with a low rating, unsatisfactory work or incomplete work.</span></p>` : ''}
    ${r.data.length ? `<div class="space-y-3">${r.data.map(f => `<article class="bg-white rounded-2xl border ${f.rating <= 2 ? 'border-red-200' : 'border-slate-200'} p-4">
      <div class="flex flex-wrap items-start justify-between gap-2"><div>
        <div class="text-[11px] text-slate-500">${date(f.created_at)} · ${TYPES[f.feedback_type] || esc(f.feedback_type)}${f.complaint_id ? ` · <button class="underline text-teal-700" onclick="window.navigate('admin-complaint', {id: '${esc(f.complaint_id)}'})">${id(f.complaint_id)}</button>` : ''}</div>
        <div class="text-sm font-semibold mt-0.5">${u(f.citizen_name)} ${f.department_name ? `· <span class="text-[11px] text-slate-500">${esc(f.department_name)}</span>` : ''}</div></div>
        <div class="text-right text-xs"><div class="text-amber-500 text-base" translate="no" aria-label="${f.rating} / 5">${'★'.repeat(f.rating)}${'☆'.repeat(5 - f.rating)}</div>
          ${f.resolution_rating ? `<div><span>Resolution</span> <span translate="no">${f.resolution_rating}/5</span></div>` : ''}${f.department_rating ? `<div><span>Department</span> <span translate="no">${f.department_rating}/5</span></div>` : ''}</div></div>
      <p class="text-sm text-slate-800 mt-2">${u(f.message)}</p>
      ${f.improvement_suggestion ? `<p class="text-xs text-slate-600 mt-1"><strong>Suggestion:</strong> ${u(f.improvement_suggestion)}</p>` : ''}
      <div class="flex flex-wrap gap-2 mt-2 text-[11px]">${f.work_satisfactory ? `<span class="px-2 py-0.5 rounded-full bg-slate-100 border">${{ yes: 'Work satisfactory', partly: 'Work partly satisfactory', no: 'Work not satisfactory' }[f.work_satisfactory]}</span>` : ''}
        ${f.incomplete_work ? '<span class="px-2 py-0.5 rounded-full bg-red-50 border border-red-200 text-red-800">Incomplete work reported</span>' : ''}${f.repeated_issue ? '<span class="px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-800">Repeated issue</span>' : ''}
        ${f.complaint_status === 'Disputed' ? '<span class="px-2 py-0.5 rounded-full bg-red-50 border border-red-200 text-red-800">Resolution disputed</span>' : ''}</div>
      ${f.attachment_url ? `<a href="${esc(f.attachment_url)}" target="_blank" rel="noopener"><img src="${esc(f.attachment_url)}" alt="Supporting photograph" class="w-32 h-24 object-cover rounded-lg mt-2 border" /></a>` : ''}
      <div class="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3">
        <div class="md:col-span-1"><label class="ns-label" for="fr-${esc(f.id)}">Official response (sent to the citizen)</label><textarea id="fr-${esc(f.id)}" rows="2" class="ns-input text-xs">${esc(f.admin_response || '')}</textarea></div>
        <div><label class="ns-label" for="fa-${esc(f.id)}">Corrective action taken</label><textarea id="fa-${esc(f.id)}" rows="2" class="ns-input text-xs">${esc(f.action_taken || '')}</textarea></div>
        <div><label class="ns-label" for="fs-${esc(f.id)}">Status</label><select id="fs-${esc(f.id)}" class="ns-input text-xs py-1.5">X</select>
          <button class="btn-primary text-xs py-1.5 px-3 mt-2" onclick="window.fiSave('${esc(f.id)}')">Save</button></div>
      </div></article>`).join('')}</div>` : emptyState('No feedback matches these filters.')}`;
  return adminLayout('Citizen Feedback Inbox', 'Private feedback from citizens. It is never published.', content);
}

window.fiSave = async fid => {
  try {
    await api.updateFeedback(fid, { admin_response: document.getElementById(`fr-${fid}`).value, action_taken: document.getElementById(`fa-${fid}`).value, status: document.getElementById(`fs-${fid}`).value });
    showToast(t('Feedback updated'), 'success'); window.rerender();
  } catch (e) { showToast(t(e.message), 'error'); }
};
