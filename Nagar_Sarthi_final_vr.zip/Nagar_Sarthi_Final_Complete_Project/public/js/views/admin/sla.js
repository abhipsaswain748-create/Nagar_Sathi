// SLA & escalation board. Deadlines are the stored deadlines; "approaching" means within 24 hours.
import { api } from '../../api.js';
import { state } from '../../state.js';
import { t, fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, slaPill, priorityPill, emptyState, askText } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';
import { showToast } from '../../components/toast.js';

const BUCKETS = [['overdue', 'Overdue (SLA breached)', 'border-red-300'], ['due_today', 'Due today', 'border-orange-300'], ['approaching', 'Deadline approaching (24 h)', 'border-yellow-300'],
  ['escalated', 'Escalated', 'border-rose-300'], ['on_track', 'Within SLA', 'border-emerald-200']];

export async function renderSlaView(params = {}) {
  const r = await api.getComplaints();
  const open = r.data.filter(c => !['Resolved', 'Verified / Closed', 'Rejected'].includes(c.status));
  const inBucket = (c, k) => k === 'escalated' ? c.sla_state.startsWith('escalated') : k === 'overdue' ? c.sla_state === 'overdue' : c.sla_state === k;
  const sel = BUCKETS.find(b => b[0] === params.sla) ? params.sla : 'overdue';
  const list = open.filter(c => inBucket(c, sel)).sort((a, b) => a.sla_deadline.localeCompare(b.sla_deadline));
  // Predicted risk: open complaints that are not yet overdue but less than 25% of their SLA time is left and work has not started
  const risk = open.filter(c => ['approaching', 'due_today'].includes(c.sla_state) && ['Submitted', 'Under Review', 'Assigned'].includes(c.status));
  const content = `
    <div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">${BUCKETS.map(([k, l, b]) => `<button class="bg-white rounded-xl border-2 ${k === sel ? 'border-[#15324B]' : b} p-3 text-left" onclick="window.navigate('sla-monitor', {sla: '${k}'})">
      <div class="text-[11px] font-semibold text-slate-500">${l}</div><div class="text-2xl font-extrabold text-[#15324B]" translate="no">${fmtNum(open.filter(c => inBucket(c, k)).length)}</div></button>`).join('')}</div>
    <div class="grid grid-cols-1 xl:grid-cols-3 gap-5">
      <section class="xl:col-span-2"><h2 class="text-sm font-bold text-slate-900 mb-2">${(BUCKETS.find(b => b[0] === sel) || [])[1]}</h2>
        ${list.length ? `<div class="bg-white rounded-2xl border border-slate-200 overflow-x-auto"><table class="ns-table"><thead><tr><th>Complaint</th><th>Status</th><th>Priority</th><th>Actual deadline</th><th>SLA state</th><th><span class="sr-only">Actions</span></th></tr></thead><tbody>
          ${list.map(c => `<tr><td data-label="Complaint"><div class="text-[11px]">${id(c.id)}</div><div class="font-semibold">${u(c.title.slice(0, 70))}</div><div class="text-[11px] text-slate-500">${esc(c.department_name || '')}</div></td>
            <td data-label="Status">${statusPill(c.status)}</td><td data-label="Priority">${priorityPill(c.priority)}</td><td data-label="Actual deadline">${date(c.sla_deadline)}</td><td data-label="SLA state">${slaPill(c.sla_state)}</td>
            <td data-label=""><div class="flex gap-1"><button class="btn-secondary text-xs py-1 px-2" onclick="window.navigate('admin-complaint', {id: '${esc(c.id)}'})">Open</button>
            ${c.sla_state.startsWith('escalated') ? '' : `<button class="btn-secondary text-xs py-1 px-2 text-rose-800" onclick="window.slaEscalate('${esc(c.id)}')">Escalate</button>`}</div></td></tr>`).join('')}
        </tbody></table></div>` : emptyState('No complaints in this group.')}</section>
      <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold text-slate-900">Predicted deadline risk</h2>
        <p class="text-[11px] text-slate-500 mt-1">Rule-based estimate, not an actual breach: the deadline is within 24 hours or today, and field work has not started yet.</p>
        ${risk.length ? `<ul class="mt-3 space-y-2">${risk.map(c => `<li class="text-xs border border-amber-200 bg-amber-50 rounded-lg p-2"><button class="text-left w-full" onclick="window.navigate('admin-complaint', {id: '${esc(c.id)}'})">
          ${id(c.id)} · ${statusPill(c.status)}<div class="mt-1">${u(c.title.slice(0, 60))}</div><div class="text-[11px] text-amber-900 mt-1"><strong>Recommended action:</strong> assign a field worker or start work now.</div></button></li>`).join('')}</ul>`
          : '<p class="text-xs text-slate-500 mt-3">No complaints at predicted risk.</p>'}</section>
    </div>`;
  return adminLayout('SLA & Escalation', 'Actual deadlines, actual breaches and rule-based risk estimates are shown separately.', content);
}

window.slaEscalate = async cid => {
  const r = await askText(t('Escalate this complaint'), { label: t('Reason for escalation') });
  if (!r) return;
  try { await api.escalate(cid, r.value); showToast(t('Escalated'), 'success'); window.rerender(); } catch (e) { showToast(t(e.message), 'error'); }
};
