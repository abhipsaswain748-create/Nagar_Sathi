// Staff GIS map (exact locations within the user's scope)
import { renderCivicMap } from '../../components/civic-map.js';
import { adminLayout } from '../../components/sidebar.js';

export async function renderGisCommandView(params = {}) {
  return adminLayout('GIS Map', 'Exact complaint locations in your scope, with hotspot and incident layers.', await renderCivicMap(params, { staff: true, route: 'gis-command' }));
}
