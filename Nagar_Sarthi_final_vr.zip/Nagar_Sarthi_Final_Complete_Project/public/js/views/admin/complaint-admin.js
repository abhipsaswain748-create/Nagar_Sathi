// Staff complaint view: every administrative action is a real API call recorded in history and audit log.
import { api } from '../../api.js';
import { state } from '../../state.js';
import { Icons } from '../../icons.js';
import { t } from '../../i18n.js';
import { esc, u, soft, id, date, statusPill, priorityPill, slaPill, categoryChip, evidenceComparison, timeline, mountUploader, iconSm, ACTION_LABEL, roleLabel, askText, demoBadge, domainOf } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';
import { showToast } from '../../components/toast.js';

export async function renderAdminComplaintView(params) {
  const isAdminRole = state.isAdmin();
  const [{ data: c }, deps, offs] = await Promise.all([api.getComplaint(params.id), api.departments(), isAdminRole ? api.officers() : Promise.resolve({ data: [] })]);
  const closed = ['Verified / Closed', 'Rejected'].includes(c.status);
  const completion = c.attachments.filter(a => a.evidence_type === 'completion').length;
  window.__afterRender = () => wire(c);
  const content = `
  <button class="text-xs font-semibold text-slate-500 hover:text-slate-800 mb-3" onclick="window.navigate('${state.currentUser.role === 'field_officer' ? 'field-tasks' : 'complaints-mgmt'}')">← Back</button>
  <div class="grid grid-cols-1 xl:grid-cols-3 gap-5">
    <div class="xl:col-span-2 space-y-5">
      <section class="bg-white rounded-2xl border border-slate-200 p-5">
        <div class="flex flex-wrap items-start justify-between gap-3"><div class="min-w-0">
          <div class="text-xs text-slate-500">${id(c.id)} ${demoBadge(c.is_demo)} · <span>Submitted</span> ${date(c.created_at)}</div>
          <h2 class="text-xl font-extrabold text-[#15324B] mt-1">${u(c.title)}</h2>
          <div class="flex flex-wrap gap-2 mt-2">${categoryChip(c.category)}${priorityPill(c.priority)}</div></div>
          <div class="flex flex-col items-end gap-1.5">${statusPill(c.status)}${slaPill(c.sla_state)}</div></div>
        <p class="text-sm text-slate-800 mt-4 whitespace-pre-line">${u(c.description)}</p>
        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 text-xs">
          <div><dt class="text-slate-500">Citizen</dt><dd class="font-semibold">${u(c.citizen_name)} ${c.citizen_phone ? `· ${u(c.citizen_phone)}` : ''}</dd></div>
          <div><dt class="text-slate-500">Original language</dt><dd>${esc(c.original_language)}${c.transcription ? ' · <span>submitted by voice</span>' : ''}</dd></div>
          <div><dt class="text-slate-500">Location</dt><dd class="font-semibold">${u(c.location_address)}${c.landmark ? ` · ${u(c.landmark)}` : ''}</dd></div>
          <div><dt class="text-slate-500">Coordinates</dt><dd translate="no">${Number(c.latitude).toFixed(5)}, ${Number(c.longitude).toFixed(5)}</dd></div>
          <div><dt class="text-slate-500">Department</dt><dd class="font-semibold">${c.department_name ? esc(c.department_name) : '<span>Unassigned</span>'}</dd></div>
          <div><dt class="text-slate-500">Field worker</dt><dd class="font-semibold">${c.officer_name ? u(c.officer_name) : '<span>None assigned</span>'}</dd></div>
          <div><dt class="text-slate-500">SLA deadline</dt><dd>${date(c.sla_deadline)} <span translate="no">(${c.sla_hours} h)</span></dd></div>
          <div><dt class="text-slate-500">Category decided by</dt><dd>${c.category_source === 'ai' ? 'Citizen accepted AI suggestion' : c.category_source === 'ai_overridden' ? 'Citizen changed AI suggestion' : 'Citizen selected'}${c.ai_suggested_category ? ` · <span>AI suggested</span>: ${esc(domainOf(c.ai_suggested_category).title)}` : ''}</dd></div>
          ${c.parent_incident_id ? `<div><dt class="text-slate-500">Shared incident</dt><dd>${id(c.parent_incident_id)} ${state.currentUser.role === 'admin' ? `<button class="text-xs text-red-700 underline ml-1" onclick="window.caUnlink()">Remove from group</button>` : ''}</dd></div>` : ''}
          ${c.dispute_reason ? `<div class="sm:col-span-2"><dt class="text-slate-500">Citizen dispute reason</dt><dd class="text-red-800">${u(c.dispute_reason)}</dd></div>` : ''}
        </dl>
        <div id="ca-map" class="h-48 rounded-xl border border-slate-200 mt-4"></div>
      </section>
      <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold text-slate-900 mb-3">Evidence: before, during and after</h2>${evidenceComparison(c.attachments)}</section>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold text-slate-900 mb-3">Action history</h2>
          ${c.actions.length ? `<ul class="space-y-3">${c.actions.slice().reverse().map(a => `<li class="text-xs border-l-2 ${a.visible_to_citizen ? 'border-teal-500' : 'border-slate-400'} pl-3">
            <div class="font-bold text-slate-800">${ACTION_LABEL[a.action_type] || esc(a.action_type)} ${a.visible_to_citizen ? '' : '<span class="text-[10px] text-slate-500">(internal)</span>'}</div>
            <div class="text-slate-700">${soft(a.details)}</div><div class="text-[11px] text-slate-500">${u(a.actor_name)} · ${roleLabel(a.actor_role)} · ${date(a.created_at)}</div></li>`).join('')}</ul>` : '<p class="text-xs text-slate-500">No actions yet.</p>'}</section>
        <section class="bg-white rounded-2xl border border-slate-200 p-5"><h2 class="text-sm font-bold text-slate-900 mb-3">Status timeline</h2>${timeline(c.timeline)}</section>
      </div>
      <details class="bg-white rounded-2xl border border-slate-200 p-5"><summary class="text-sm font-bold text-slate-900 cursor-pointer">Audit log (${(c.audits || []).length})</summary>
        <ul class="mt-3 space-y-2 text-xs">${(c.audits || []).map(a => `<li class="border-b border-slate-100 pb-2"><span class="font-semibold font-mono" translate="no">${esc(a.event_type)}</span> · ${soft(a.action)} ${a.details ? `· ${soft(a.details)}` : ''}<div class="text-[11px] text-slate-500">${u(a.actor_name)} · ${roleLabel(a.actor_role)} · ${date(a.created_at)} · <span translate="no" class="font-mono">${esc(a.hash_signature)}</span></div></li>`).join('')}</ul></details>
    </div>

    <aside class="space-y-4" aria-label="Actions">
      ${isAdminRole && !closed ? `<section class="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
        <h2 class="text-sm font-bold text-slate-900">Administrative actions</h2>
        ${c.status === 'Submitted' ? `<button class="btn-primary w-full text-xs py-2 justify-center" onclick="window.caStatus('Under Review')">Mark as reviewed (Under Review)</button>` : ''}
        <div class="space-y-2 border-t border-slate-100 pt-3"><span class="ns-label">Assign</span>
          <label class="sr-only" for="ca-dept">Department</label><select id="ca-dept" class="ns-input py-1.5 text-xs" ${state.currentUser.role === 'dept_officer' ? 'disabled' : ''}>${deps.data.map(d => `<option value="${esc(d.id)}" ${d.id === c.department_id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select>
          <label class="sr-only" for="ca-off">Field worker</label><select id="ca-off" class="ns-input py-1.5 text-xs"><option value="">No field worker</option></select>
          <input id="ca-assign-note" class="ns-input py-1.5 text-xs" placeholder="Note (optional)" />
          <button class="btn-primary w-full text-xs py-2 justify-center" onclick="window.caAssign()">Save assignment</button></div>
        <div class="grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
          <button class="btn-secondary text-xs py-2 justify-center" onclick="window.caPriority()">Change priority</button>
          <button class="btn-secondary text-xs py-2 justify-center" onclick="window.caInfo()">Request information</button>
          <button class="btn-secondary text-xs py-2 justify-center" onclick="window.caRemark()">Add remark</button>
          <button class="btn-secondary text-xs py-2 justify-center text-rose-800" onclick="window.caEscalate()">Escalate</button>
        </div>
        ${c.status === 'Resolution Submitted' ? `<div class="border-t border-slate-100 pt-3 space-y-2"><p class="text-xs text-teal-900 bg-teal-50 border border-teal-200 rounded-lg p-2">The field team submitted completion evidence. Review the photographs, then approve or return the work.</p>
          <button class="btn-teal w-full text-xs py-2 justify-center" onclick="window.caStatus('Resolved')">Approve and ask the citizen to verify</button>
          <button class="btn-secondary w-full text-xs py-2 justify-center" onclick="window.caStatus('In Progress', true)">Return to field team for more work</button></div>` : ''}
        ${['Disputed'].includes(c.status) ? `<div class="border-t border-slate-100 pt-3"><p class="text-xs text-red-800 bg-red-50 border border-red-200 rounded-lg p-2 mb-2">The citizen disputed the resolution. Review the dispute and reopen the work if it is valid.</p>
          <button class="btn-primary w-full text-xs py-2 justify-center" onclick="window.caStatus('Reopened', true)">Reopen complaint</button></div>` : ''}
        <div class="border-t border-slate-100 pt-3 flex gap-2"><label class="sr-only" for="ca-status">Status</label>
          <select id="ca-status" class="ns-input py-1.5 text-xs">${['Under Review', 'Assigned', 'In Progress', ...(completion ? ['Resolved'] : []), 'Reopened', 'Rejected'].map(s => `<option value="${s}">${s === 'Resolved' ? 'Awaiting Citizen Verification' : s}</option>`).join('')}</select>
          <button class="btn-secondary text-xs py-1.5 px-3" onclick="window.caStatus(document.getElementById('ca-status').value, true)">Update</button></div>
        ${!completion ? '<p class="text-[11px] text-slate-500">"Awaiting Citizen Verification" becomes available after a completion photograph is uploaded.</p>' : ''}
      </section>` : ''}
      ${!closed ? `<section class="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
        <h2 class="text-sm font-bold text-slate-900">Upload field evidence</h2>
        <label class="ns-label" for="ev-type">Evidence type</label>
        <select id="ev-type" class="ns-input py-1.5 text-xs"><option value="inspection">Inspection photograph</option><option value="progress">Work-in-progress photograph</option><option value="completion">Completion photograph (submit for review)</option></select>
        <label class="ns-label" for="ev-notes">Notes</label><textarea id="ev-notes" rows="2" class="ns-input text-xs"></textarea>
        <div id="ev-up"></div>
        <button class="btn-teal w-full text-xs py-2 justify-center" onclick="window.caEvidence()">${iconSm(Icons.upload, 14)}<span>Save evidence</span></button>
        ${!isAdminRole ? `<button class="btn-secondary w-full text-xs py-2 justify-center" onclick="window.caRemark()">Add field remark</button>` : ''}
      </section>` : `<p class="text-xs bg-slate-50 border border-slate-200 rounded-xl p-3">This complaint is closed.</p>`}
    </aside>
  </div>`;
  window.__caOfficers = offs.data;
  return adminLayout(`<span translate="no">${esc(c.id)}</span>`, '', content);
}

let evUp = null;
function wire(c) {
  evUp = document.getElementById('ev-up') ? mountUploader(document.getElementById('ev-up'), { purpose: 'progress', max: 4 }) : null;
  const deptSel = document.getElementById('ca-dept'); const offSel = document.getElementById('ca-off');
  const fillOff = () => { if (!offSel) return; const list = (window.__caOfficers || []).filter(o => o.department_id === deptSel.value);
    offSel.innerHTML = `<option value="">${t('No field worker')}</option>` + list.map(o => `<option value="${esc(o.id)}" ${o.id === c.assigned_officer_id ? 'selected' : ''} translate="no">${esc(o.name)} (${o.open_tasks})</option>`).join(''); };
  if (deptSel) { deptSel.onchange = fillOff; fillOff(); }
  if (typeof L !== 'undefined' && document.getElementById('ca-map')) {
    import('../../components/map-picker.js').then(({ addBaseLayers }) => {
      const m = L.map('ca-map').setView([c.latitude, c.longitude], 16); addBaseLayers(m); L.marker([c.latitude, c.longitude]).addTo(m);
    });
  }
  const done = async (p, msg) => { try { const r = await p; showToast(t(msg || r.message), 'success'); window.rerender(); } catch (e) { showToast(t(e.message), 'error'); } };
  window.caStatus = async (s, ask) => {
    let notes = '';
    if (ask || ['Rejected', 'Reopened'].includes(s)) { const r = await askText(t('Reason / note for this status change'), { required: ['Rejected', 'Reopened', 'In Progress'].includes(s) }); if (!r) return; notes = r.value; }
    done(api.updateStatus(c.id, s, notes));
  };
  window.caAssign = () => done(api.assign(c.id, { department_id: deptSel.value, assigned_officer_id: offSel.value || null, notes: document.getElementById('ca-assign-note').value }));
  window.caPriority = async () => {
    const r = await askText(t('Change priority'), { label: t('Reason (required)'), extraHtml: `<label class="ns-label mt-3" for="ns-pri">${t('New priority')}</label><select id="ns-pri" data-extra="priority" class="ns-input">${['High', 'Medium', 'Low'].map(p => `<option value="${p}" ${p === c.priority ? 'selected' : ''}>${t(p)}</option>`).join('')}</select>` });
    if (r) done(api.setPriority(c.id, r.extra.priority, r.value));
  };
  window.caInfo = async () => { const r = await askText(t('Request more information from the citizen'), { label: t('What do you need to know?') }); if (r) done(api.requestInfo(c.id, r.value)); };
  window.caEscalate = async () => { const r = await askText(t('Escalate this complaint'), { label: t('Reason for escalation') }); if (r) done(api.escalate(c.id, r.value)); };
  window.caRemark = async () => {
    const r = await askText(t('Add remark'), { label: t('Remark'), extraHtml: state.isAdmin() ? `<label class="flex items-center gap-2 text-xs mt-3"><input type="checkbox" data-extra="visible" /> <span>${t('Show this remark to the citizen')}</span></label>` : '' });
    if (r) done(api.remark(c.id, r.value, !!r.extra.visible));
  };
  window.caEvidence = async () => {
    if (evUp && evUp.busy()) { showToast(t('Please wait until the photos finish uploading.'), 'warning'); return; }
    const type = document.getElementById('ev-type').value;
    const ids = evUp ? evUp.getIds() : [];
    if (!ids.length && type === 'completion') { showToast(t('A completion photograph is required.'), 'warning'); return; }
    if (!ids.length && !document.getElementById('ev-notes').value.trim()) { showToast(t('Add a photograph or a note.'), 'warning'); return; }
    done(api.evidence(c.id, type, document.getElementById('ev-notes').value.trim(), ids));
  };
  window.caUnlink = () => done(api.unlinkIncident(c.id));
}
