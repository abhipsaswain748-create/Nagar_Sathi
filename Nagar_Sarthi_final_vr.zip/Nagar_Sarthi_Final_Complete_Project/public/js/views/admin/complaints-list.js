// Complaint Management table: search, filters, sorting, pagination → detail view with all actions
import { api } from '../../api.js';
import { fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, priorityPill, slaPill, categoryChip, emptyState, demoBadge } from '../../ui.js';
import { adminLayout } from '../../components/sidebar.js';
import { filterBar } from './dashboard.js';

const PAGE = 15;
const SORTS = { created_at: 'Submitted', updated_at: 'Last updated', sla_deadline: 'SLA deadline', priority: 'Priority' };

export async function renderComplaintsListView(params = {}) {
  const [r, deps] = await Promise.all([api.getComplaints({ ...params, page: undefined, sort: undefined, dir: undefined }), api.departments()]);
  const sort = SORTS[params.sort] ? params.sort : 'created_at';
  const dir = params.dir === 'asc' ? 1 : -1;
  const pr = { High: 3, Medium: 2, Low: 1 };
  const rows = r.data.slice().sort((a, b) => sort === 'priority' ? (pr[a.priority] - pr[b.priority]) * dir : String(a[sort]).localeCompare(String(b[sort])) * dir);
  const page = Math.max(1, Number(params.page) || 1);
  const pages = Math.max(1, Math.ceil(rows.length / PAGE));
  const shown = rows.slice((page - 1) * PAGE, page * PAGE);
  const go = extra => `window.navigate('complaints-mgmt', ${esc(JSON.stringify({ ...params, ...extra }))})`;
  const search = `<div><label class="ns-label" for="ff-search">Search</label><input id="ff-search" name="search" value="${esc(params.search || '')}" class="ns-input py-1.5" placeholder="ID, title, area" /></div>`;
  const content = `${filterBar('complaints-mgmt', params, deps.data, { extra: search })}
    <div class="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs">
      <span class="text-slate-600"><span translate="no">${fmtNum(rows.length)}</span> <span>complaints found</span></span>
      <span class="flex items-center gap-2"><label for="cm-sort" class="font-semibold">Sort by</label>
        <select id="cm-sort" class="ns-input w-auto py-1" onchange="window.navigate('complaints-mgmt', Object.assign(${esc(JSON.stringify(params))}, {sort: this.value, page: 1}))">${Object.entries(SORTS).map(([k, l]) => `<option value="${k}" ${k === sort ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <button class="btn-secondary text-xs py-1 px-2" onclick="${go({ dir: dir === 1 ? 'desc' : 'asc', page: 1 })}" aria-label="Change sort direction">${dir === 1 ? '↑' : '↓'}</button></span>
    </div>
    ${shown.length ? `<div class="bg-white rounded-2xl border border-slate-200 overflow-x-auto"><table class="ns-table"><thead><tr>
      <th>Complaint</th><th>Domain</th><th>Location</th><th>Submitted</th><th>Priority</th><th>Department / field worker</th><th>Status</th><th>SLA deadline</th><th>Last updated</th><th><span class="sr-only">Open</span></th></tr></thead><tbody>
      ${shown.map(c => `<tr>
        <td data-label="Complaint" class="max-w-[260px]"><div class="text-[11px] text-slate-500">${id(c.id)} ${demoBadge(c.is_demo)}</div><div class="font-semibold text-slate-900">${u(c.title)}</div>
          <div class="text-[11px] text-slate-500 line-clamp-2">${u(c.description.slice(0, 110))}</div>${c.thumbnail_url ? '<span class="text-[10px] text-teal-700 font-bold">Photo attached</span>' : ''}</td>
        <td data-label="Domain">${categoryChip(c.category)}</td>
        <td data-label="Location">${u(c.locality)}</td>
        <td data-label="Submitted">${date(c.created_at)}</td>
        <td data-label="Priority">${priorityPill(c.priority)}</td>
        <td data-label="Department / field worker"><div>${c.department_name ? esc(c.department_name) : '<span class="text-slate-400">Unassigned</span>'}</div><div class="text-[11px] text-slate-500">${c.officer_name ? u(c.officer_name) : '<span>No field worker</span>'}</div></td>
        <td data-label="Status">${statusPill(c.status)}</td>
        <td data-label="SLA deadline"><div>${date(c.sla_deadline)}</div>${slaPill(c.sla_state)}</td>
        <td data-label="Last updated">${date(c.updated_at)}</td>
        <td data-label=""><button class="btn-primary text-xs py-1.5 px-3" onclick="window.navigate('admin-complaint', {id: '${esc(c.id)}'})">Manage</button></td></tr>`).join('')}
      </tbody></table></div>
      <div class="flex items-center justify-center gap-2 mt-4 text-xs">
        <button class="btn-secondary py-1 px-3" ${page <= 1 ? 'disabled' : ''} onclick="${go({ page: page - 1 })}">Previous</button>
        <span>${'Page'} <span translate="no">${page} / ${pages}</span></span>
        <button class="btn-secondary py-1 px-3" ${page >= pages ? 'disabled' : ''} onclick="${go({ page: page + 1 })}">Next</button></div>`
      : emptyState('No complaints match these filters.')}`;
  return adminLayout('Complaint Management', 'Review, assign, prioritise and follow every complaint in your scope.', content);
}
