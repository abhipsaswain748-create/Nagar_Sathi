// Field worker task list: only complaints assigned to this worker (enforced by the server)
import { api } from '../../api.js';
import { state } from '../../state.js';
import { fmtNum } from '../../i18n.js';
import { esc, u, id, date, statusPill, priorityPill, slaPill, categoryChip, emptyState } from '../../ui.js';

export async function renderFieldOfficerTasksView(params = {}) {
  const r = await api.getComplaints();
  const tab = params.tab || 'open';
  const open = r.data.filter(c => !['Resolved', 'Verified / Closed', 'Rejected', 'Resolution Submitted'].includes(c.status));
  const review = r.data.filter(c => c.status === 'Resolution Submitted');
  const done = r.data.filter(c => ['Resolved', 'Verified / Closed', 'Rejected'].includes(c.status));
  const list = tab === 'review' ? review : tab === 'done' ? done : open;
  return `<div class="max-w-6xl mx-auto px-4 py-8 w-full">
    <h1 class="text-2xl sm:text-3xl font-extrabold text-[#15324B] font-heading">My Field Tasks</h1>
    <p class="text-xs sm:text-sm text-slate-500 mt-1 mb-5"><span translate="no">${esc(state.currentUser.name)}</span> · <span>Open a task to upload inspection, work-in-progress and completion photographs. Completion is submitted for official review; you cannot close a complaint yourself.</span></p>
    <div class="flex gap-1.5 overflow-x-auto pb-2 mb-4" role="tablist">
      ${[['open', 'To do', open.length], ['review', 'Submitted for review', review.length], ['done', 'Completed', done.length]].map(([k, l, n]) => `<button role="tab" aria-selected="${k === tab}" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${k === tab ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200'}" onclick="window.navigate('field-tasks', {tab: '${k}'})">${l} <span translate="no">(${fmtNum(n)})</span></button>`).join('')}
    </div>
    ${list.length ? `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">${list.map(c => `<article class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="flex items-start justify-between gap-2"><div class="min-w-0"><div class="text-[11px] text-slate-500">${id(c.id)}</div><h2 class="text-sm font-bold">${u(c.title)}</h2>${categoryChip(c.category)}</div>${statusPill(c.status)}</div>
      <p class="text-xs text-slate-600 mt-2">${u(c.location_address)}</p>
      <div class="flex flex-wrap gap-2 mt-2">${priorityPill(c.priority)}${slaPill(c.sla_state)}</div>
      <p class="text-[11px] text-slate-500 mt-1"><span>Deadline</span>: ${date(c.sla_deadline)}</p>
      <button class="btn-primary text-xs py-2 px-3 mt-3" onclick="window.navigate('admin-complaint', {id: '${esc(c.id)}'})">Open task and upload evidence</button></article>`).join('')}</div>`
      : emptyState('No tasks in this list.')}</div>`;
}
