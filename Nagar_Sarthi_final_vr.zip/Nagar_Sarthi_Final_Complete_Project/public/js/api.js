// Client API. Session cookie is HttpOnly and sent automatically (same origin).
import { t } from './i18n.js';

async function request(endpoint, options = {}) {
  const config = { credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options };
  if (config.body && typeof config.body === 'object') config.body = JSON.stringify(config.body);
  let res;
  try { res = await fetch(endpoint, config); }
  catch (e) { const err = new Error(t('Network error. Check your connection and try again.')); err.code = 'NETWORK'; throw err; }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) {
    const err = new Error(data.error || `${t('Request failed')} (${res.status})`);
    err.status = res.status; err.code = data.code;
    if (res.status === 401 && window.onSessionExpired) window.onSessionExpired();
    throw err;
  }
  return data;
}
const qs = (o = {}) => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '' && v !== 'all') p.append(k, v); }); const s = p.toString(); return s ? `?${s}` : ''; };

export const api = {
  request,
  // auth
  me: () => request('/api/auth/me'),
  citizenLogin: (email, password, language) => request('/api/auth/citizen/login', { method: 'POST', body: { email, password, language } }),
  staffLogin: (email, password, language) => request('/api/auth/staff/login', { method: 'POST', body: { email, password, language } }),
  register: body => request('/api/auth/citizen/register', { method: 'POST', body }),
  logout: () => request('/api/auth/logout', { method: 'POST' }),
  savePreferences: lang => request('/api/auth/preferences', { method: 'PATCH', body: { preferred_language: lang } }),
  changePassword: (current_password, new_password) => request('/api/auth/change-password', { method: 'POST', body: { current_password, new_password } }),
  // complaints
  getComplaints: (f = {}) => request('/api/complaints' + qs(f)),
  getComplaint: id => request(`/api/complaints/${encodeURIComponent(id)}`),
  createComplaint: body => request('/api/complaints', { method: 'POST', body }),
  updateStatus: (id, status, notes) => request(`/api/complaints/${id}/status`, { method: 'PATCH', body: { status, notes } }),
  assign: (id, body) => request(`/api/complaints/${id}/assign`, { method: 'POST', body }),
  setPriority: (id, priority, reason) => request(`/api/complaints/${id}/priority`, { method: 'POST', body: { priority, reason } }),
  requestInfo: (id, message) => request(`/api/complaints/${id}/request-info`, { method: 'POST', body: { message } }),
  respondInfo: (id, message, media_ids) => request(`/api/complaints/${id}/respond-info`, { method: 'POST', body: { message, media_ids } }),
  escalate: (id, reason) => request(`/api/complaints/${id}/escalate`, { method: 'POST', body: { reason } }),
  remark: (id, text, visible_to_citizen) => request(`/api/complaints/${id}/remark`, { method: 'POST', body: { text, visible_to_citizen } }),
  confirm: (id, confirmation_type) => request(`/api/complaints/${id}/confirm`, { method: 'POST', body: { confirmation_type } }),
  evidence: (id, evidence_type, notes, media_ids) => request(`/api/complaints/${id}/evidence`, { method: 'POST', body: { evidence_type, notes, media_ids } }),
  verify: (id, verified, dispute_reason, media_ids) => request(`/api/complaints/${id}/verify`, { method: 'POST', body: { verified, dispute_reason, media_ids } }),
  publicMap: (f = {}) => request('/api/complaints-public-map' + qs(f)),
  // media
  uploadMedia: (data, purpose, complaint_id) => request('/api/media', { method: 'POST', body: { data, purpose, complaint_id } }),
  deleteMedia: id => request(`/api/media/${id}`, { method: 'DELETE' }),
  // ai / speech
  classify: (text, exclude = []) => request('/api/ai/classify', { method: 'POST', body: { text, exclude } }),
  chat: (message, language) => request('/api/ai/chat', { method: 'POST', body: { message, language } }),
  resolveLandmark: text => request('/api/ai/resolve-landmark', { method: 'POST', body: { text } }),
  speechConfig: () => request('/api/speech/config'),
  transcribe: (audio, language) => request('/api/speech/transcribe', { method: 'POST', body: { audio, language } }),
  // notifications
  getNotifications: () => request('/api/notifications'),
  markRead: id => request(`/api/notifications/${id}/read`, { method: 'POST' }),
  markAllRead: () => request('/api/notifications/read-all', { method: 'POST' }),
  // feedback
  getFeedback: (f = {}) => request('/api/feedback' + qs(f)),
  submitFeedback: body => request('/api/feedback', { method: 'POST', body }),
  updateFeedback: (id, body) => request(`/api/feedback/${id}`, { method: 'PATCH', body }),
  // reference / admin / intelligence
  departments: () => request('/api/departments'),
  officers: () => request('/api/officers'),
  publicStats: () => request('/api/public/stats'),
  overview: (f = {}) => request('/api/admin/overview' + qs(f)),
  deptStats: () => request('/api/admin/departments'),
  fieldWorkers: () => request('/api/admin/field-workers'),
  audit: (f = {}) => request('/api/admin/audit' + qs(f)),
  unlinkIncident: id => request(`/api/admin/incidents/${id}/unlink`, { method: 'POST' }),
  incidents: () => request('/api/intel/incidents'),
  recurring: (f = {}) => request('/api/intel/recurring' + qs(f)),
  hotspots: (f = {}) => request('/api/intel/hotspots' + qs(f)),
  weatherRisk: () => request('/api/weather/risk'),
  // legacy innovation modules (staff only)
  getCivicDNA: () => request('/api/innovations/civic-dna'),
  getCivicPulse: () => request('/api/innovations/civic-pulse'),
  getCivicEcho: () => request('/api/innovations/civic-echo'),
  getCivicForecast: () => request('/api/innovations/civic-forecast'),
  getCivicRoute: () => request('/api/innovations/civic-route'),
  dispatchRoute: body => request('/api/innovations/civic-route/dispatch', { method: 'POST', body }),
  getCivicProof: () => request('/api/innovations/civic-proof'),
  getCivicTrace: (complaintId) => request('/api/innovations/civic-trace' + qs({ complaint_id: complaintId })),
  getCharts: () => request('/api/analytics/charts')
};
