// Shared UI helpers: escaping, labels, pills, modal, photo uploader, evidence comparison
import { Icons, getCategoryIcon } from './icons.js';
import { t, fmtDate } from './i18n.js';
import { showToast } from './components/toast.js';

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
// Citizen/official-written content: escaped and never machine-altered by the translator
export function u(v) { return `<span translate="no">${esc(v)}</span>`; }
// System-generated text stored in English (timeline notes, action details): translated when it matches
// the catalogue, left unchanged otherwise (staff free text), and not reported as a missing key.
export function soft(v) { return `<span data-i18n-soft>${esc(v)}</span>`; }
export function date(iso, withTime = true) { return `<span translate="no">${esc(fmtDate(iso, withTime))}</span>`; }
export function id(v) { return `<span translate="no" class="font-mono">${esc(v)}</span>`; }

// ---- Civic issue domains (the 9 original categories + 2 added)
export const DOMAINS = [
  { category: 'Road damage / potholes', title: 'Roads & Potholes', icon: Icons.pothole, desc: 'Potholes, asphalt cave-ins, broken medians, damaged dividers, and hazardous road trenches.', subs: ['Pothole & Surface Crater', 'Road Cave-In / Subsidence', 'Broken Road Divider', 'Damaged Pavement / Paver Block'] },
  { category: 'Garbage accumulation', title: 'Waste Management & Garbage', icon: Icons.garbage, desc: 'Overflowing community dumpsters, uncollected market vegetable waste, and illegal debris dumping.', subs: ['Secondary Bin Overflow', 'Roadside Waste Heap', 'Market Vegetable Organic Waste', 'Construction Debris Dumping'] },
  { category: 'Drainage blockage', title: 'Drainage & Sewage', icon: Icons.drainage, urgent: true, desc: 'Choked concrete box drains, silted canal siphons, gutter backflow, and missing manhole covers.', subs: ['Open / Missing Manhole Cover', 'Silt-Choked Box Culvert', 'Drainage Sewage Overflow', 'Canal Embankment Siltation'] },
  { category: 'Water leakage', title: 'Water Supply', icon: Icons.water, desc: 'Main underground pipeline bursts, valve leaks, low pressure, and drinking water contamination.', subs: ['Pressurized Main Pipeline Burst', 'Feeder Line Valve Leakage', 'Contaminated Tap Supply', 'Low Pressure / No Supply'] },
  { category: 'Streetlight failure', title: 'Streetlights & Electricity', icon: Icons.streetlight, desc: 'Blacked-out LED street poles, flickering fixtures, dangling high-voltage cables, and dark junctions.', subs: ['Consecutive Dark Poles Outage', 'Flickering LED Luminaire', 'Exposed Electrical Junction Wire', 'Traffic Signal Blackout'] },
  { category: 'Damaged public infrastructure', title: 'Public Infrastructure', icon: Icons.infrastructure, desc: 'Damaged bus stop shelters, broken footbridge railings, public benches and other civic structures.', subs: ['Damaged Bus Shelter', 'Footbridge Railing Disrepair', 'Broken Public Bench', 'Pedestrian Crossing Signage'] },
  { category: 'Sanitation issues', title: 'Public Health & Sanitation', icon: Icons.broom, desc: 'Unhygienic community toilets, septic tank overflow, stagnant waste water, and mosquito breeding spots.', subs: ['Choked Community Toilet', 'Septic Tank Overflow', 'Open Waste Water Stagnation', 'Public Urinal Maintenance'] },
  { category: 'Waterlogging / flooding', title: 'Waterlogging & Flooding', icon: Icons.flood, desc: 'Rainwater accumulation, submerged underpasses, and road inundation.', subs: ['Service Road Waterlogging', 'Railway Underpass Flooding', 'Residential Colony Inundation', 'Natural Drainage Basin Choke'] },
  { category: 'Public safety hazards', title: 'Public Safety', icon: Icons.safety, urgent: true, desc: 'Open manholes, exposed live wires, unsafe structures and other hazards to people.', subs: ['Open Manhole', 'Exposed Live Wire', 'Unsafe Structure', 'Stray Cattle on Road'] },
  { category: 'Parks and public spaces', title: 'Parks & Public Spaces', icon: Icons.tree, desc: 'Broken play equipment, poorly maintained parks, damaged walking tracks and public grounds.', subs: ['Broken Play Equipment', 'Overgrown Park', 'Damaged Walking Track', 'Park Lighting'] },
  { category: 'Other civic problems', title: 'Other Civic Issues', icon: Icons.other, desc: 'Fallen tree branches, unauthorized hoardings, encroachments and other municipal concerns.', subs: ['Fallen Tree / Branch', 'Unauthorized Hoarding', 'Encroachment', 'General Civic Grievance'] }
];
export function domainOf(category) { return DOMAINS.find(d => d.category === category) || DOMAINS[DOMAINS.length - 1]; }

// ---- Status groups used by citizen tracking
export const STATUS_GROUPS = [
  { key: 'all', label: 'All', statuses: null },
  { key: 'pending', label: 'Pending', statuses: ['Submitted'] },
  { key: 'reviewed', label: 'Reviewed', statuses: ['Under Review'] },
  { key: 'assigned', label: 'Assigned', statuses: ['Assigned'] },
  { key: 'progress', label: 'In Progress', statuses: ['In Progress', 'Resolution Submitted', 'Escalated'] },
  { key: 'resolved', label: 'Resolved', statuses: ['Resolved', 'Verified / Closed'] },
  { key: 'disputed', label: 'Disputed', statuses: ['Disputed'] },
  { key: 'reopened', label: 'Reopened', statuses: ['Reopened'] },
  { key: 'rejected', label: 'Rejected', statuses: ['Rejected'] }
];
export const STATUS_LABEL = {
  'Submitted': 'Submitted', 'Under Review': 'Under Review', 'Assigned': 'Assigned', 'In Progress': 'In Progress',
  'Resolution Submitted': 'Resolution Submitted', 'Resolved': 'Awaiting Citizen Verification', 'Verified / Closed': 'Verified / Closed',
  'Disputed': 'Disputed', 'Reopened': 'Reopened', 'Escalated': 'Escalated', 'Rejected': 'Rejected'
};
const STATUS_STYLE = {
  'Submitted': 'bg-slate-100 text-slate-700 border-slate-300', 'Under Review': 'bg-sky-50 text-sky-800 border-sky-200',
  'Assigned': 'bg-indigo-50 text-indigo-800 border-indigo-200', 'In Progress': 'bg-blue-50 text-blue-800 border-blue-200',
  'Resolution Submitted': 'bg-teal-50 text-teal-800 border-teal-200', 'Resolved': 'bg-amber-50 text-amber-900 border-amber-300',
  'Verified / Closed': 'bg-emerald-50 text-emerald-800 border-emerald-200', 'Disputed': 'bg-red-50 text-red-800 border-red-200',
  'Reopened': 'bg-orange-50 text-orange-800 border-orange-200', 'Escalated': 'bg-rose-50 text-rose-800 border-rose-300',
  'Rejected': 'bg-slate-200 text-slate-700 border-slate-300'
};
export function statusPill(s) {
  return `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border ${STATUS_STYLE[s] || STATUS_STYLE.Submitted}">${esc(STATUS_LABEL[s] || s)}</span>`;
}
export function priorityPill(p) {
  const cls = p === 'High' ? 'bg-red-50 text-red-800 border-red-200' : p === 'Low' ? 'bg-slate-50 text-slate-600 border-slate-200' : 'bg-amber-50 text-amber-800 border-amber-200';
  const label = p === 'High' ? 'High Priority' : p === 'Low' ? 'Low Priority' : 'Medium Priority';
  return `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border ${cls}">${label}</span>`;
}
const SLA = {
  on_track: ['Within SLA', 'bg-emerald-50 text-emerald-800 border-emerald-200'],
  approaching: ['Deadline approaching', 'bg-yellow-50 text-yellow-900 border-yellow-300'],
  due_today: ['Due today', 'bg-orange-50 text-orange-900 border-orange-300'],
  overdue: ['Overdue (SLA breached)', 'bg-red-50 text-red-800 border-red-300'],
  escalated: ['Escalated', 'bg-rose-50 text-rose-800 border-rose-300'],
  escalated_overdue: ['Escalated and overdue', 'bg-red-100 text-red-900 border-red-400'],
  met: ['Resolved within SLA', 'bg-emerald-50 text-emerald-800 border-emerald-200'],
  breached_closed: ['Resolved after deadline', 'bg-slate-100 text-slate-700 border-slate-300'],
  closed: ['Closed', 'bg-slate-100 text-slate-700 border-slate-300']
};
export function slaPill(state) {
  const [label, cls] = SLA[state] || SLA.on_track;
  return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border ${cls}">${Icons.clock.replace('width="20" height="20"', 'width="12" height="12"')}${label}</span>`;
}
export function demoBadge(isDemo) {
  return isDemo ? '<span class="inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold bg-violet-50 text-violet-800 border border-violet-200">Demo data</span>' : '';
}
export function categoryChip(cat) {
  return `<span class="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700"><span class="w-4 h-4 inline-flex text-teal-700 [&>svg]:w-4 [&>svg]:h-4">${getCategoryIcon(cat)}</span>${esc(cat)}</span>`;
}
export function iconSm(svg, size = 16) { return svg.replace('width="20" height="20"', `width="${size}" height="${size}"`); }

export function emptyState(title, text = '', action = '') {
  return `<div class="text-center py-12 px-4 bg-white rounded-2xl border border-dashed border-slate-300">
    <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mb-3">${Icons.info}</div>
    <div class="font-bold text-slate-800 text-sm">${title}</div>${text ? `<p class="text-xs text-slate-500 mt-1 max-w-md mx-auto">${text}</p>` : ''}${action}</div>`;
}
export function loading() {
  return `<div class="flex items-center justify-center min-h-[40vh]" role="status"><div class="w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full animate-spin"></div><span class="sr-only">Loading...</span></div>`;
}
export function errorBox(msg) {
  return `<div class="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm" role="alert">${esc(msg)}</div>`;
}

// ---- Modal
export function openModal(html, { onClose, wide = false, labelledBy = 'ns-modal-title' } = {}) {
  closeModal();
  const prev = document.activeElement;
  const wrap = document.createElement('div');
  wrap.id = 'ns-modal';
  wrap.className = 'fixed inset-0 z-[9998] bg-slate-900/60 flex items-end sm:items-center justify-center p-0 sm:p-4';
  wrap.innerHTML = `<div role="dialog" aria-modal="true" aria-labelledby="${labelledBy}" class="bg-white w-full ${wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'} max-h-[92vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl shadow-2xl p-5 sm:p-6 relative">
    <button class="absolute top-3 right-3 p-2 rounded-lg text-slate-500 hover:bg-slate-100" aria-label="Close" data-close>${Icons.x}</button>${html}</div>`;
  document.body.appendChild(wrap);
  const close = () => { closeModal(); if (onClose) onClose(); if (prev && prev.focus) prev.focus(); };
  wrap.addEventListener('click', e => { if (e.target === wrap || e.target.closest('[data-close]')) close(); });
  wrap.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  const first = wrap.querySelector('input, textarea, select, button:not([data-close])');
  setTimeout(() => (first || wrap.querySelector('[data-close]')).focus(), 30);
  return { el: wrap, close };
}
export function closeModal() { const m = document.getElementById('ns-modal'); if (m) m.remove(); }

// Promise-based prompt for reasons (priority change, escalate, etc.)
export function askText(title, { label = 'Reason', required = true, multiline = true, confirmText = 'Confirm', extraHtml = '' } = {}) {
  return new Promise(resolve => {
    const m = openModal(`<h2 id="ns-modal-title" class="text-base font-bold text-slate-900 pr-8">${title}</h2>
      <label class="block text-xs font-bold text-slate-700 mt-4 mb-1" for="ns-ask">${label}${required ? ' *' : ''}</label>
      ${multiline ? '<textarea id="ns-ask" rows="3" class="ns-input"></textarea>' : '<input id="ns-ask" class="ns-input" />'}
      ${extraHtml}
      <p id="ns-ask-err" class="text-xs text-red-700 mt-1 hidden" role="alert">This field is required.</p>
      <div class="flex justify-end gap-2 mt-4"><button class="btn-secondary text-xs py-2 px-4" data-close>Cancel</button><button id="ns-ask-ok" class="btn-primary text-xs py-2 px-4">${confirmText}</button></div>`,
      { onClose: () => resolve(null) });
    m.el.querySelector('#ns-ask-ok').onclick = () => {
      const v = m.el.querySelector('#ns-ask').value.trim();
      if (required && !v) { m.el.querySelector('#ns-ask-err').classList.remove('hidden'); return; }
      const extra = {};
      m.el.querySelectorAll('[data-extra]').forEach(el => { extra[el.dataset.extra] = el.type === 'checkbox' ? el.checked : el.value; });
      closeModal(); resolve({ value: v, extra });
    };
  });
}

// ---- Photo uploader (validates, compresses on device, uploads with progress, preview + remove)
const ACCEPT = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_BYTES = 5 * 1024 * 1024;

function compress(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, 1600 / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error(t('This file is not a readable image.'))); };
    img.src = url;
  });
}

function postWithProgress(body, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/media');
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.upload.onprogress = e => { if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100)); };
    xhr.onload = () => {
      let d = {}; try { d = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && d.success) resolve(d.media); else reject(new Error(d.error || `${t('Upload failed')} (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error(t('Network error. Check your connection and try again.')));
    xhr.send(JSON.stringify(body));
  });
}

// Mounts an uploader into container; returns controller with getIds()
export function mountUploader(container, { purpose = 'complaint', max = 4, label = 'Add photograph', initial = [] } = {}) {
  const items = [...initial]; // {id, url, previewUrl}
  const uid = 'up' + Math.random().toString(36).slice(2, 8);
  function render() {
    container.innerHTML = `
      <div class="flex flex-wrap gap-3" id="${uid}-list">
        ${items.map((it, i) => `<div class="relative w-28 h-24 rounded-xl overflow-hidden border border-slate-300 bg-slate-100">
            <img src="${esc(it.previewUrl || it.url)}" alt="Uploaded photograph ${i + 1}" class="w-full h-full object-cover" />
            ${it.progress !== undefined && it.progress < 100 && !it.id ? `<div class="absolute inset-x-0 bottom-0 bg-black/60 text-white text-[10px] text-center py-0.5">${it.progress}%</div>` : ''}
            ${it.error ? `<div class="absolute inset-0 bg-red-700/80 text-white text-[10px] p-1 flex items-center text-center" role="alert">${esc(it.error)}</div>` : ''}
            <button type="button" data-rm="${i}" class="absolute top-1 right-1 bg-white/90 rounded-full p-1 text-red-700 shadow" aria-label="Remove photograph">${iconSm(Icons.trash, 14)}</button>
          </div>`).join('')}
        ${items.length < max ? `<label class="relative w-28 h-24 rounded-xl border-2 border-dashed border-slate-300 hover:border-teal-500 flex flex-col items-center justify-center text-slate-500 cursor-pointer text-[11px] font-semibold text-center px-1">
            ${Icons.camera}<span class="mt-1">${label}</span>
            <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" class="sr-only" ${max - items.length > 1 ? 'multiple' : ''} id="${uid}-input" />
          </label>` : ''}
      </div>
      <p class="text-[11px] text-slate-500 mt-2">JPEG, PNG or WEBP, up to 5 MB each, maximum ${max}. Location data inside the photo file is removed.</p>`;
    container.querySelectorAll('[data-rm]').forEach(b => b.onclick = async () => {
      const it = items[+b.dataset.rm];
      items.splice(+b.dataset.rm, 1); render();
      if (it && it.id) { try { await (await import('./api.js')).api.deleteMedia(it.id); } catch (e) {} }
    });
    const input = container.querySelector(`#${uid}-input`);
    if (input) input.onchange = e => handle([...e.target.files]);
  }
  async function handle(files) {
    for (const f of files.slice(0, max - items.length)) {
      if (!ACCEPT.includes(f.type)) { showToast(t('Only JPEG, PNG or WEBP photos are accepted.'), 'error'); continue; }
      if (f.size > 15 * MAX_BYTES) { showToast(t('This photo is too large.'), 'error'); continue; }
      const it = { previewUrl: URL.createObjectURL(f), progress: 0 };
      items.push(it); render();
      try {
        const data = await compress(f);
        if (data.length * 0.75 > MAX_BYTES) throw new Error(t('Photo is larger than 5 MB after compression.'));
        const media = await postWithProgress({ data, purpose }, p => { it.progress = p; render(); });
        it.id = media.id; it.url = media.url; it.progress = 100;
      } catch (err) { it.error = err.message; showToast(err.message, 'error'); }
      render();
    }
  }
  render();
  return {
    getIds: () => items.filter(i => i.id).map(i => i.id),
    getItems: () => items.filter(i => i.id),
    busy: () => items.some(i => !i.id && !i.error),
    reset: () => { items.length = 0; render(); }
  };
}

// ---- Evidence comparison: Before / Inspection / During work / After / Dispute
export function evidenceComparison(attachments = []) {
  const groups = [
    ['complaint', 'Before (citizen photographs)', 'border-red-300', 'bg-red-600'],
    ['inspection', 'Inspection', 'border-sky-300', 'bg-sky-600'],
    ['progress', 'During Work', 'border-amber-300', 'bg-amber-600'],
    ['completion', 'After (completion evidence)', 'border-emerald-300', 'bg-emerald-600'],
    ['dispute', 'Citizen dispute photographs', 'border-rose-300', 'bg-rose-700']
  ];
  return `<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">${groups.filter(g => g[0] !== 'dispute' || attachments.some(a => a.evidence_type === 'dispute')).map(([type, title, border, tag]) => {
    const list = attachments.filter(a => (a.evidence_type || 'complaint') === type);
    return `<div class="rounded-xl border ${border} p-3 bg-white">
      <div class="flex items-center justify-between mb-2"><span class="text-[11px] font-bold text-white ${tag} px-2 py-0.5 rounded">${title}</span><span class="text-[11px] text-slate-500">${list.length}</span></div>
      ${list.length ? `<div class="grid grid-cols-2 gap-2">${list.map(a => `<a href="${esc(a.url)}" target="_blank" rel="noopener" class="block">
          <img src="${esc(a.url)}" loading="lazy" alt="${esc(title)}" class="w-full h-24 object-cover rounded-lg border border-slate-200" />
          <div class="text-[10px] text-slate-500 mt-1 leading-tight"><span translate="no">${esc(a.uploaded_by_name || '')}</span> · ${date(a.created_at)}${a.is_demo ? ' · <span class="text-violet-700 font-bold">Demo data</span>' : ''}</div></a>`).join('')}</div>`
        : '<p class="text-xs text-slate-400 italic py-6 text-center">No photograph uploaded for this stage.</p>'}
    </div>`;
  }).join('')}</div>
  <p class="text-[11px] text-slate-500 mt-2">A completion photograph alone does not close a complaint. The citizen confirms or disputes the result.</p>`;
}

// ---- Timeline (only real recorded events)
export function timeline(events = []) {
  if (!events.length) return '<p class="text-xs text-slate-500">No events recorded yet.</p>';
  return `<ol class="relative border-l-2 border-slate-200 ml-2 space-y-4">${events.map(e => `<li class="ml-4">
      <span class="absolute -left-[7px] mt-1 w-3 h-3 rounded-full bg-teal-600 border-2 border-white"></span>
      <div class="flex flex-wrap items-center gap-2">${e.to_status ? statusPill(e.to_status) : `<span class="text-[11px] font-bold text-slate-700">${esc(e.label || '')}</span>`}<span class="text-[11px] text-slate-500">${date(e.created_at)}</span></div>
      ${e.notes ? `<p class="text-xs text-slate-700 mt-1">${soft(e.notes)}</p>` : ''}
      <p class="text-[11px] text-slate-500 mt-0.5">${u(e.actor_name || '')} · ${esc(roleLabel(e.actor_role))}</p></li>`).join('')}</ol>`;
}
export function roleLabel(r) {
  return { citizen: 'Citizen', admin: 'Administrator', dept_officer: 'Department Official', field_officer: 'Field Worker' }[r] || r || '';
}
export const ACTION_LABEL = {
  status_change: 'Status changed', department_assigned: 'Department assigned', field_worker_assigned: 'Field worker assigned',
  priority_change: 'Priority changed', info_requested: 'More information requested', citizen_reply: 'Citizen reply',
  escalated: 'Escalated', remark: 'Remark', location_corrected: 'Location corrected', evidence_inspection: 'Inspection evidence',
  evidence_progress: 'Work-in-progress evidence', evidence_completion: 'Completion evidence', citizen_verified: 'Citizen confirmed resolution',
  citizen_disputed: 'Citizen disputed resolution', incident_ungrouped: 'Removed from shared incident'
};
