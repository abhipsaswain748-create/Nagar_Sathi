// Nagar Sarthi internationalisation engine
// ------------------------------------------------------------
// Catalogue model (gettext style): the English source string is the translation key.
// Dictionaries live in /js/i18n/hi.js and /js/i18n/or.js and are checked for coverage by
// test/i18n-coverage.test.js (which renders every screen and fails on untranslated text).
//
// Two ways strings are translated:
//   1. t('English text', {vars})  - for strings built in JavaScript (toasts, confirms, aria labels).
//   2. translateDOM()             - every rendered view is passed through the catalogue; a
//      MutationObserver also translates anything inserted later (toasts, modals, map popups).
// Citizen-written content (complaint titles, descriptions, names) is wrapped in translate="no"
// so it is never altered. Language choice is saved in localStorage and in the user's profile.
import HI from './i18n/hi.js';
import OR from './i18n/or.js';

export const LANGUAGES = [
  { code: 'English', label: 'English', html: 'en' },
  { code: 'Hindi', label: 'हिन्दी', html: 'hi' },
  { code: 'Odia', label: 'ଓଡ଼ିଆ', html: 'or' }
];
const DICTS = { Hindi: HI, Odia: OR };
const STORAGE_KEY = 'ns_lang';
const ATTRS = ['placeholder', 'title', 'aria-label', 'alt', 'data-tip', 'content', 'data-label'];
// Keep the source English text for each live node so language changes are reversible
// even when the same DOM node is reused (e.g. map controls and dynamically mounted panels).
const originalText = new WeakMap();
const originalAttrs = new WeakMap();
const PASS = /^[…\s\d.,:;%°+\-−–/()#@|•·×✓★☆→←↑↓*!?'"&_=<>\[\]{}X]*$/; // nothing translatable

let current = (() => {
  try { const v = localStorage.getItem(STORAGE_KEY); if (DICTS[v] || v === 'English') return v; } catch (e) {}
  return 'English';
})();

// Pattern catalogue: entries containing {0} {1}... match text with numbers/IDs in those slots
const patternCache = {};
function patterns(lang) {
  if (patternCache[lang]) return patternCache[lang];
  const list = [];
  for (const [src, dst] of Object.entries(DICTS[lang] || {})) {
    if (!/\{\d\}/.test(src)) continue;
    const parts = src.split(/(\{\d\})/);
    const re = new RegExp('^' + parts.map(p => /^\{\d\}$/.test(p) ? '(.+?)' : p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('') + '$');
    const order = parts.filter(p => /^\{\d\}$/.test(p)).map(p => +p[1]);
    list.push({ re, dst, order, lit: src.replace(/\{\d\}/g, '').length });
  }
  // Most specific first: more literal text wins over a shorter, more general pattern
  list.sort((a, b) => b.lit - a.lit);
  return (patternCache[lang] = list);
}

window.__i18nMissing = window.__i18nMissing || new Set();
window.__i18nSoft = window.__i18nSoft || new Set();

function lookup(text, lang = current, softMode = false) {
  if (lang === 'English') return text;
  const dict = DICTS[lang];
  const key = text.replace(/\s+/g, ' ').trim();
  if (!key || PASS.test(key)) return text;
  if (/[\u0900-\u097F\u0B00-\u0B7F]/.test(key)) return text; // already Hindi/Odia
  const lead = text.match(/^\s*/)[0], trail = text.match(/\s*$/)[0];
  if (dict[key] !== undefined) return lead + dict[key] + trail;
  // Strip decorative separators ("· ", "→", "(", ":") and translate the core text
  const sep = key.match(/^([·•|→←✓:,(\s]*)(.*?)([·•|→←:,)\s]*)$/);
  if (sep && (sep[1] || sep[3]) && sep[2] && sep[2] !== key && (dict[sep[2]] !== undefined)) {
    return lead + sep[1] + dict[sep[2]] + sep[3] + trail;
  }
  for (const p of patterns(lang)) {
    const m = key.match(p.re);
    if (m) {
      let out = p.dst;
      p.order.forEach((slot, i) => { out = out.replace(`{${slot}}`, lookup(m[i + 1], lang, true)); });
      return lead + out + trail;
    }
  }
  if (!ALLOW_LATIN.test(key)) (softMode ? window.__i18nSoft : window.__i18nMissing).add(key);
  return text;
}
// Tokens that are legitimately the same in every language
const ALLOW_LATIN = /^(NS-\d{4}-\d+|INC-NS-\d{4}-\d+|[A-Z]{2,6}(-[A-Z0-9]+)?|[\w.+-]+@[\w.-]+|https?:\/\/\S+|\+?\d[\d\s-]+|English|हिन्दी|ଓଡ଼ିଆ|SLA|AI|ID|GPS|PNG|JPEG|WEBP|OSM|Esri|Leaflet|OpenStreetMap|Open-Meteo|CARTO|Azure|en-IN|hi-IN|or-IN|\d+\s?(MB|KB|mm|h|m|km|%))$/;

export function t(text, vars) {
  let out = lookup(String(text));
  if (vars) for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(v);
  return out;
}
export function getLanguage() { return current; }
export function htmlLang() { return (LANGUAGES.find(l => l.code === current) || LANGUAGES[0]).html; }
export function locale() { return current === 'Hindi' ? 'hi-IN' : current === 'Odia' ? 'or-IN' : 'en-IN'; }

export function setLanguage(lang) {
  if (!LANGUAGES.some(l => l.code === lang)) return;
  current = lang;
  try { localStorage.setItem(STORAGE_KEY, lang); } catch (e) {}
  document.documentElement.lang = htmlLang();
  // Translate the current view immediately; the router may subsequently re-render it.
  if (typeof document !== 'undefined') { if (document.head) translateDOM(document.head); if (document.body) translateDOM(document.body); }
}

function skip(node) {
  for (let el = node.nodeType === 1 ? node : node.parentElement; el; el = el.parentElement) {
    if (el.getAttribute && (el.getAttribute('translate') === 'no' || el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.tagName === 'TEXTAREA' || el.classList.contains('leaflet-control-attribution'))) return true;
  }
  return false;
}

let busy = false;
function translatedText(node) {
  const previous = originalText.get(node);
  const source = previous && node.nodeValue === previous.rendered ? previous.source : node.nodeValue;
  const rendered = lookup(source, current);
  originalText.set(node, { source, rendered });
  if (rendered !== node.nodeValue) node.nodeValue = rendered;
}
function translatedAttribute(el, attr) {
  const value = el.getAttribute(attr);
  if (!value) return;
  let records = originalAttrs.get(el);
  if (!records) { records = new Map(); originalAttrs.set(el, records); }
  const previous = records.get(attr);
  const source = previous && value === previous.rendered ? previous.source : value;
  const rendered = lookup(source, current);
  records.set(attr, { source, rendered });
  if (rendered !== value) el.setAttribute(attr, rendered);
}
export function translateDOM(root = document.body) {
  if (!root) return;
  busy = true;
  try {
    if (root.nodeType === 3) { if (!skip(root)) translatedText(root); return; }
    if (root.nodeType !== 1 || skip(root)) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, {
      acceptNode: n => (n.nodeType === 1 && (n.getAttribute('translate') === 'no' || ['SCRIPT', 'STYLE', 'TEXTAREA'].includes(n.tagName))) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const els = [root];
    let n;
    while ((n = walker.nextNode())) {
      if (n.nodeType === 3) {
        if (n.nodeValue.trim() && !skip(n)) translatedText(n);
      } else els.push(n);
    }
    for (const el of els) {
      for (const a of ATTRS) translatedAttribute(el, a);
      if (el.tagName === 'INPUT' && ['button', 'submit'].includes(el.type) && el.value) {
        // Input button values are translated as attributes too, while preserving their source.
        translatedAttribute(el, 'value');
      }
    }
    // Textareas are skipped by the walker (their content is user text) but placeholders are UI text.
    const tas = root.tagName === 'TEXTAREA' ? [root] : [...root.querySelectorAll('textarea[placeholder]')];
    for (const ta of tas) if (!ta.closest('[translate="no"]')) translatedAttribute(ta, 'placeholder');
  } finally { busy = false; }
}
export function startObserver() {
  document.documentElement.lang = htmlLang();
  const obs = new MutationObserver(muts => {
    if (busy || current === 'English') return;
    for (const m of muts) {
      if (m.type === 'characterData') translateDOM(m.target);
      else if (m.type === 'attributes') { if (ATTRS.includes(m.attributeName)) translateDOM(m.target); }
      else m.addedNodes.forEach(node => translateDOM(node));
    }
  });
  obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
}

// ---- Labels for data values stored in English in the database
export const CATEGORY_KEYS = ['Road damage / potholes', 'Garbage accumulation', 'Drainage blockage', 'Water leakage', 'Streetlight failure',
  'Waterlogging / flooding', 'Damaged public infrastructure', 'Sanitation issues', 'Public safety hazards', 'Parks and public spaces', 'Other civic problems'];
export function tCategory(c) { return t(c); }
export function tStatus(s) { return t(s); }
export function tPriority(p) { return t(p); }

const OR_MONTHS = ['ଜାନୁଆରୀ', 'ଫେବୃଆରୀ', 'ମାର୍ଚ୍ଚ', 'ଅପ୍ରେଲ', 'ମେ', 'ଜୁନ', 'ଜୁଲାଇ', 'ଅଗଷ୍ଟ', 'ସେପ୍ଟେମ୍ବର', 'ଅକ୍ଟୋବର', 'ନଭେମ୍ବର', 'ଡିସେମ୍ବର'];
export function fmtDate(iso, withTime = true) {
  if (!iso) return '-';
  const d = new Date(iso);
  if (isNaN(d)) return '-';
  if (current !== 'English') {
    // Browsers often lack Odia date data and print English month names; format explicitly (IST, 24-hour)
    const ist = new Date(d.getTime() + 5.5 * 3600e3);
    const day = ist.getUTCDate(), m = ist.getUTCMonth(), y = ist.getUTCFullYear();
    const hh = String(ist.getUTCHours()).padStart(2, '0'), mm = String(ist.getUTCMinutes()).padStart(2, '0');
    const month = current === 'Odia' ? OR_MONTHS[m] : d.toLocaleString('hi-IN', { month: 'short', timeZone: 'Asia/Kolkata' });
    return `${day} ${month} ${y}${withTime ? `, ${hh}:${mm}` : ''}`;
  }
  return d.toLocaleString(locale(), withTime ? { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' } : { dateStyle: 'medium', timeZone: 'Asia/Kolkata' });
}
export function fmtNum(n) { return n === null || n === undefined ? '-' : Number(n).toLocaleString(locale()); }
