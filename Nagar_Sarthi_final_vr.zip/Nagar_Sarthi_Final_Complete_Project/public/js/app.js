// Nagar Sarthi application controller: routing, server-verified access guards, language & notifications
import { state } from './state.js';
import { api } from './api.js';
import { showToast } from './components/toast.js';
import { renderNavbar } from './components/navbar.js';
import { renderAIAssistant } from './components/ai-assistant.js';
import { setLanguage, getLanguage, translateDOM, startObserver, t } from './i18n.js';
import { loading, esc } from './ui.js';

import { renderLandingView } from './views/public/landing.js';
import { renderPublicMapView } from './views/public/public-map.js';
import { renderAboutView } from './views/public/about.js';
import { renderLegalPoliciesView } from './views/public/legal-policies.js';
import { renderCitizenLoginView } from './views/auth/citizen-login.js';
import { renderAdminLoginView } from './views/auth/admin-login.js';
import { renderCitizenDashboardView } from './views/citizen/dashboard.js';
import { renderReportFormView } from './views/citizen/report-form.js';
import { renderMyComplaintsView } from './views/citizen/my-complaints.js';
import { renderComplaintDetailView } from './views/citizen/complaint-detail.js';
import { renderCommunityView } from './views/citizen/community.js';
import { renderFeedbackView } from './views/citizen/feedback-modal.js';
import { renderSettingsView } from './views/settings.js';
import { renderAdminDashboardView } from './views/admin/dashboard.js';
import { renderComplaintsListView } from './views/admin/complaints-list.js';
import { renderAdminComplaintView } from './views/admin/complaint-admin.js';
import { renderDepartmentsView } from './views/admin/departments.js';
import { renderFieldWorkersView } from './views/admin/field-workers.js';
import { renderSlaView } from './views/admin/sla.js';
import { renderIntelligenceView } from './views/admin/intelligence.js';
import { renderAuditView } from './views/admin/audit.js';
import { renderAdminFeedbackInbox } from './views/admin/feedback-inbox.js';
import { renderGisCommandView } from './views/admin/gis-command.js';
import { renderFieldOfficerTasksView } from './views/field-officer/tasks.js';

const CITIZEN = ['citizen'];
const ADMINS = ['admin', 'dept_officer'];
const STAFF = ['admin', 'dept_officer', 'field_officer'];
const ANY = ['citizen', ...STAFF];

// route -> [view, allowed roles (null = public)]
const ROUTES = {
  'home': [renderLandingView, null],
  'about': [renderAboutView, null],
  'legal-policies': [renderLegalPoliciesView, null],
  'trust': [renderLegalPoliciesView, null],
  'citizen-login': [renderCitizenLoginView, null],
  'citizen-register': [p => renderCitizenLoginView({ ...p, mode: 'register' }), null],
  'admin-login': [renderAdminLoginView, null],
  'public-map': [renderPublicMapView, null],
  'community-issues': [renderCommunityView, null],
  'citizen-dashboard': [renderCitizenDashboardView, CITIZEN],
  'report-issue': [renderReportFormView, CITIZEN],
  'my-complaints': [renderMyComplaintsView, CITIZEN],
  'complaint-detail': [renderComplaintDetailView, ANY],
  'feedback': [renderFeedbackView, CITIZEN],
  'settings': [renderSettingsView, ANY],
  'admin-dashboard': [renderAdminDashboardView, ADMINS],
  'complaints-mgmt': [renderComplaintsListView, ADMINS],
  'admin-complaint': [renderAdminComplaintView, STAFF],
  'departments-mgmt': [renderDepartmentsView, ADMINS],
  'field-workers': [renderFieldWorkersView, ADMINS],
  'sla-monitor': [renderSlaView, ADMINS],
  'intelligence': [renderIntelligenceView, ADMINS],
  'audit-log': [renderAuditView, ADMINS],
  'admin-feedback': [renderAdminFeedbackInbox, ADMINS],
  'gis-command': [renderGisCommandView, ADMINS],
  'field-tasks': [renderFieldOfficerTasksView, ['field_officer']]
};

function parseHash() {
  const raw = window.location.hash.replace(/^#\/?/, '') || 'home';
  const [path, q] = raw.split('?');
  const [route, id] = path.split('/');
  const params = { id: id ? decodeURIComponent(id) : null };
  new URLSearchParams(q || '').forEach((v, k) => { params[k] = v; });
  return { route: route || 'home', params };
}

function renderShell() {
  const nav = document.getElementById('navbar-container');
  if (nav) nav.innerHTML = renderNavbar();
  const ai = document.getElementById('ai-companion-container');
  if (ai && !ai.dataset.mounted) { ai.innerHTML = renderAIAssistant(); ai.dataset.mounted = '1'; }
  translateDOM(document.getElementById('navbar-container'));
}

let renderSeq = 0;
async function handleRouting() {
  const seq = ++renderSeq;
  const { route, params } = parseHash();
  const entry = ROUTES[route] || ROUTES.home;
  state.activeRoute = ROUTES[route] ? route : 'home';
  state.routeParams = params;
  const roles = entry[1];
  const main = document.getElementById('main-content');

  if (roles && (!state.currentUser || !roles.includes(state.currentUser.role))) {
    if (!state.currentUser) {
      const staffArea = !roles.includes('citizen');
      sessionStorage.setItem('ns_after_login', window.location.hash);
      window.location.hash = staffArea ? '#admin-login' : '#citizen-login';
      return;
    }
    renderShell();
    main.innerHTML = `<div class="max-w-xl mx-auto p-8 text-center"><h1 class="text-xl font-bold text-slate-900">Access denied</h1>
      <p class="text-sm text-slate-600 mt-2">Your account does not have permission to open this page.</p>
      <button class="btn-primary mt-4 py-2 px-4 text-sm" onclick="window.goHomeForRole()">Go to my dashboard</button></div>`;
    translateDOM(main);
    return;
  }

  renderShell();
  main.innerHTML = loading();
  try {
    const html = await entry[0](params);
    if (seq !== renderSeq) return;
    if (html instanceof HTMLElement) { main.innerHTML = ''; main.appendChild(html); } else main.innerHTML = html;
    translateDOM(main);
    document.title = `Nagar Sarthi | ${(main.querySelector('h1') || {}).textContent || 'Nagar Sarthi'}`.trim();
    if (window.__afterRender) { const f = window.__afterRender; window.__afterRender = null; await f(); translateDOM(main); }
    main.focus({ preventScroll: true });
  } catch (err) {
    console.error('Route render error:', err);
    if (seq !== renderSeq) return;
    main.innerHTML = `<div class="max-w-xl mx-auto p-8"><div class="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm" role="alert">
      <strong>Could not load this page.</strong> <span>${esc(err.message)}</span></div>
      <button class="btn-secondary mt-4 py-2 px-4 text-sm" onclick="window.location.reload()">Try again</button></div>`;
    translateDOM(main);
  }
}

// ---------- globals used by inline handlers
window.navigate = (route, params = {}) => state.setRoute(route, params);
window.rerender = () => handleRouting();
window.goHomeForRole = () => {
  const r = state.currentUser && state.currentUser.role;
  window.navigate(r === 'citizen' ? 'citizen-dashboard' : r === 'field_officer' ? 'field-tasks' : r ? 'admin-dashboard' : 'home');
};

window.switchLanguage = async lang => {
  setLanguage(lang);
  if (state.currentUser) { try { await api.savePreferences(lang); state.currentUser.preferred_language = lang; } catch (e) {} }
  const ai = document.getElementById('ai-companion-container');
  if (ai) { ai.dataset.mounted = ''; }
  await handleRouting();
  showToast(t('Language changed'), 'success', 2000);
};

window.afterLogin = async user => {
  state.setUser(user);
  if (user.preferred_language && user.preferred_language !== getLanguage()) setLanguage(user.preferred_language);
  await refreshNotifications();
  const back = sessionStorage.getItem('ns_after_login');
  sessionStorage.removeItem('ns_after_login');
  const ai = document.getElementById('ai-companion-container'); if (ai) ai.dataset.mounted = '';
  if (back && !/login/.test(back)) { window.location.hash = back; if (window.location.hash === back) handleRouting(); }
  else window.goHomeForRole();
};

window.logout = async () => {
  try { await api.logout(); } catch (e) {}
  state.setUser(null); state.setNotifications([]);
  const ai = document.getElementById('ai-companion-container'); if (ai) ai.dataset.mounted = '';
  showToast(t('You have been logged out.'), 'info');
  window.navigate('home');
};

window.onSessionExpired = () => {
  if (state.currentUser) { state.setUser(null); showToast(t('Your session has ended. Please log in again.'), 'warning'); renderShell(); }
};

window.toggleThemeNav = () => {
  const dark = document.documentElement.classList.toggle('dark');
  try { localStorage.setItem('ns_theme', dark ? 'dark' : 'light'); } catch (e) {}
  renderShell();
};
window.toggleMobileMenu = btn => {
  const m = document.getElementById('mobile-menu');
  const open = m.classList.toggle('hidden') === false;
  btn.setAttribute('aria-expanded', String(open));
};
window.toggleNotifications = e => {
  if (e) e.stopPropagation();
  const el = document.getElementById('notif-dropdown');
  if (el) el.classList.toggle('hidden');
};
document.addEventListener('click', e => {
  const n = document.getElementById('notif-dropdown');
  if (n && !n.classList.contains('hidden') && !e.target.closest('#notif-dropdown')) n.classList.add('hidden');
  const um = document.getElementById('user-menu');
  if (um && !um.classList.contains('hidden') && !e.target.closest('#user-menu') && !e.target.closest('[aria-haspopup]')) um.classList.add('hidden');
});

async function refreshNotifications() {
  if (!state.currentUser) { state.setNotifications([]); return; }
  try { const r = await api.getNotifications(); state.setNotifications(r.data); } catch (e) {}
}
window.refreshNotifications = async () => { await refreshNotifications(); renderShell(); };
window.markAllNotifsRead = async () => {
  try { await api.markAllRead(); await refreshNotifications(); renderShell(); showToast(t('All notifications marked as read'), 'success'); }
  catch (e) { showToast(e.message, 'error'); }
};
window.openNotification = async (id, complaintId) => {
  try { await api.markRead(id); } catch (e) {}
  await refreshNotifications();
  if (complaintId) window.navigate(state.isStaff() ? 'admin-complaint' : 'complaint-detail', { id: complaintId });
  else renderShell();
};

async function bootstrap() {
  try { if (localStorage.getItem('ns_theme') === 'dark') document.documentElement.classList.add('dark'); } catch (e) {}
  startObserver();
  try {
    const me = await api.me();
    if (me.user) {
      state.setUser(me.user);
      // Profile language wins only when the browser has no saved choice
      let saved = null; try { saved = localStorage.getItem('ns_lang'); } catch (e) {}
      if (!saved && me.user.preferred_language) setLanguage(me.user.preferred_language);
    }
  } catch (e) { console.warn('Session check failed', e); }
  await refreshNotifications();
  setInterval(async () => { if (state.currentUser) { const before = state.unreadNotifications; await refreshNotifications(); if (state.unreadNotifications !== before) renderShell(); } }, 60000);
  window.addEventListener('hashchange', handleRouting);
  handleRouting();
}

bootstrap();
