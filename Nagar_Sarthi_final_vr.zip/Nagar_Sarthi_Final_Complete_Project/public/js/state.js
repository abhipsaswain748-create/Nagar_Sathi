// Application state. The user object always comes from the server session (/api/auth/me);
// the browser never decides the role.
import { getLanguage } from './i18n.js';

export const state = {
  currentUser: null,
  get currentLanguage() { return getLanguage(); },
  activeRoute: 'home',
  routeParams: {},
  notifications: [],
  unreadNotifications: 0,

  setUser(user) { this.currentUser = user || null; },
  setRoute(route, params = {}) {
    this.activeRoute = route;
    this.routeParams = params;
    const qs = Object.entries(params).filter(([k, v]) => k !== 'id' && v !== undefined && v !== null && v !== '')
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
    const hash = '#' + route + (params.id ? `/${encodeURIComponent(params.id)}` : '') + (qs ? `?${qs}` : '');
    if (window.location.hash === hash) window.dispatchEvent(new HashChangeEvent('hashchange'));
    else window.location.hash = hash;
    window.scrollTo({ top: 0 });
  },
  setNotifications(list) {
    this.notifications = list || [];
    this.unreadNotifications = this.notifications.filter(n => !n.is_read).length;
  },
  isStaff() { return !!this.currentUser && ['admin', 'dept_officer', 'field_officer'].includes(this.currentUser.role); },
  isAdmin() { return !!this.currentUser && ['admin', 'dept_officer'].includes(this.currentUser.role); },
  isCitizen() { return !!this.currentUser && this.currentUser.role === 'citizen'; }
};
