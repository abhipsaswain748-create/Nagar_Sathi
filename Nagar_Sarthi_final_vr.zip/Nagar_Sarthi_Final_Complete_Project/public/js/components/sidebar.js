// Administrative navigation (desktop sidebar + scrollable tab strip on small screens)
import { state } from '../state.js';
import { Icons } from '../icons.js';
import { esc, iconSm, roleLabel } from '../ui.js';

const ITEMS = [
  ['admin-dashboard', 'Overview', Icons.activity],
  ['complaints-mgmt', 'Complaint Management', Icons.fileText],
  ['sla-monitor', 'SLA & Escalation', Icons.clock],
  ['departments-mgmt', 'Departments', Icons.building],
  ['field-workers', 'Field Workers', Icons.hardhat],
  ['admin-feedback', 'Feedback Inbox', Icons.messageSquare],
  ['intelligence', 'Civic Intelligence', Icons.chart],
  ['gis-command', 'GIS Map', Icons.map],
  ['audit-log', 'Audit Log', Icons.civicTrace]
];

export function renderAdminSidebar() {
  const cur = state.activeRoute;
  const u = state.currentUser || {};
  const item = ([r, l, ic]) => `<button onclick="window.navigate('${r}')" ${cur === r ? 'aria-current="page"' : ''} class="w-full flex items-center gap-2.5 px-3 py-2 text-sm rounded-xl transition ${cur === r ? 'bg-teal-700 text-white font-bold' : 'text-slate-300 hover:bg-slate-800 hover:text-white'}">${iconSm(ic, 16)}<span>${l}</span></button>`;
  return `<aside class="w-64 bg-[#122B40] text-slate-200 flex-shrink-0 p-4 hidden lg:flex flex-col gap-4" aria-label="Administrator navigation">
      <div class="px-3 py-2.5 bg-[#1B3B52] rounded-xl border border-slate-700/50">
        <div class="text-[10px] font-bold text-teal-300">Administrator Portal</div>
        <div class="font-bold text-sm text-white mt-0.5" translate="no">${esc(u.name || '')}</div>
        <div class="text-[11px] text-slate-300">${roleLabel(u.role)}</div>
      </div>
      <nav class="space-y-1">${ITEMS.map(item).join('')}</nav>
    </aside>`;
}

export function renderAdminTabs() {
  const cur = state.activeRoute;
  return `<nav class="lg:hidden flex gap-1.5 overflow-x-auto pb-2 mb-4" aria-label="Administrator navigation">${ITEMS.map(([r, l]) =>
    `<button onclick="window.navigate('${r}')" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border ${cur === r ? 'bg-[#15324B] text-white border-[#15324B]' : 'bg-white text-slate-700 border-slate-200'}">${l}</button>`).join('')}</nav>`;
}

export function adminLayout(title, subtitle, content, actions = '') {
  if (state.currentUser && state.currentUser.role === 'field_officer') {
    return `<div class="max-w-7xl mx-auto w-full p-4 sm:p-6"><div class="flex flex-wrap items-end justify-between gap-3 mb-5"><div><h1 class="text-2xl font-extrabold text-[#15324B] font-heading">${title}</h1>${subtitle ? `<p class="text-xs sm:text-sm text-slate-500 mt-1">${subtitle}</p>` : ''}</div>${actions}</div>${content}</div>`;
  }
  return `<div class="flex-1 flex w-full min-w-0">${renderAdminSidebar()}
    <div class="flex-1 min-w-0 overflow-x-hidden p-4 sm:p-6 lg:p-8 bg-[#F3F6F8]">${renderAdminTabs()}
      <div class="flex flex-wrap items-end justify-between gap-3 mb-5"><div><h1 class="text-2xl font-extrabold text-[#15324B] font-heading">${title}</h1>${subtitle ? `<p class="text-xs sm:text-sm text-slate-500 mt-1">${subtitle}</p>` : ''}</div>${actions}</div>
      ${content}</div></div>`;
}
