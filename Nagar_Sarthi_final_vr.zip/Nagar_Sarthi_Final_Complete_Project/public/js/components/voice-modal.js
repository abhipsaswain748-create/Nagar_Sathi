// Voice complaint recorder — genuine speech capture only.
// Engine 1: the browser's Web Speech API (live transcript; availability and supported languages
//           depend on the browser). Engine 2: server-side Azure Speech (16 kHz mono WAV recorded here,
//           sent to /api/speech/transcribe; only if the administrator configured a key).
// The spoken language is chosen explicitly and is independent of the website display language.
// Nothing is ever inserted unless audio was actually recognised. No confidence numbers are invented.
import { api } from '../api.js';
import { Icons } from '../icons.js';
import { t, translateDOM } from '../i18n.js';
import { esc, iconSm, openModal, closeModal } from '../ui.js';

const LOCALE = { English: 'en-IN', Hindi: 'hi-IN', Odia: 'or-IN' };
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let cfg = null;
let s = null; // session state

function setState(name, msg) {
  s.state = name;
  const el = document.getElementById('vr-status');
  if (el) { el.textContent = t(msg); el.dataset.state = name; }
  const rec = document.getElementById('vr-rec');
  const stop = document.getElementById('vr-stop');
  const ind = document.getElementById('vr-indicator');
  const recording = name === 'recording';
  if (rec) rec.disabled = !s.lang || recording || ['requesting', 'uploading', 'processing'].includes(name);
  if (stop) stop.classList.toggle('hidden', !recording);
  if (ind) ind.classList.toggle('hidden', !recording);
  const confirmBtn = document.getElementById('vr-confirm');
  if (confirmBtn) confirmBtn.disabled = recording || !document.getElementById('vr-text').value.trim();
}

function tick() {
  s.seconds++;
  const el = document.getElementById('vr-timer');
  if (el) el.textContent = `${String(Math.floor(s.seconds / 60)).padStart(2, '0')}:${String(s.seconds % 60).padStart(2, '0')}`;
  if (s.engine === 'server' && s.seconds >= (cfg.maxSeconds || 55)) stopRecording();
}

export async function openVoiceModal(onConfirm) {
  if (!cfg) { try { cfg = await api.speechConfig(); } catch (e) { cfg = { serverProvider: null, maxSeconds: 55 }; } }
  s = { lang: null, state: 'idle', seconds: 0, timer: null, engine: null, onConfirm };
  const secure = window.isSecureContext;
  const browserOk = !!SR;
  const serverOk = !!cfg.serverProvider;
  const m = openModal(`
    <div class="flex items-center gap-3 mb-4 pr-8"><div class="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200">${Icons.microphone}</div>
      <div><h2 id="ns-modal-title" class="text-base font-bold text-slate-900">Speak your complaint</h2><p class="text-xs text-slate-500">You will review and edit the text before anything is submitted.</p></div></div>
    ${!secure ? `<div class="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs mb-3" role="alert">Microphone access needs a secure connection (HTTPS, or localhost on this computer). This page was opened over plain HTTP, so the browser will block the microphone. Please type your complaint instead, or open the site over HTTPS.</div>` : ''}
    <fieldset class="mb-4"><legend class="ns-label">1. Which language will you speak? (choose one)</legend>
      <div class="grid grid-cols-3 gap-2" id="vr-langs">
        ${['English', 'Hindi', 'Odia'].map(l => `<button type="button" data-lang="${l}" aria-pressed="false" class="py-2 rounded-xl border border-slate-300 text-sm font-semibold hover:border-teal-500" translate="no">${l === 'English' ? 'English' : l === 'Hindi' ? 'हिन्दी' : 'ଓଡ଼ିଆ'}</button>`).join('')}
      </div>
      <p class="text-[11px] text-slate-500 mt-1">The spoken language does not have to match the website language.</p>
    </fieldset>
    <div id="vr-engine" class="text-[11px] text-slate-600 mb-3"></div>
    <div class="bg-gradient-to-b from-slate-900 to-[#15324B] text-white rounded-2xl p-5 text-center mb-4">
      <div class="flex items-center justify-center gap-2 text-xs font-mono text-teal-300"><span id="vr-indicator" class="rec-dot hidden" aria-hidden="true"></span><span id="vr-timer" translate="no">00:00</span></div>
      <p id="vr-status" class="text-xs text-slate-200 mt-2 min-h-[2.5em]" aria-live="assertive"></p>
      <div class="mt-3 flex justify-center gap-3">
        <button id="vr-rec" class="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold rounded-full px-5 py-3">${Icons.microphone}<span>Start recording</span></button>
        <button id="vr-stop" class="hidden inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white text-sm font-bold rounded-full px-5 py-3">${Icons.stop}<span>Stop</span></button>
      </div>
    </div>
    <label for="vr-text" class="ns-label">2. Transcript (you can edit it)</label>
    <textarea id="vr-text" rows="4" class="ns-input" placeholder="Your words appear here after recognition. You can also type."></textarea>
    <div class="flex flex-wrap justify-between gap-2 mt-4">
      <button id="vr-retry" class="btn-secondary text-xs py-2 px-3">${iconSm(Icons.refresh, 14)}<span>Clear and retry</span></button>
      <div class="flex gap-2"><button class="btn-secondary text-xs py-2 px-3" data-close>Cancel</button>
      <button id="vr-confirm" class="btn-teal text-xs py-2 px-4" disabled>${iconSm(Icons.checkCircle, 14)}<span>Use this transcript</span></button></div>
    </div>`, { onClose: cleanup });

  const engineEl = m.el.querySelector('#vr-engine');
  const describe = () => {
    if (!s.lang) { engineEl.textContent = ''; return; }
    if (browserOk) engineEl.textContent = t('Recognition: your browser\'s speech service ({0}). If it does not support this language, you will be offered another option.').replace('{0}', LOCALE[s.lang]);
    else if (serverOk) engineEl.textContent = t('Recognition: Nagar Sarthi server speech service (Azure, {0}). Recording limit: 55 seconds.').replace('{0}', LOCALE[s.lang]);
    else engineEl.textContent = t('Speech recognition is not available: this browser has no speech service and the server speech service is not configured. Please type your complaint.');
    translateDOM(engineEl);
  };
  m.el.querySelectorAll('[data-lang]').forEach(b => b.onclick = () => {
    if (s.state === 'recording') return;
    s.lang = b.dataset.lang;
    m.el.querySelectorAll('[data-lang]').forEach(x => { const on = x === b; x.setAttribute('aria-pressed', String(on)); x.classList.toggle('bg-teal-700', on); x.classList.toggle('text-white', on); x.classList.toggle('border-teal-700', on); });
    describe();
    setState('idle', browserOk || serverOk ? 'Ready. Press Start recording and speak clearly.' : 'Voice input is unavailable here. Please type in the box below.');
  });
  m.el.querySelector('#vr-rec').onclick = () => startRecording(browserOk ? 'browser' : 'server');
  m.el.querySelector('#vr-stop').onclick = stopRecording;
  m.el.querySelector('#vr-retry').onclick = () => { cleanupAudio(); s.final = ''; m.el.querySelector('#vr-text').value = ''; s.seconds = 0; m.el.querySelector('#vr-timer').textContent = '00:00'; setState('idle', 'Cleared. Press Start recording to try again.'); };
  m.el.querySelector('#vr-text').oninput = () => { const c = document.getElementById('vr-confirm'); if (c) c.disabled = s.state === 'recording' || !c.ownerDocument.getElementById('vr-text').value.trim(); };
  m.el.querySelector('#vr-confirm').onclick = () => {
    const text = m.el.querySelector('#vr-text').value.trim();
    if (!text) return;
    const cb = s.onConfirm; const lang = s.lang || 'English'; const engine = s.usedEngine || 'typed';
    closeModal(); cleanup();
    cb && cb({ transcript: text, language: lang, engine });
  };
  setState('idle', 'Choose the language you will speak.');
  translateDOM(m.el);
}

function offerServerFallback(reason) {
  if (cfg.serverProvider) {
    setState('error', `${reason} You can try the server speech service instead.`);
    const st = document.getElementById('vr-status');
    const b = document.createElement('button');
    b.className = 'block mx-auto mt-2 text-xs font-bold underline text-teal-300';
    b.textContent = t('Use server speech recognition');
    b.onclick = () => startRecording('server');
    st.appendChild(b);
  } else {
    setState('error', `${reason} Server speech recognition is not configured, so please type your complaint.`);
  }
}

async function startRecording(engine) {
  if (!s.lang) return;
  s.engine = engine; s.seconds = 0; s.final = document.getElementById('vr-text').value.trim();
  document.getElementById('vr-timer').textContent = '00:00';
  if (!window.isSecureContext) { setState('error', 'The microphone is blocked on insecure (HTTP) pages. Use HTTPS or localhost, or type your complaint.'); return; }
  if (engine === 'browser') return startBrowser();
  if (!cfg.serverProvider) { setState('error', 'Server speech recognition is not configured. Please type your complaint.'); return; }
  return startServer();
}

function startBrowser() {
  const rec = new SR();
  s.rec = rec;
  rec.lang = LOCALE[s.lang];
  rec.continuous = true;
  rec.interimResults = true;
  let gotAny = false;
  const base = s.final ? s.final + ' ' : '';
  setState('requesting', 'Requesting microphone permission...');
  rec.onstart = () => { s.timer = setInterval(tick, 1000); setState('recording', `Listening (${s.lang})... Speak now. Press Stop when finished.`); };
  rec.onresult = ev => {
    // Rebuild from all results (avoids duplicated words on Android Chrome)
    let fin = '', interim = '';
    for (let i = 0; i < ev.results.length; i++) {
      const r = ev.results[i];
      if (r.isFinal) fin += r[0].transcript + ' '; else interim += r[0].transcript;
    }
    gotAny = gotAny || !!(fin + interim).trim();
    document.getElementById('vr-text').value = (base + fin + interim).replace(/\s+/g, ' ').trim();
  };
  rec.onerror = ev => {
    clearInterval(s.timer);
    const map = {
      'not-allowed': 'Microphone permission was denied. Allow microphone access in your browser settings (lock icon in the address bar) and try again, or type your complaint.',
      'service-not-allowed': 'This browser does not allow its speech service here.',
      'language-not-supported': `Your browser's speech service does not support ${s.lang}.`,
      'network': 'The browser speech service needs an internet connection and could not be reached.',
      'audio-capture': 'No microphone was found. Connect a microphone or type your complaint.',
      'no-speech': 'No speech was detected. Please try again and speak closer to the microphone.',
      'aborted': 'Recording stopped.'
    };
    const msg = map[ev.error] || `Speech recognition error: ${ev.error}.`;
    if (['language-not-supported', 'service-not-allowed', 'network'].includes(ev.error)) offerServerFallback(msg);
    else setState('error', msg);
    s.failed = true;
  };
  rec.onend = () => {
    clearInterval(s.timer);
    if (s.failed) { s.failed = false; return; }
    if (gotAny) { s.usedEngine = `browser ${LOCALE[s.lang]}`; setState('done', 'Recording finished. Check the transcript, edit it if needed, then press Use this transcript.'); }
    else setState('error', 'No speech was recognised. Please try again, or type your complaint.');
  };
  try { rec.start(); } catch (e) { setState('error', `Could not start recording: ${e.message}`); }
}

async function startServer() {
  setState('requesting', 'Requesting microphone permission...');
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } }); }
  catch (e) {
    setState('error', e.name === 'NotAllowedError' ? 'Microphone permission was denied. Allow microphone access in your browser settings (lock icon in the address bar) and try again, or type your complaint.' : 'No microphone could be opened. Check that one is connected, or type your complaint.');
    return;
  }
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const src = ctx.createMediaStreamSource(stream);
  const proc = ctx.createScriptProcessor(4096, 1, 1);
  const chunks = [];
  proc.onaudioprocess = e => chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
  src.connect(proc); proc.connect(ctx.destination);
  s.audio = { stream, ctx, src, proc, chunks, rate: ctx.sampleRate };
  s.timer = setInterval(tick, 1000);
  setState('recording', `Recording (${s.lang})... Press Stop when finished. Maximum 55 seconds.`);
}

function stopRecording() {
  clearInterval(s.timer);
  if (s.engine === 'browser' && s.rec) { setState('processing', 'Finishing recognition...'); s.rec.stop(); return; }
  if (s.engine === 'server' && s.audio) return finishServer();
}

async function finishServer() {
  const { chunks, rate } = s.audio;
  cleanupAudio();
  const len = chunks.reduce((a, c) => a + c.length, 0);
  if (len < rate * 0.5) { setState('error', 'The recording was too short. Please try again.'); return; }
  setState('uploading', 'Uploading audio...');
  const wav = encodeWav(chunks, rate, 16000);
  const b64 = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(wav); });
  setState('processing', 'Recognising speech...');
  try {
    const r = await api.transcribe(b64, s.lang);
    const box = document.getElementById('vr-text');
    box.value = ((s.final ? s.final + ' ' : '') + r.transcript).trim();
    s.usedEngine = `azure ${r.locale}`;
    setState('done', 'Transcript ready. Check it, edit if needed, then press Use this transcript.');
  } catch (e) { setState('error', t(e.message)); }
}

function encodeWav(chunks, inRate, outRate) {
  const len = chunks.reduce((a, c) => a + c.length, 0);
  const data = new Float32Array(len); let o = 0;
  for (const c of chunks) { data.set(c, o); o += c.length; }
  const ratio = inRate / outRate; const outLen = Math.floor(len / ratio);
  const pcm = new Int16Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const start = Math.floor(i * ratio), end = Math.min(len, Math.floor((i + 1) * ratio));
    let sum = 0; for (let j = start; j < end; j++) sum += data[j];
    const v = Math.max(-1, Math.min(1, sum / Math.max(1, end - start)));
    pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
  }
  const buf = new ArrayBuffer(44 + pcm.length * 2); const dv = new DataView(buf);
  const w = (p, str) => { for (let i = 0; i < str.length; i++) dv.setUint8(p + i, str.charCodeAt(i)); };
  w(0, 'RIFF'); dv.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true); dv.setUint32(24, outRate, true);
  dv.setUint32(28, outRate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, pcm.length * 2, true);
  new Int16Array(buf, 44).set(pcm);
  return new Blob([buf], { type: 'audio/wav' });
}

function cleanupAudio() {
  if (s && s.audio) {
    try { s.audio.proc.disconnect(); s.audio.src.disconnect(); s.audio.stream.getTracks().forEach(tr => tr.stop()); s.audio.ctx.close(); } catch (e) {}
    s.audio = null;
  }
}
function cleanup() {
  if (!s) return;
  clearInterval(s.timer);
  try { if (s.rec && s.state === 'recording') s.rec.abort(); } catch (e) {}
  cleanupAudio();
}

export { encodeWav };
window.openVoiceModal = openVoiceModal;
