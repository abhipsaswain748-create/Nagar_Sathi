// Interactive civic map (Leaflet + marker clustering) with filters, layers, legend and a list view.
// Public mode: privacy-projected data (approx. 100 m offset, no names, only photos the citizen allowed).
// Staff mode: exact locations for complaints within the staff member's scope.
import { api } from '../api.js';
import { getCategoryIcon } from '../icons.js';
import { t, translateDOM, fmtNum } from '../i18n.js';
import { esc, u, id, date, statusPill, priorityPill, categoryChip, demoBadge, DOMAINS, STATUS_LABEL, emptyState } from '../ui.js';
import { addBaseLayers } from './map-picker.js';

// Shared civic priority palette. Priority is independent from complaint status.
const COLORS = { Critical: '#C62828', High: '#E87516', Medium: '#D6A400', Low: '#23834A', Unassessed: '#64748B' };
function priorityKey(value) {
  const v = String(value || '').trim().toLowerCase();
  if (['critical', 'urgent', 'emergency'].includes(v)) return 'Critical';
  if (['high', 'high priority'].includes(v)) return 'High';
  if (['medium', 'moderate'].includes(v)) return 'Medium';
  if (['low', 'low priority'].includes(v)) return 'Low';
  return 'Unassessed';
}
function markerColor(row) { return COLORS[priorityKey(row.priority)]; }
const CLOSED = ['Verified / Closed', 'Resolved', 'Rejected'];

export async function renderCivicMap(params, { staff = false, route }) {
  const f = { category: params.category || 'all', status: params.status || 'all', priority: params.priority || 'all', from: params.from || '', department_id: params.department_id || 'all', search: params.search || '' };
  const view = params.view === 'list' ? 'list' : 'map';
  let rows = [], error = null, deps = [];
  try {
    if (staff) {
      const [r, d] = await Promise.all([api.getComplaints(f), api.departments()]);
      deps = d.data;
      rows = r.data.map(c => ({ ...c, related_reports: c.community_confirmations_count || 1, public_photo_url: c.thumbnail_url }));
    } else rows = (await api.publicMap(f)).data;
  } catch (e) { error = e.message; }
  const counts = { total: rows.length, open: rows.filter(r => !CLOSED.includes(r.status)).length, high: rows.filter(r => ['High', 'Critical'].includes(priorityKey(r.priority)) && !CLOSED.includes(r.status)).length };
  window.__afterRender = () => { if (view === 'map') drawMap(rows, staff); };
  const q = obj => esc(JSON.stringify({ ...f, view, ...obj }));
  return `
    <form class="bg-white rounded-2xl border border-slate-200 p-3 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-7 gap-2 mb-3" onsubmit="event.preventDefault(); window.navigate('${route}', Object.assign(Object.fromEntries(new FormData(this)), {view: '${view}'}))">
      <div class="col-span-2 md:col-span-1"><label class="ns-label" for="cm-search">Search</label><input id="cm-search" name="search" value="${esc(f.search)}" class="ns-input py-1.5" placeholder="Area, title or ID" /></div>
      <div><label class="ns-label" for="cm-cat">Domain</label><select id="cm-cat" name="category" class="ns-input py-1.5"><option value="all">All</option>${DOMAINS.map(d => `<option value="${esc(d.category)}" ${f.category === d.category ? 'selected' : ''}>${d.title}</option>`).join('')}</select></div>
      <div><label class="ns-label" for="cm-st">Status</label><select id="cm-st" name="status" class="ns-input py-1.5"><option value="all">All</option>${Object.keys(STATUS_LABEL).filter(s => staff || s !== 'Rejected').map(s => `<option value="${esc(s)}" ${f.status === s ? 'selected' : ''}>${STATUS_LABEL[s]}</option>`).join('')}</select></div>
      <div><label class="ns-label" for="cm-pri">Severity</label><select id="cm-pri" name="priority" class="ns-input py-1.5"><option value="all">All</option>${['Critical', 'High', 'Medium', 'Low', 'Unassessed'].map(p => `<option value="${p}" ${String(f.priority).toLowerCase() === p.toLowerCase() ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
      <div><label class="ns-label" for="cm-from">Reported since</label><input id="cm-from" name="from" type="date" value="${esc(f.from)}" class="ns-input py-1.5" /></div>
      ${staff ? `<div><label class="ns-label" for="cm-dept">Department</label><select id="cm-dept" name="department_id" class="ns-input py-1.5"><option value="all">All</option>${deps.map(d => `<option value="${esc(d.id)}" ${f.department_id === d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>` : ''}
      <div class="flex items-end gap-2"><button class="btn-primary text-xs py-2 px-3">Apply filters</button><button type="button" class="btn-secondary text-xs py-2 px-3" onclick="window.navigate('${route}')">Clear</button></div>
    </form>
    <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
      <div class="text-xs text-slate-600"><span translate="no">${fmtNum(counts.total)}</span> <span>reports</span> · <span translate="no">${fmtNum(counts.open)}</span> <span>open</span> · <span translate="no">${fmtNum(counts.high)}</span> <span>high priority open</span></div>
      <div class="inline-flex rounded-xl border border-slate-300 overflow-hidden text-xs font-semibold" role="group" aria-label="View">
        <button class="px-3 py-1.5 ${view === 'map' ? 'bg-[#15324B] text-white' : 'bg-white'}" aria-pressed="${view === 'map'}" onclick="window.navigate('${route}', ${q({ view: 'map' })})">Map view</button>
        <button class="px-3 py-1.5 ${view === 'list' ? 'bg-[#15324B] text-white' : 'bg-white'}" aria-pressed="${view === 'list'}" onclick="window.navigate('${route}', ${q({ view: 'list' })})">List view</button></div>
    </div>
    ${error ? `<div class="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm mb-3" role="alert">${esc(t(error))}</div>` : ''}
    ${view === 'map' ? `<div class="relative"><div id="civic-map" class="h-[60vh] min-h-[360px] rounded-2xl border border-slate-300 bg-slate-100" role="region" aria-label="Civic map"></div></div>
      <div class="flex flex-wrap gap-3 mt-3 text-[11px] text-slate-600" aria-label="Legend"><span class="font-bold">Legend:</span>
        ${Object.entries(COLORS).map(([k, c]) => `<span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full inline-block" style="background:${c}"></span>${k === 'Unassessed' ? 'Unassessed' : k + ' Priority'}</span>`).join('')}
        <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full inline-block bg-slate-800"></span>Resolved status (priority retained)</span>
        <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full inline-block border-2 border-red-500"></span>Recurring hotspot (layer)</span>
        <span class="inline-flex items-center gap-1"><span class="w-3 h-3 inline-block bg-violet-600 rounded-sm"></span>Community incident (layer)</span></div>
      ${!staff ? '<p class="text-[11px] text-slate-500 mt-1">Locations are shown about 100 m away from the exact point to protect privacy. Satellite layer: Esri World Imagery, archived imagery that is not real-time; capture dates vary by area.</p>' : ''}` : listView(rows, staff)}`;
}

function listView(rows, staff) {
  if (!rows.length) return emptyState('No reports match these filters.');
  return `<div class="grid grid-cols-1 md:grid-cols-2 gap-3">${rows.map(r => `<article class="bg-white rounded-xl border border-slate-200 p-4">
    <div class="flex items-start justify-between gap-2"><div class="min-w-0"><div class="text-[11px] text-slate-500">${id(r.id)} · ${date(r.created_at, false)} ${demoBadge(r.is_demo)}</div>
      <h3 class="text-sm font-bold">${u(r.title)}</h3>${categoryChip(r.category)}</div>${statusPill(r.status)}</div>
    <p class="text-[11px] text-slate-600 mt-1">${u(r.locality)} · ${priorityPill(r.priority)} · <span>Related reports</span>: <span translate="no">${r.related_reports}</span> · <span>Last updated</span> ${date(r.updated_at)}</p>
    ${staff ? `<button class="text-xs font-bold text-teal-700 mt-2" onclick="window.navigate('admin-complaint', {id: '${esc(r.id)}'})">Manage →</button>` : ''}</article>`).join('')}</div>`;
}

function popup(r, staff) {
  return `<div style="max-width:240px" class="text-xs">
    <div class="text-[10px] text-slate-500">${id(r.id)} ${demoBadge(r.is_demo)}</div>
    <div class="font-bold text-sm my-0.5">${u(r.title)}</div>
    <div>${categoryChip(r.category)}</div>
    ${r.description ? `<p class="mt-1 text-slate-700">${u(r.description.slice(0, 160))}${r.description.length > 160 ? '…' : ''}</p>` : ''}
    <div class="mt-1"><span>${staff ? 'Location' : 'Approximate location'}</span>: ${u(r.locality)}${r.ward_no ? `, <span translate="no">Ward ${r.ward_no}</span>` : ''}</div>
    <div><span>Reported</span>: ${date(r.created_at, false)} · <span>Last updated</span>: ${date(r.updated_at)}</div>
    <div class="mt-1 flex flex-wrap gap-1">${statusPill(r.status)} ${priorityPill(r.priority)}</div>
    <div class="mt-1"><span>Related reports</span>: <span translate="no">${r.related_reports || 1}</span></div>
    ${r.public_photo_url ? `<img src="${esc(r.public_photo_url)}" alt="Reported problem" class="mt-2 w-full h-24 object-cover rounded" loading="lazy" />` : ''}
    ${staff ? `<button class="mt-2 text-teal-700 font-bold underline" onclick="window.navigate('admin-complaint', {id: '${esc(r.id)}'})">Manage complaint</button>` : ''}</div>`;
}

async function drawMap(rows, staff) {
  const el = document.getElementById('civic-map');
  if (!el) return;
  if (typeof L === 'undefined') {
    el.innerHTML = `<div class="h-full flex items-center justify-center p-6 text-center text-sm text-slate-700" role="alert">${t('The map could not be loaded. Use the List view instead.')}</div>`;
    return;
  }
  const map = L.map(el, { zoomControl: true }).setView([20.2961, 85.8245], 12);
  const base = addBaseLayers(map);
  const cluster = L.markerClusterGroup ? L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 45 }) : L.layerGroup();
  const dangerLayer = L.layerGroup();
  rows.forEach(r => {
    const color = markerColor(r);
    const key = priorityKey(r.priority);
    const icon = L.divIcon({ className: '', html: `<div class="ns-marker" role="img" aria-label="${key} priority" title="${key} priority" style="background:${color};border:2px solid #fff;box-shadow:0 1px 5px #0006">${getCategoryIcon(r.category)}</div>`, iconSize: [32, 32], iconAnchor: [16, 16] });
    const m = L.marker([r.latitude, r.longitude], { icon, keyboard: true });
    m.bindPopup(() => { const d = document.createElement('div'); d.innerHTML = popup(r, staff); translateDOM(d); return d; });
    cluster.addLayer(m);

    // A separate, always-visible red danger dot makes urgent reports stand out
    // even when the normal priority marker is clustered or visually small.
    if (['Critical', 'High'].includes(key)) {
      const dangerIcon = L.divIcon({
        className: 'ns-danger-marker-wrap',
        html: `<span class="ns-danger-dot" role="img" aria-label="${key} danger report" title="${key} danger report"></span>`,
        iconSize: [22, 22], iconAnchor: [11, 11]
      });
      const danger = L.marker([r.latitude, r.longitude], { icon: dangerIcon, keyboard: true, zIndexOffset: 1200 });
      danger.bindPopup(() => { const d = document.createElement('div'); d.innerHTML = popup(r, staff); translateDOM(d); return d; });
      dangerLayer.addLayer(danger);
    }
  });
  cluster.addTo(map);
  dangerLayer.addTo(map);

  // Population-density choropleth from Bhubaneswar One / BMC ward-boundary GIS.
  // Population and ward area are read from the official GIS layer; no population
  // counts or ward sizes are invented in the client.
  const densityLayer = L.layerGroup();
  // The same-origin server proxy handles upstream GIS access and CORS.
  const getProp = (obj, names) => {
    for (const n of names) {
      const key = Object.keys(obj || {}).find(k => k.toLowerCase() === n.toLowerCase());
      if (key && obj[key] !== null && obj[key] !== undefined && obj[key] !== '') return obj[key];
    }
    return null;
  };
  const geometryAreaKm2 = geometry => {
    const R = 6371.0088;
    const ringArea = ring => {
      let sum = 0;
      for (let i = 0; i < ring.length; i++) {
        const a = ring[i], b = ring[(i + 1) % ring.length];
        sum += (b[0] - a[0]) * Math.PI / 180 *
          (2 + Math.sin(a[1] * Math.PI / 180) + Math.sin(b[1] * Math.PI / 180));
      }
      return Math.abs(sum * R * R / 2);
    };
    if (!geometry) return 0;
    const polys = geometry.type === 'Polygon' ? [geometry.coordinates] :
      geometry.type === 'MultiPolygon' ? geometry.coordinates : [];
    return polys.reduce((total, poly) => total + Math.max(0, ringArea(poly[0]) - poly.slice(1).reduce((a, r) => a + ringArea(r), 0)), 0);
  };
  try {
    const response = await fetch('/api/public/ward-density', { headers: { Accept: 'application/geo+json, application/json' } });
    if (!response.ok) throw new Error(`Ward GIS service returned ${response.status}`);
    const geo = await response.json();
    const features = (geo.features || []).map(feature => {
      const props = feature.properties || {};
      const population = Number(getProp(props, ['totalwardp', 'total_population', 'population']));
      const wardAreaRaw = Number(getProp(props, ['Shape_Area', 'shape_area', 'shapearea']));
      const mappedGeometryArea = geometryAreaKm2(feature.geometry);
      const areaKm2 = mappedGeometryArea > 0 ? mappedGeometryArea :
        (wardAreaRaw > 1000000 ? wardAreaRaw / 1000000 : wardAreaRaw);
      const density = population > 0 && areaKm2 > 0 ? population / areaKm2 : null;
      return { ...feature, properties: { ...props, __population: population, __areaKm2: areaKm2, __density: density } };
    }).filter(f => Number.isFinite(f.properties.__density) && f.properties.__density > 0);
    if (!features.length) throw new Error('Ward population or area fields were unavailable.');
    const values = features.map(f => f.properties.__density).sort((a, b) => a - b);
    const quantile = q => values[Math.min(values.length - 1, Math.floor((values.length - 1) * q))];
    const cuts = [quantile(.25), quantile(.5), quantile(.75)];
    const densityColor = d => d <= cuts[0] ? '#fef3c7' : d <= cuts[1] ? '#fdba74' : d <= cuts[2] ? '#f97316' : '#b91c1c';
    const densityGeo = L.geoJSON({ type: 'FeatureCollection', features }, {
      style: feature => ({
        color: '#7c2d12', weight: 1.2, opacity: .8,
        fillColor: densityColor(feature.properties.__density), fillOpacity: .28
      }),
      onEachFeature: (feature, layer) => {
        const p = feature.properties;
        const ward = getProp(p, ['wardno', 'ward_no', 'ward']);
        const density = Math.round(p.__density).toLocaleString('en-IN');
        const population = Math.round(p.__population).toLocaleString('en-IN');
        const area = p.__areaKm2.toFixed(2);
        layer.bindPopup(`<div class="text-xs"><strong>${esc(t('Ward {0}', { 0: ward ?? '—' }))} · ${esc(t('Population density'))}</strong><br>${esc(t('Population'))}: ${population}<br>${esc(t('Ward area'))}: ${area} km²<br><strong>${density} ${esc(t('people/km²'))}</strong><br><span class="text-slate-500">${esc(t('BMC / Bhubaneswar One ward GIS data. Density calculated from ward population ÷ mapped ward area.'))}</span></div>`);
        layer.bindTooltip(`${esc(t('Ward {0}', { 0: ward ?? '—' }))} · ${density} ${esc(t('people/km²'))}`, { sticky: true });
      }
    });
    densityGeo.addTo(densityLayer);
    // Keep the choropleth below complaint and danger markers.
    densityLayer.addTo(map);
    const legend = L.control({ position: 'bottomright' });
    legend.onAdd = () => {
      const div = L.DomUtil.create('div', 'ns-density-legend');
      div.innerHTML = `<strong>${esc(t('Population density'))}</strong><div><i style="background:#fef3c7"></i>${esc(t('Lower'))}</div><div><i style="background:#fdba74"></i>${esc(t('Moderate'))}</div><div><i style="background:#f97316"></i>${esc(t('High'))}</div><div><i style="background:#b91c1c"></i>${esc(t('Very high'))}</div><small>${esc(t('Relative ward classes · click a ward for people/km²'))}</small>`;
      L.DomEvent.disableClickPropagation(div);
      return div;
    };
    legend.addTo(map);
  } catch (e) {
    console.warn('[Civic Map] Population-density layer unavailable:', e.message);
    // Published iFOREST analysis identifies Wards 21 and 26 as exceptionally
    // dense (>700 persons/hectare). Show a clearly-labelled fallback only when
    // complaint coordinates provide an actual ward location.
    const knownDenseWards = [21, 26];
    knownDenseWards.forEach(ward => {
      const wardRows = rows.filter(r => Number(r.ward_no) === ward && Number.isFinite(Number(r.latitude)) && Number.isFinite(Number(r.longitude)));
      if (!wardRows.length) return;
      const lat = wardRows.reduce((a, r) => a + Number(r.latitude), 0) / wardRows.length;
      const lon = wardRows.reduce((a, r) => a + Number(r.longitude), 0) / wardRows.length;
      L.circle([lat, lon], { radius: 420, color: '#b91c1c', weight: 2, fillColor: '#ef4444', fillOpacity: .18, dashArray: '5 5' })
        .bindPopup(`<strong>Ward ${ward} · Very high population-density zone</strong><br>Published analysis reports more than 700 persons per hectare.<br><small>Approximate position from mapped ward complaints; density overlay uses published classification fallback.</small>`)
        .addTo(densityLayer);
    });
    if (densityLayer.getLayers().length) densityLayer.addTo(map);
  }

  // Recurring hotspots and community incidents.
  const hotspots = L.layerGroup(); const incidents = L.layerGroup();
  try {
    const [rec, inc] = await Promise.all([api.recurring(), api.incidents()]);
    (rec.data || []).forEach(h => {
      const radius = Math.min(520, 180 + h.total_reports * 55);
      const popupHtml = `<strong>${esc(t('Recurring hotspot'))}</strong><br>${esc(t(h.category))}<br>${esc(h.area)}<br>${esc(t('Total reports'))}: ${h.total_reports}`;
      L.circle([h.latitude, h.longitude], {
        radius, color: '#b91c1c', weight: 4, opacity: 1,
        fillColor: '#ef4444', fillOpacity: 0.32, className: 'ns-hotspot-zone', interactive: true
      }).bindPopup(popupHtml).addTo(hotspots);
      L.circleMarker([h.latitude, h.longitude], {
        radius: 8, color: '#ffffff', weight: 2, fillColor: '#dc2626', fillOpacity: 1
      }).bindPopup(popupHtml).addTo(hotspots);
    });
    (inc.data || []).forEach(g => L.marker([g.latitude, g.longitude], { icon: L.divIcon({ className: '', html: `<div style="background:#7c3aed;color:#fff;border-radius:6px;padding:2px 5px;font-size:11px;font-weight:700;border:2px solid #fff">${g.related_complaints}</div>` }) })
      .bindPopup(`<strong>${esc(t('Community incident'))}</strong><br>${esc(t(g.category))}<br>${esc(g.area)}<br>${esc(t('Citizens reporting'))}: ${g.citizens_reporting}`).addTo(incidents));
  } catch (e) { console.warn('[Civic Map] Intelligence overlays unavailable:', e.message); }

  cluster.addTo(map);
  dangerLayer.addTo(map);
  hotspots.addTo(map);
  incidents.addTo(map);
  const overlays = {
    [t('Civic complaints')]: cluster,
    [t('Danger / high-risk reports (red dots)')]: dangerLayer,
    [t('Population density by ward')]: densityLayer,
    [t('Recurring hotspots')]: hotspots,
    [t('Community incidents')]: incidents
  };
  L.control.layers({ [t('Street map')]: base.osm, [t('Satellite (Esri archive imagery)')]: base.sat }, overlays, { collapsed: window.innerWidth < 640 }).addTo(map);
  if (rows.length) map.fitBounds(rows.map(r => [r.latitude, r.longitude]), { padding: [30, 30], maxZoom: 15 });
  setTimeout(() => map.invalidateSize(), 200);
  translateDOM(el);
}
