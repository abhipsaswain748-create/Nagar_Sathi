// Location picker: map pin (drag/click), landmark search, and device location only after the
// citizen presses the button (consent). If the map cannot load, the form still works with
// typed address/landmark.
import { api } from '../api.js';
import { t, translateDOM } from '../i18n.js';
import { showToast } from './toast.js';

const DEFAULT = { lat: Number(window.NS_DEFAULT_LAT || 20.2961), lon: Number(window.NS_DEFAULT_LON || 85.8245) };

export function addBaseLayers(map) {
  let tileErrors = 0;
  const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' });
  const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19, attribution: 'Imagery &copy; Esri, Maxar, Earthstar Geographics (archived imagery, not real-time; capture dates vary by area)'
  });
  [osm, sat].forEach(l => l.on('tileerror', () => {
    tileErrors++;
    if (tileErrors === 6) {
      const c = map.getContainer();
      const note = document.createElement('div');
      note.className = 'absolute inset-x-2 top-2 z-[1000] bg-amber-50 border border-amber-300 text-amber-900 text-xs rounded-lg p-2';
      note.setAttribute('role', 'alert');
      note.textContent = t('Map images could not be loaded (no internet or the tile server is unavailable). You can still type the address or landmark, and use the list view.');
      c.appendChild(note);
    }
  }));
  osm.addTo(map);
  return { osm, sat };
}

export class MapPicker {
  constructor(containerId, options = {}) {
    this.containerId = containerId;
    this.lat = Number.isFinite(options.lat) ? options.lat : DEFAULT.lat;
    this.lon = Number.isFinite(options.lon) ? options.lon : DEFAULT.lon;
    this.onChange = options.onLocationChange || (() => {});
    this.map = null; this.marker = null;
  }

  init() {
    const el = document.getElementById(this.containerId);
    if (!el) return false;
    if (typeof L === 'undefined') {
      el.innerHTML = `<div class="h-full flex items-center justify-center bg-slate-100 text-slate-600 text-xs p-4 text-center" role="alert">${t('The map library could not be loaded. Type the address and landmark instead.')}</div>`;
      return false;
    }
    if (this.map) this.map.remove();
    this.map = L.map(this.containerId, { zoomControl: true }).setView([this.lat, this.lon], 15);
    const layers = addBaseLayers(this.map);
    L.control.layers({ [t('Street map')]: layers.osm, [t('Satellite (Esri archive imagery)')]: layers.sat }).addTo(this.map);
    this.marker = L.marker([this.lat, this.lon], { draggable: true, keyboard: true, title: t('Problem location (drag to adjust)') }).addTo(this.map);
    this.marker.on('dragend', () => { const p = this.marker.getLatLng(); this.set(p.lat, p.lng, null, 0.9, 'pin'); });
    this.map.on('click', e => this.set(e.latlng.lat, e.latlng.lng, null, 0.9, 'pin'));
    setTimeout(() => this.map.invalidateSize(), 200);
    translateDOM(el);
    return true;
  }

  set(lat, lon, address, confidence, source) {
    this.lat = lat; this.lon = lon;
    if (this.marker) this.marker.setLatLng([lat, lon]);
    if (this.map) this.map.panTo([lat, lon]);
    this.onChange({ latitude: lat, longitude: lon, address, confidence, source });
  }

  async resolveVagueLandmark(text) {
    try {
      const r = await api.resolveLandmark(text);
      const d = r.data;
      if (d.matched) {
        this.set(d.lat, d.lon, d.address, d.confidence, 'landmark');
        if (this.map) this.map.setZoom(16);
        showToast(t('Landmark found: {0}. Check the pin and adjust it if needed.').replace('{0}', d.landmark), 'success');
        return d;
      }
      showToast(t('That landmark is not in the local list. Please drag the pin to the exact spot.'), 'warning');
      return null;
    } catch (e) { showToast(t(e.message), 'error'); return null; }
  }

  detectGPS() {
    if (!navigator.geolocation) { showToast(t('This device does not provide location. Use the map or landmark instead.'), 'warning'); return; }
    if (!window.isSecureContext) { showToast(t('Device location needs HTTPS. Use the map or landmark instead.'), 'warning'); return; }
    showToast(t('Asking your device for its location...'), 'info');
    navigator.geolocation.getCurrentPosition(
      pos => { this.set(pos.coords.latitude, pos.coords.longitude, null, pos.coords.accuracy < 50 ? 0.95 : 0.8, 'gps'); if (this.map) this.map.setZoom(17); showToast(t('Location detected. Check the pin.'), 'success'); },
      err => showToast(err.code === 1 ? t('Location permission was denied. Use the map or landmark instead.') : t('Could not get your location. Use the map or landmark instead.'), 'warning'),
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }
}
