// Top navigation: brand, citizen navigation, language selector, notifications, account menu and a
// separate "Administrator Portal" entry at the top right (never mixed into the civic domain list).
import { state } from '../state.js';
import { Icons } from '../icons.js';
import { LANGUAGES, getLanguage, fmtDate } from '../i18n.js';
import { esc, iconSm, roleLabel } from '../ui.js';

function link(route, label, extra = '') {
  const active = state.activeRoute === route;
  return `<button class="px-2.5 py-2 rounded-lg text-sm hover:text-teal-700 hover:bg-slate-100 transition whitespace-nowrap ${active ? 'text-teal-700 bg-slate-100 font-bold' : ''} ${extra}" ${active ? 'aria-current="page"' : ''} onclick="window.navigate('${route}')">${label}</button>`;
}

function links() {
  const u = state.currentUser;
  const out = [link('home', 'Home'), link('public-map', 'Civic Map'), link('community-issues', 'Civic Echo Community')];
  if (u && u.role === 'citizen') out.push(link('citizen-dashboard', 'My Dashboard'), link('my-complaints', 'Track Progress'), link('feedback', 'Feedback'));
  if (u && (u.role === 'admin' || u.role === 'dept_officer')) out.push(link('admin-dashboard', 'Command Centre', 'text-blue-900 font-semibold'));
  if (u && u.role === 'field_officer') out.push(link('field-tasks', 'My Field Tasks', 'text-emerald-900 font-semibold'));
  out.push(link('about', 'About'));
  return out;
}

function langSelect(id) {
  const lang = getLanguage();
  return `<label class="sr-only" for="${id}">Language</label>
    <select id="${id}" translate="no" class="bg-slate-100 border border-slate-300 text-slate-700 text-xs font-semibold rounded-lg py-1.5 px-2 focus:ring-2 focus:ring-teal-600 cursor-pointer" onchange="window.switchLanguage(this.value)">
      ${LANGUAGES.map(l => `<option value="${l.code}" ${lang === l.code ? 'selected' : ''}>${l.label}</option>`).join('')}
    </select>`;
}

function notifPanel() {
  const list = state.notifications;
  return `<div id="notif-dropdown" class="hidden absolute right-0 mt-2 w-[min(22rem,calc(100vw-1.5rem))] bg-white rounded-xl shadow-2xl border border-slate-200 z-50" role="region" aria-label="Notifications">
    <div class="flex items-center justify-between px-4 py-2.5 border-b border-slate-100">
      <span class="text-sm font-bold text-slate-900">Notifications</span>
      ${state.unreadNotifications ? '<button class="text-xs font-semibold text-teal-700 hover:underline" onclick="window.markAllNotifsRead()">Mark all as read</button>' : ''}
    </div>
    <div class="max-h-96 overflow-y-auto divide-y divide-slate-100">
      ${list.length ? list.map(n => `<button class="w-full text-left px-4 py-3 hover:bg-slate-50 flex gap-2 ${n.is_read ? 'opacity-70' : ''}" onclick="window.openNotification('${esc(n.id)}', '${esc(n.complaint_id || '')}')">
          <span class="mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${n.is_read ? 'bg-slate-300' : 'bg-teal-600'}" aria-hidden="true"></span>
          <span class="min-w-0"><span class="block text-xs font-bold text-slate-900" data-i18n-soft>${esc(n.title)}</span>
          <span class="block text-xs text-slate-600 mt-0.5" data-i18n-soft>${esc(n.message)}</span>
          <span class="block text-[10px] text-slate-400 mt-1" translate="no">${esc(fmtDate(n.created_at))}</span>
          ${n.is_read ? '' : '<span class="sr-only">Unread</span>'}</span></button>`).join('')
        : '<p class="px-4 py-8 text-center text-xs text-slate-500">No notifications yet.</p>'}
    </div></div>`;
}

export function renderNavbar() {
  const u = state.currentUser;
  const staff = state.isStaff();
  const unread = state.unreadNotifications;
  const many = !!u; // logged-in users have more links: switch to the menu earlier
  const navCls = many ? 'hidden 2xl:flex' : 'hidden xl:flex';
  const burgerCls = many ? '2xl:hidden' : 'xl:hidden';
  return `
  <header class="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 bg-white px-3 py-2 rounded">Skip to main content</a>
    <div class="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16 gap-2">
        <button class="flex items-center gap-2 flex-shrink-0" onclick="window.navigate('home')" aria-label="Nagar Sarthi home">
          <img src="/assets/nagar-sarthi-brand-official-v2.jpg?v=20261106-2" alt="Nagar Sarthi" class="h-9 sm:h-11 w-auto max-w-[190px] sm:max-w-[220px] object-contain" />
        </button>
        <nav class="${navCls} items-center gap-0.5 font-medium text-slate-700 min-w-0" aria-label="Main">${links().join('')}</nav>
        <div class="flex items-center gap-1.5 sm:gap-2">
          <div class="hidden sm:block">${langSelect('lang-selector')}</div>
          <button class="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 hidden sm:inline-flex" aria-label="Toggle light or dark theme" title="Toggle light or dark theme" onclick="window.toggleThemeNav()">${iconSm(document.documentElement.classList.contains('dark') ? Icons.sun : Icons.moon, 16)}</button>
          ${u ? `<div class="relative">
              <button class="relative p-2 rounded-full text-slate-600 hover:bg-slate-100" aria-label="Notifications" aria-haspopup="true" onclick="window.toggleNotifications(event)">
                ${Icons.bell}${unread ? `<span class="absolute top-0.5 right-0.5 min-w-[1rem] h-4 px-1 bg-red-600 text-white rounded-full text-[10px] flex items-center justify-center font-bold" translate="no">${unread}</span><span class="sr-only">unread notifications</span>` : ''}
              </button>${notifPanel()}</div>` : ''}
          ${!staff ? `<button class="${u ? 'hidden sm:inline-flex' : 'inline-flex'} items-center gap-1.5 px-2.5 md:px-3 py-2 rounded-xl text-xs font-bold bg-[#15324B] hover:bg-[#122B40] text-white shadow-sm" onclick="window.navigate('admin-login')" aria-label="Administrator Portal">
              ${iconSm(Icons.shield, 16)}<span class="hidden md:inline">Administrator Portal</span></button>` : ''}
          ${u ? `<div class="relative">
              <button class="flex items-center gap-1.5 bg-slate-800 text-white text-xs font-semibold py-2 px-2.5 sm:px-3 rounded-full" aria-haspopup="true" onclick="document.getElementById('user-menu').classList.toggle('hidden')">
                ${iconSm(Icons.user, 14)}<span class="max-w-[90px] truncate hidden sm:inline" translate="no">${esc(u.name.split(' ')[0])}</span>${iconSm(Icons.chevronDown, 14)}
              </button>
              <div id="user-menu" class="hidden absolute right-0 mt-2 w-60 bg-white rounded-xl shadow-2xl border border-slate-200 py-2 z-50">
                <div class="px-4 py-2 border-b border-slate-100"><div class="text-sm font-bold text-slate-900" translate="no">${esc(u.name)}</div><div class="text-[11px] text-slate-500">${roleLabel(u.role)}</div></div>
                <button class="w-full text-left px-4 py-2 text-sm hover:bg-slate-50 flex items-center gap-2" onclick="window.navigate('settings')">${iconSm(Icons.lock, 16)}Account settings</button>
                <button class="w-full text-left px-4 py-2 text-sm hover:bg-slate-50 text-red-700 flex items-center gap-2" onclick="window.logout()">${iconSm(Icons.logout, 16)}Log out</button>
              </div></div>`
            : `<span class="hidden sm:inline-block"><button class="btn-teal py-2 px-3 text-xs font-bold whitespace-nowrap" onclick="window.navigate('citizen-login')">${iconSm(Icons.user, 16)}<span>Citizen Login</span></button></span>`}
          <button class="${burgerCls} p-2 rounded-lg border border-slate-200 text-slate-700" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu" onclick="window.toggleMobileMenu(this)">${Icons.menu}</button>
        </div>
      </div>
    </div>
    <div id="mobile-menu" class="hidden ${burgerCls} border-t border-slate-200 bg-white px-3 py-3">
      <nav class="grid grid-cols-1 sm:grid-cols-2 gap-1" aria-label="Mobile">${links().join('')}
        ${u ? '' : `<button class="px-2.5 py-2 rounded-lg text-sm text-left font-bold text-teal-700" onclick="window.navigate('citizen-login')">Citizen Login</button>`}
        ${staff ? '' : `<button class="px-2.5 py-2 rounded-lg text-sm text-left font-bold text-[#15324B]" onclick="window.navigate('admin-login')">Administrator Portal</button>`}
      </nav>
      <div class="flex items-center gap-2 mt-3 pt-3 border-t border-slate-100 sm:hidden">${iconSm(Icons.globe, 16)}${langSelect('lang-selector-mobile')}
        <button class="ml-auto p-2 rounded-lg border border-slate-200 text-slate-600" aria-label="Toggle light or dark theme" onclick="window.toggleThemeNav()">${iconSm(Icons.moon, 16)}</button></div>
    </div>
  </header>`;
}
