// Toast notifications (aria-live). Messages are escaped; the i18n observer translates them.
import { Icons } from '../icons.js';

export function showToast(message, type = 'info', duration = 4500) {
  let container = document.getElementById('toast-container');
  if (!container) { container = document.createElement('div'); container.id = 'toast-container'; document.body.appendChild(container); }
  container.setAttribute('aria-live', 'polite');
  const colors = { success: 'var(--color-success)', warning: 'var(--color-warning)', error: 'var(--color-critical)', info: 'var(--color-brand-ocean)' };
  const icon = type === 'success' ? Icons.checkCircle : (type === 'info' ? Icons.info : Icons.alertTriangle);
  const toast = document.createElement('div');
  toast.className = 'toast-msg';
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  toast.style.borderLeftColor = colors[type] || colors.info;
  const text = document.createElement('div');
  text.style.cssText = 'flex-grow:1;font-weight:500;color:#15324B;';
  text.textContent = String(message);
  toast.innerHTML = `<div style="flex-shrink:0;color:${colors[type] || colors.info}">${icon}</div>`;
  toast.appendChild(text);
  const btn = document.createElement('button');
  btn.setAttribute('aria-label', 'Close');
  btn.style.cssText = 'background:none;border:none;cursor:pointer;color:#7E94A5;';
  btn.innerHTML = Icons.x;
  btn.onclick = () => toast.remove();
  toast.appendChild(btn);
  container.appendChild(toast);
  setTimeout(() => { if (toast.parentElement) { toast.style.transition = 'all .3s'; toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); } }, duration);
}
