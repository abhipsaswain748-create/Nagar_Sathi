// Nagar Sarthi AI assistant drawer. Replies come from /api/ai/chat, which grounds every fact
// (IDs, statuses, deadlines) in records the logged-in user is allowed to see. The assistant can
// prepare a report draft but never submits a complaint itself.
import { api } from '../api.js';
import { state } from '../state.js';
import { Icons } from '../icons.js';
import { getLanguage, t, translateDOM } from '../i18n.js';
import { esc, iconSm } from '../ui.js';

const history = [];
let lastSource = '';

export function renderAIAssistant() {
  return `
    <button class="ai-fab" onclick="window.toggleAIDrawer()" aria-label="Open Nagar Sarthi AI assistant" title="Nagar Sarthi AI">${Icons.aiSparkle}</button>
    <div id="ai-drawer" class="hidden fixed inset-0 sm:inset-auto sm:bottom-24 sm:right-6 z-[9500] sm:w-[400px] sm:h-[600px] sm:max-h-[80vh] bg-white sm:rounded-2xl shadow-2xl border border-slate-200 flex-col" role="dialog" aria-label="Nagar Sarthi AI">
      <div class="flex items-center justify-between px-4 py-3 bg-[#15324B] text-white sm:rounded-t-2xl">
        <div class="flex items-center gap-2"><span class="text-teal-300">${Icons.aiSparkle}</span>
          <div><div class="text-sm font-bold">Nagar Sarthi AI</div><div class="text-[10px] text-slate-300" id="ai-source" translate="no">${esc(lastSource || 'Civic assistant')}</div></div></div>
        <button class="p-2 rounded-lg hover:bg-white/10" aria-label="Close" onclick="window.toggleAIDrawer()">${Icons.x}</button>
      </div>
      <div id="ai-messages" class="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50" aria-live="polite"></div>
      <div class="px-3 pt-2 flex flex-wrap gap-1.5 border-t border-slate-100">
        ${['How do I report a problem?', 'Show my complaints', 'What is the SLA deadline?', 'How does verification work?', 'Community issues near me'].map(q =>
          `<button class="text-[11px] bg-teal-50 text-teal-800 border border-teal-200 rounded-full px-2.5 py-1 hover:bg-teal-100" onclick="window.askAI(this.textContent, '${q}')">${q}</button>`).join('')}
      </div>
      <form class="p-3 flex gap-2" onsubmit="event.preventDefault(); window.askAI(document.getElementById('ai-input').value)">
        <label for="ai-input" class="sr-only">Message</label>
        <input id="ai-input" autocomplete="off" class="ns-input" placeholder="Ask about reporting, tracking or a complaint ID..." />
        <button class="btn-teal px-3" aria-label="Send">${iconSm(Icons.send, 18)}</button>
      </form>
    </div>`;
}

function bubble(m) {
  if (m.role === 'user') return `<div class="flex justify-end"><div class="max-w-[85%] bg-teal-700 text-white text-sm rounded-2xl rounded-br-sm px-3 py-2" translate="no">${esc(m.text)}</div></div>`;
  const actions = (m.actions || []).map(a => {
    if (a.type === 'open_complaint') return `<button class="text-xs font-bold text-teal-700 underline" onclick="window.navigate('${state.isStaff() ? 'admin-complaint' : 'complaint-detail'}', {id: '${esc(a.id)}'}); window.toggleAIDrawer(false)">Open complaint <span translate="no">${esc(a.id)}</span></button>`;
    if (a.type === 'navigate') return `<button class="text-xs font-bold text-teal-700 underline" onclick="window.navigate('${esc(a.route)}'); window.toggleAIDrawer(false)">Open page</button>`;
    if (a.type === 'start_report') return `<button class="text-xs font-bold text-white bg-teal-700 rounded-lg px-2.5 py-1" onclick="window.aiStartReport(${esc(JSON.stringify(a.category))}, ${esc(JSON.stringify(a.text))})">Start a report with this description</button>`;
    return '';
  }).join(' ');
  // Assistant replies are already in the chosen language (server-side templates), so not re-translated
  return `<div class="flex"><div class="max-w-[90%] bg-white border border-slate-200 text-slate-800 text-sm rounded-2xl rounded-bl-sm px-3 py-2 whitespace-pre-line"><span translate="no">${esc(m.text)}</span>${actions ? `<div class="mt-2 flex flex-wrap gap-2">${actions}</div>` : ''}</div></div>`;
}

function paint() {
  const box = document.getElementById('ai-messages');
  if (!box) return;
  box.innerHTML = history.map(bubble).join('');
  translateDOM(box);
  box.scrollTop = box.scrollHeight;
}

window.toggleAIDrawer = async (force) => {
  const d = document.getElementById('ai-drawer');
  if (!d) return;
  const open = force === undefined ? d.classList.contains('hidden') : force;
  d.classList.toggle('hidden', !open); d.classList.toggle('flex', open);
  if (open) {
    if (!history.length || history.lang !== getLanguage()) {
      history.length = 0; history.lang = getLanguage();
      try { const r = await api.chat('', getLanguage()); history.push({ role: 'ai', text: r.reply }); lastSource = r.sourceLabel; }
      catch (e) { history.push({ role: 'ai', text: t('The assistant is not reachable right now.') }); }
      const s = document.getElementById('ai-source'); if (s) { s.textContent = lastSource; }
    }
    paint();
    setTimeout(() => document.getElementById('ai-input')?.focus(), 50);
  }
};

window.askAI = async (text, intent) => {
  text = String(text || '').trim();
  if (!text) return;
  const input = document.getElementById('ai-input'); if (input) input.value = '';
  history.push({ role: 'user', text });
  history.push({ role: 'ai', text: t('Thinking...') });
  paint();
  try {
    const r = await api.chat(intent || text, getLanguage());
    history[history.length - 1] = { role: 'ai', text: r.reply, actions: r.actions };
    lastSource = r.sourceLabel;
    const s = document.getElementById('ai-source'); if (s) { s.textContent = lastSource; }
  } catch (e) { history[history.length - 1] = { role: 'ai', text: t(e.message) }; }
  paint();
};

window.aiStartReport = (category, text) => {
  sessionStorage.setItem('ns_report_draft', JSON.stringify({ description: text, suggested: category }));
  window.toggleAIDrawer(false);
  window.navigate('report-issue');
};
