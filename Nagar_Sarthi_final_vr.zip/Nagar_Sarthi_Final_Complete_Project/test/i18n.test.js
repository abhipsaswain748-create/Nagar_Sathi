// Translation catalogue checks: every key has Hindi and Odia text, placeholders match,
// and every English string passed to t() in the code exists in the catalogue.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { hi, or } = require('../tools/build-i18n.js');

test('Hindi and Odia catalogues have the same keys and no empty values', () => {
  assert.deepStrictEqual(Object.keys(hi).sort(), Object.keys(or).sort());
  for (const [k, v] of Object.entries(hi)) assert.ok(v && or[k], `empty translation for: ${k}`);
  assert.ok(Object.keys(hi).length > 1000);
});

test('Hindi strings are in Devanagari and Odia strings in Odia script', () => {
  const latinOnly = s => !/[\u0900-\u097F\u0B00-\u0B7F]/.test(s);
  const allowed = /^[\s{}\d→:|.,()+·*-]*$|^(SLA|AI|ID|GPS|OSM)/;
  for (const [k, v] of Object.entries(hi)) if (latinOnly(v)) assert.ok(allowed.test(v) || v === k, `Hindi value looks untranslated: ${k}`);
  for (const [k, v] of Object.entries(or)) if (latinOnly(v)) assert.ok(allowed.test(v) || v === k, `Odia value looks untranslated: ${k}`);
  for (const v of Object.values(hi)) assert.ok(!/[\u0B00-\u0B7F]/.test(v), 'Odia script inside Hindi value: ' + v);
  for (const v of Object.values(or)) assert.ok(!/[\u0900-\u0963\u0966-\u097F]/.test(v), 'Devanagari inside Odia value: ' + v);
});

test('every literal t("...") string in the frontend is in the catalogue', () => {
  const files = [];
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => e.isDirectory() ? (e.name !== 'i18n' && walk(path.join(d, e.name))) : e.name.endsWith('.js') && files.push(path.join(d, e.name)));
  walk(path.join(__dirname, '..', 'public', 'js'));
  const missing = [];
  for (const f of files) {
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(/\bt\(\s*'((?:[^'\\]|\\.)*)'/g)) {
      const key = m[1].replace(/\\'/g, "'");
      if (!(key in hi) && key !== 'English text') missing.push(`${path.basename(f)}: ${key}`);
    }
  }
  assert.deepStrictEqual(missing, []);
});


test('population map and dashboard labels are translated in both catalogues', () => {
  const keys = [
    'Danger / high-risk reports (red dots)', 'Population density by ward', 'Population density',
    'Ward {0}', 'Population', 'Ward area', 'Lower', 'Moderate', 'High', 'Very high',
    'Population density overview', 'Open population density map'
  ];
  for (const key of keys) {
    assert.ok(hi[key], `missing Hindi translation: ${key}`);
    assert.ok(or[key], `missing Odia translation: ${key}`);
  }
});
