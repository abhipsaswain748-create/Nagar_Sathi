// End-to-end lifecycle: citizen report → admin assignment → field evidence → admin approval →
// citizen dispute → reopen → completion → citizen confirmation → feedback, plus notifications.
const test = require('node:test');
const assert = require('node:assert');
const { startServer, client, login, JPEG_1PX } = require('./helpers');

let srv;
test.before(async () => { srv = await startServer(); });
test.after(() => srv.stop());

test('full complaint lifecycle with evidence, dispute and verification', async () => {
  const cit = await login(srv.base, 'citizen');
  const adm = await login(srv.base, 'admin');
  const fld = await login(srv.base, 'field');

  // AI suggestion is only a suggestion
  const cls = await cit.post('/api/ai/classify', { text: 'There is a large amount of garbage lying near the main market for three days' });
  assert.strictEqual(cls.data.data.category, 'Garbage accumulation');
  const cls2 = await cit.post('/api/ai/classify', { text: 'garbage near market', exclude: ['Garbage accumulation'] });
  assert.notStrictEqual(cls2.data.data.category, 'Garbage accumulation', 'reconsider excludes previous suggestion');

  // invalid category is rejected; citizen-chosen category is stored as chosen
  assert.strictEqual((await cit.post('/api/complaints', { description: 'Deep pothole here', category: 'Not a category', latitude: 20.3, longitude: 85.8 })).status, 400);
  const photo = (await cit.post('/api/media', { data: JPEG_1PX, purpose: 'complaint' })).data.media;
  const created = await cit.post('/api/complaints', {
    description: 'Deep pothole on Janpath near Ram Mandir, two scooters skidded', category: 'Road damage / potholes', category_source: 'ai_overridden',
    ai_suggested_category: 'Garbage accumulation', latitude: 20.2842, longitude: 85.8431, location_address: 'Janpath, Saheed Nagar', media_ids: [photo.id]
  });
  assert.strictEqual(created.status, 201);
  const id = created.data.complaintId;
  assert.match(id, /^NS-\d{4}-\d+$/);
  let c = (await cit.get(`/api/complaints/${id}`)).data.data;
  assert.strictEqual(c.category, 'Road damage / potholes');
  assert.strictEqual(c.category_source, 'ai_overridden');
  assert.strictEqual(c.status, 'Submitted');
  assert.strictEqual(c.attachments.filter(a => a.evidence_type === 'complaint').length, 1);

  // invalid transition is refused
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Resolved' })).status, 409);
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Under Review' })).status, 200);
  assert.strictEqual((await adm.post(`/api/complaints/${id}/priority`, { priority: 'High' })).status, 400, 'reason required');
  assert.strictEqual((await adm.post(`/api/complaints/${id}/priority`, { priority: 'High', reason: 'Accident risk' })).status, 200);
  assert.strictEqual((await adm.post(`/api/complaints/${id}/assign`, { department_id: 'dept-roads', assigned_officer_id: 'officer-1' })).status, 200);
  assert.strictEqual((await adm.post(`/api/complaints/${id}/request-info`, { message: 'Is the pothole on the left lane?' })).status, 200);
  assert.strictEqual((await cit.post(`/api/complaints/${id}/respond-info`, { message: 'Yes, left lane' })).status, 200);

  // field worker evidence
  const insp = (await fld.post('/api/media', { data: JPEG_1PX, purpose: 'inspection' })).data.media;
  assert.strictEqual((await fld.post(`/api/complaints/${id}/evidence`, { evidence_type: 'inspection', notes: 'Inspected', media_ids: [insp.id] })).status, 200);
  assert.strictEqual((await fld.post(`/api/complaints/${id}/evidence`, { evidence_type: 'completion', notes: 'done' })).status, 400, 'completion needs a photo');
  const done = (await fld.post('/api/media', { data: JPEG_1PX, purpose: 'completion' })).data.media;
  assert.strictEqual((await fld.post(`/api/complaints/${id}/evidence`, { evidence_type: 'completion', notes: 'Filled', media_ids: [done.id] })).status, 200);
  c = (await adm.get(`/api/complaints/${id}`)).data.data;
  assert.strictEqual(c.status, 'Resolution Submitted', 'field worker cannot close');
  assert.strictEqual((await cit.post(`/api/complaints/${id}/verify`, { verified: true })).status, 409, 'not yet awaiting citizen');

  // admin approves → citizen is asked to verify
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Resolved' })).status, 200);
  const notes = (await cit.get('/api/notifications')).data.data;
  assert.ok(notes.some(n => n.complaint_id === id && n.type === 'verification_request'));

  // citizen disputes with a reason + photo
  assert.strictEqual((await cit.post(`/api/complaints/${id}/verify`, { verified: false })).status, 400);
  const dp = (await cit.post('/api/media', { data: JPEG_1PX, purpose: 'dispute' })).data.media;
  assert.strictEqual((await cit.post(`/api/complaints/${id}/verify`, { verified: false, dispute_reason: 'Still broken', media_ids: [dp.id] })).status, 200);
  c = (await adm.get(`/api/complaints/${id}`)).data.data;
  assert.strictEqual(c.status, 'Disputed');
  assert.strictEqual(c.attachments.filter(a => a.evidence_type === 'dispute').length, 1);
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Reopened' })).status, 400, 'reason required');
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Reopened', notes: 'Valid dispute' })).status, 200);

  // rework → approve → citizen confirms
  const done2 = (await fld.post('/api/media', { data: JPEG_1PX, purpose: 'completion' })).data.media;
  assert.strictEqual((await fld.post(`/api/complaints/${id}/evidence`, { evidence_type: 'completion', notes: 'Relaid', media_ids: [done2.id] })).status, 200);
  assert.strictEqual((await adm.patch(`/api/complaints/${id}/status`, { status: 'Resolved' })).status, 200);
  assert.strictEqual((await cit.post(`/api/complaints/${id}/verify`, { verified: true })).status, 200);
  c = (await cit.get(`/api/complaints/${id}`)).data.data;
  assert.strictEqual(c.status, 'Verified / Closed');
  const statuses = c.timeline.map(t => t.to_status);
  for (const s of ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolution Submitted', 'Resolved', 'Disputed', 'Reopened', 'Verified / Closed']) assert.ok(statuses.includes(s), s);
  assert.ok(!c.audits, 'citizen does not receive audit log');
  const full = (await adm.get(`/api/complaints/${id}`)).data.data;
  assert.ok(full.audits.length >= 8);

  // feedback linked to the complaint, then answered by admin
  assert.strictEqual((await cit.post('/api/feedback', { feedback_type: 'resolution', complaint_id: id, message: 'Good' })).status, 400, 'rating required');
  const fb = await cit.post('/api/feedback', { feedback_type: 'resolution', complaint_id: id, rating: 4, resolution_rating: 4, department_rating: 5, work_satisfactory: 'yes', message: 'Fixed after second attempt' });
  assert.strictEqual(fb.status, 201);
  const inbox = (await adm.get('/api/feedback?department_id=dept-roads')).data.data;
  assert.ok(inbox.some(f => f.id === fb.data.feedbackId));
  assert.strictEqual((await adm.patch(`/api/feedback/${fb.data.feedbackId}`, { admin_response: 'Thank you', status: 'Responded' })).status, 200);
  assert.ok((await cit.get('/api/notifications')).data.data.some(n => n.type === 'feedback_response'));

  // other citizen: community confirmation, once
  const c2 = await login(srv.base, 'citizen2');
  assert.strictEqual((await c2.post(`/api/complaints/NS-2026-1102/confirm`, {})).status, 200);
  assert.strictEqual((await c2.post(`/api/complaints/NS-2026-1102/confirm`, {})).status, 409);
});

test('notifications are private and mark-as-read is per user', async () => {
  const a = await login(srv.base, 'citizen');
  const b = await login(srv.base, 'citizen2');
  const an = (await a.get('/api/notifications')).data.data;
  const bn = (await b.get('/api/notifications')).data.data;
  assert.ok(an.every(n => n.user_id === a.user.id));
  assert.ok(bn.every(n => n.user_id === b.user.id));
  if (an.length) assert.strictEqual((await b.post(`/api/notifications/${an[0].id}/read`)).status, 404);
});

test('public data, AI chat grounding and admin analytics', async () => {
  const g = client(srv.base);
  const stats = (await g.get('/api/public/stats')).data.data;
  assert.ok(stats.total > 0 && stats.includesDemo === true);
  assert.ok((await g.get('/api/intel/recurring')).data.data.some(r => r.flag_preventive_maintenance));
  assert.strictEqual((await g.get('/api/weather/risk')).data.data.available, false, 'no invented weather when disabled');
  const anon = await g.post('/api/ai/chat', { message: 'status of NS-2026-1041', language: 'Hindi' });
  assert.match(anon.data.reply, /लॉग इन/);
  const cit = await login(srv.base, 'citizen');
  const own = await cit.post('/api/ai/chat', { message: 'status of NS-2026-1041', language: 'Odia' });
  assert.match(own.data.reply, /NS-2026-1041/);
  const other = await cit.post('/api/ai/chat', { message: 'NS-2026-1101', language: 'English' });
  assert.match(other.data.reply, /could not find/, 'assistant must not reveal other citizens complaints');
  const adm = await login(srv.base, 'admin');
  const ov = (await adm.get('/api/admin/overview')).data.data;
  assert.ok(ov.total > 0 && ov.sla);
  const deps = (await adm.get('/api/admin/departments')).data.data;
  assert.ok(deps.every(d => d.avgResolutionHours === null || d.sampleSize >= 2));
});

test('registration and language preference persistence', async () => {
  const g = client(srv.base);
  assert.strictEqual((await g.post('/api/auth/citizen/register', { name: 'Test', email: 't@example.com', password: 'short' })).status, 400);
  const r = await g.post('/api/auth/citizen/register', { name: 'Test User', email: 't@example.com', password: 'Testpass123', language: 'Odia' });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.data.user.role, 'citizen');
  assert.strictEqual((await g.patch('/api/auth/preferences', { preferred_language: 'Hindi' })).status, 200);
  assert.strictEqual((await g.get('/api/auth/me')).data.user.preferred_language, 'Hindi');
  assert.strictEqual((await g.post('/api/auth/citizen/register', { name: 'x', email: 't@example.com', password: 'Testpass123' })).status, 409);
});
