// Test harness: starts an isolated server (temporary database + upload folder) and gives
// cookie-aware HTTP clients for each demo role.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ACCOUNTS = {
  citizen: ['priyadarshini.jena@odisha.in', 'Citizen@2026', 'citizen'],
  citizen2: ['rajesh.mohanty@gmail.com', 'Citizen@2026', 'citizen'],
  admin: ['commissioner.bmc@bhubaneswar.gov.in', 'Staff@2026', 'staff'],
  dept: ['s.tripathy@bmc.gov.in', 'Staff@2026', 'staff'],
  field: ['amit.rout@field.bmc.gov.in', 'Staff@2026', 'staff'],
  field2: ['manoj.behera@field.bmc.gov.in', 'Staff@2026', 'staff']
};

async function startServer() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ns-test-'));
  const port = 4100 + Math.floor(Math.random() * 800);
  const env = { ...process.env, PORT: String(port), DB_PATH: path.join(dir, 'test.db'), UPLOAD_DIR: path.join(dir, 'uploads'), WEATHER_DISABLED: 'true', AZURE_SPEECH_KEY: '', ANTHROPIC_API_KEY: '' };
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server', 'index.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  await new Promise((resolve, reject) => {
    const to = setTimeout(() => reject(new Error('server start timeout')), 15000);
    proc.stdout.on('data', d => { if (String(d).includes('Server running')) { clearTimeout(to); resolve(); } });
    proc.on('exit', c => reject(new Error('server exited ' + c)));
  });
  return { base: `http://127.0.0.1:${port}`, stop: () => { proc.kill(); fs.rmSync(dir, { recursive: true, force: true }); } };
}

function client(base) {
  let cookie = '';
  async function req(method, p, body, extraHeaders = {}) {
    const res = await fetch(base + p, {
      method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...extraHeaders },
      body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body))
    });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch (e) { data = text; }
    return { status: res.status, data, headers: res.headers };
  }
  return {
    get: p => req('GET', p), post: (p, b) => req('POST', p, b ?? {}), patch: (p, b) => req('PATCH', p, b ?? {}), del: p => req('DELETE', p),
    raw: req, cookie: () => cookie, setCookie: c => { cookie = c; }
  };
}

async function login(base, who) {
  const c = client(base);
  const [email, password, portal] = ACCOUNTS[who];
  const r = await c.post(`/api/auth/${portal}/login`, { email, password });
  if (r.status !== 200) throw new Error(`login failed for ${who}: ${r.status} ${JSON.stringify(r.data)}`);
  c.user = r.data.user;
  return c;
}

// A tiny valid JPEG (1x1 px) generated once
const JPEG_1PX = '/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';

module.exports = { startServer, client, login, ACCOUNTS, JPEG_1PX };
