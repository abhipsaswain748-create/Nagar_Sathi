// Security & permission tests (run: npm test)
const test = require('node:test');
const assert = require('node:assert');
const { startServer, client, login, JPEG_1PX } = require('./helpers');

let srv;
test.before(async () => { srv = await startServer(); });
test.after(() => srv.stop());

test('unauthenticated users cannot read protected records', async () => {
  const g = client(srv.base);
  for (const p of ['/api/complaints', '/api/complaints/NS-2026-1041', '/api/admin/overview', '/api/feedback', '/api/officers', '/api/admin/audit', '/api/innovations/civic-trace']) {
    const r = await g.get(p);
    assert.strictEqual(r.status, 401, p);
  }
  assert.strictEqual((await g.post('/api/complaints', { title: 'x' })).status, 401);
});

test('old persona switch endpoint no longer exists', async () => {
  const g = client(srv.base);
  const r = await g.post('/api/auth/switch-role', { role: 'admin' });
  assert.strictEqual(r.status, 404);
  assert.strictEqual((await g.get('/api/auth/me')).data.user, null);
});

test('portal separation: staff cannot use citizen login and vice versa', async () => {
  const g = client(srv.base);
  assert.strictEqual((await g.post('/api/auth/citizen/login', { email: 'commissioner.bmc@bhubaneswar.gov.in', password: 'Staff@2026' })).status, 403);
  assert.strictEqual((await g.post('/api/auth/staff/login', { email: 'priyadarshini.jena@odisha.in', password: 'Citizen@2026' })).status, 403);
  assert.strictEqual((await g.post('/api/auth/staff/login', { email: 'commissioner.bmc@bhubaneswar.gov.in', password: 'wrong' })).status, 401);
});

test('session cookie is HttpOnly + SameSite and logout invalidates it', async () => {
  const c = client(srv.base);
  const r = await c.post('/api/auth/citizen/login', { email: 'priyadarshini.jena@odisha.in', password: 'Citizen@2026' });
  const sc = r.headers.get('set-cookie');
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Lax/);
  const stolen = c.cookie();
  assert.strictEqual((await c.get('/api/complaints')).status, 200);
  await c.post('/api/auth/logout');
  const replay = client(srv.base); replay.setCookie(stolen);
  assert.strictEqual((await replay.get('/api/complaints')).status, 401, 'old session token must be rejected after logout');
});

test('a citizen cannot call administrator endpoints', async () => {
  const c = await login(srv.base, 'citizen');
  assert.strictEqual((await c.get('/api/admin/overview')).status, 403);
  assert.strictEqual((await c.post('/api/complaints/NS-2026-1041/assign', { department_id: 'dept-roads', assigned_officer_id: 'officer-1' })).status, 403);
  assert.strictEqual((await c.patch('/api/complaints/NS-2026-1041/status', { status: 'Resolved' })).status, 403);
  assert.strictEqual((await c.post('/api/complaints/NS-2026-1041/priority', { priority: 'Low', reason: 'x' })).status, 403);
  assert.strictEqual((await c.post('/api/complaints/NS-2026-1041/evidence', { evidence_type: 'completion' })).status, 403);
  assert.strictEqual((await c.get('/api/innovations/civic-trace')).status, 403);
});

test("a citizen only sees and changes their own complaints", async () => {
  const c = await login(srv.base, 'citizen');
  const list = (await c.get('/api/complaints')).data.data;
  assert.ok(list.length > 0 && list.every(x => x.citizen_id === c.user.id));
  // NS-2026-1101 belongs to citizen2
  assert.strictEqual((await c.get('/api/complaints/NS-2026-1101')).status, 403);
  assert.strictEqual((await c.post('/api/complaints/NS-2026-1101/verify', { verified: true })).status, 403);
  // the citizen_id query parameter can not widen the scope
  const sneaky = (await c.get('/api/complaints?citizen_id=user-citizen-2')).data.data;
  assert.ok(sneaky.every(x => x.citizen_id === c.user.id));
});

test('field worker sees only assigned tasks; department official only own department', async () => {
  const f = await login(srv.base, 'field');
  const tasks = (await f.get('/api/complaints')).data.data;
  assert.ok(tasks.length > 0 && tasks.every(x => x.assigned_officer_id === 'officer-1'));
  assert.strictEqual((await f.get('/api/complaints/NS-2026-1101')).status, 403, 'unassigned task');
  assert.strictEqual((await f.patch('/api/complaints/NS-2026-1041/status', { status: 'Resolved' })).status, 403, 'field worker cannot set status');
  const d = await login(srv.base, 'dept');
  const dl = (await d.get('/api/complaints')).data.data;
  assert.ok(dl.length > 0 && dl.every(x => x.department_id === 'dept-roads'));
  assert.strictEqual((await d.get('/api/complaints/NS-2026-1101')).status, 403, 'other department');
  assert.strictEqual((await d.post('/api/complaints/NS-2026-1041/assign', { department_id: 'dept-water' })).status, 403, 'cannot move to another dept');
});

test('SQL injection strings in filters do not bypass scoping', async () => {
  const c = await login(srv.base, 'citizen');
  for (const s of ["' OR 1=1 --", "1'; DROP TABLE complaints; --", '" OR ""="']) {
    const r = await c.get('/api/complaints?search=' + encodeURIComponent(s));
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.data.length, 0);
  }
  const a = await login(srv.base, 'admin');
  assert.ok((await a.get('/api/complaints')).data.data.length > 5, 'table still intact');
});

test('upload validation: type, size, purpose and private access', async () => {
  const c = await login(srv.base, 'citizen');
  assert.strictEqual((await c.post('/api/media', { data: Buffer.from('<?php echo 1; ?>').toString('base64'), purpose: 'complaint' })).status, 415);
  assert.strictEqual((await c.post('/api/media', { data: Buffer.from('MZ\x90\x00 exe').toString('base64'), purpose: 'complaint' })).status, 415);
  assert.strictEqual((await c.post('/api/media', { data: JPEG_1PX, purpose: 'completion' })).status, 403, 'citizen cannot upload official evidence');
  const big = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff]), Buffer.alloc(6 * 1024 * 1024)]).toString('base64');
  assert.strictEqual((await c.post('/api/media', { data: big, purpose: 'complaint' })).status, 413);
  const ok = await c.post('/api/media', { data: JPEG_1PX, purpose: 'complaint' });
  assert.strictEqual(ok.status, 201);
  const url = ok.data.media.url;
  assert.strictEqual((await c.get(url)).status, 200);
  assert.strictEqual((await client(srv.base).get(url)).status, 401, 'anonymous cannot fetch private photo');
  const other = await login(srv.base, 'citizen2');
  assert.strictEqual((await other.get(url)).status, 403, 'other citizen cannot fetch private photo');
});

test('oversized request bodies are rejected', async () => {
  const c = await login(srv.base, 'citizen');
  const r = await c.raw('POST', '/api/feedback', JSON.stringify({ message: 'x'.repeat(40 * 1024 * 1024) })).catch(e => ({ status: 413 }));
  assert.ok([413].includes(r.status) || r.status === undefined);
});

test('static path traversal and the old source archive are not served', async () => {
  const g = client(srv.base);
  const r = await fetch(srv.base + '/..%2fserver%2fauth.js');
  const t = await r.text();
  assert.ok(!t.includes('hashPassword'), 'server source must not be readable');
  const z = await fetch(srv.base + '/Nagar_Sarthi_Enhanced_Complete_Project.zip');
  assert.ok(!(z.headers.get('content-type') || '').includes('zip'));
});

test('public map hides personal data and private photos', async () => {
  const r = await client(srv.base).get('/api/complaints-public-map');
  assert.strictEqual(r.status, 200);
  for (const x of r.data.data) {
    for (const k of ['citizen_id', 'citizen_name', 'citizen_phone', 'location_address']) assert.strictEqual(x[k], undefined, k);
    assert.strictEqual(x.privacy_protected, true);
  }
});

test('login is rate limited after repeated failures', async () => {
  const g = client(srv.base);
  let last;
  for (let i = 0; i < 10; i++) last = await g.post('/api/auth/citizen/login', { email: 'nobody@example.com', password: 'bad' });
  assert.strictEqual(last.status, 429);
});
