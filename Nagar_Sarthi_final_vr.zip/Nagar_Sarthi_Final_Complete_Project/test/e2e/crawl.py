import asyncio, json, sys
from playwright.async_api import async_playwright
import os
B=os.environ.get('NS_URL','http://127.0.0.1:3000')
CH=os.environ.get('CHROME_PATH') or None
ACC={'citizen':('priyadarshini.jena@odisha.in','Citizen@2026','citizen'),'admin':('commissioner.bmc@bhubaneswar.gov.in','Staff@2026','staff'),
     'dept':('s.tripathy@bmc.gov.in','Staff@2026','staff'),'field':('amit.rout@field.bmc.gov.in','Staff@2026','staff')}
ROUTES={'guest':['home','public-map','public-map?view=list','community-issues','community-issues?tab=recurring','community-issues?tab=hotspots','community-issues?tab=reports','about','legal-policies','legal-policies?tab=faq','legal-policies?tab=terms','legal-policies?tab=data','legal-policies?tab=accessibility','legal-policies?tab=attributions','legal-policies?tab=security','legal-policies?tab=cookies','legal-policies?tab=disclaimer','citizen-login','citizen-register','admin-login'],
 'citizen':['citizen-dashboard','report-issue','my-complaints','my-complaints?group=progress','complaint-detail/NS-2026-1106','complaint-detail/NS-2026-1102','feedback','feedback?tab=pending','feedback?tab=mine','feedback?tab=disputed','settings','community-issues'],
 'admin':['admin-dashboard','complaints-mgmt','admin-complaint/NS-2026-1104','admin-complaint/NS-2026-1107','sla-monitor','departments-mgmt','field-workers','admin-feedback','intelligence','intelligence?tab=recurring','intelligence?tab=hotspots','intelligence?tab=incidents','gis-command','gis-command?view=list','audit-log','settings'],
 'dept':['admin-dashboard','complaints-mgmt','departments-mgmt'],
 'field':['field-tasks','admin-complaint/NS-2026-1041']}
async def main(lang='English', roles=None, shots=False, width=1366):
    roles = roles or list(ROUTES)
    missing={}; softm={}
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH)
        for role in roles:
            ctx=await b.new_context(viewport={'width':width,'height':900})
            pg=await ctx.new_page()
            errs=[]
            pg.on('pageerror', lambda e: errs.append('PAGEERROR '+str(e)[:200]))
            pg.on('console', lambda m: errs.append('CONSOLE '+m.text[:200]) if m.type=='error' and 'ERR_NAME_NOT_RESOLVED' not in m.text and 'Failed to load resource' not in m.text else None)
            await pg.route('**/fonts.googleapis.com/**', lambda r: r.abort())
            await pg.goto(B+'/'); await pg.evaluate(f"localStorage.setItem('ns_lang','{lang}')")
            if role!='guest':
                e,pw,portal=ACC[role]
                r=await pg.evaluate(f"fetch('/api/auth/{portal}/login',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{email:'{e}',password:'{pw}',language:'{lang}'}})}}).then(r=>r.status)")
                assert r==200, (role, r)
            for rt in ROUTES[role]:
                errs.clear()
                await pg.goto(B+'/#'+rt); await pg.reload(); await pg.wait_for_timeout(1300)
                txt=await pg.evaluate("document.querySelector('main').innerText.slice(0,120).replace(/\\n/g,' | ')")
                ov=await pg.evaluate("document.documentElement.scrollWidth - window.innerWidth")
                if ov>0:
                    culprit=await pg.evaluate("""(()=>{const W=window.innerWidth;let best=null;document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>W+1&&r.width>0){const st=getComputedStyle(e);if(!best||r.width<best.w) best={w:r.width,tag:e.tagName,cls:(e.className&&e.className.baseVal===undefined?e.className:'').slice(0,80),txt:(e.innerText||'').slice(0,40)}}});return best})()""")
                    errs.append('OVERFLOW '+str(culprit))
                bad=[x for x in errs]
                print(f"[{role}] {rt}: overflow={ov} {'ERR '+str(bad[:3]) if bad else ''} :: {txt[:90]}")
                for x in await pg.evaluate("[...window.__i18nMissing]"): missing[x]=role+':'+rt
                for x in await pg.evaluate("[...(window.__i18nSoft||[])]"): softm[x]=role+':'+rt
                if shots: await pg.screenshot(path=f"/tmp/shot_{role}_{rt.replace('/','_').replace('?','_')}_{lang}_{width}.png", full_page=True)
            await ctx.close()
        await b.close()
    json.dump({'missing':missing,'soft':softm}, open(f'/tmp/missing_{lang}.json','w'), ensure_ascii=False, indent=0)
    print('MISSING', len(missing), 'SOFT', len(softm))
a=sys.argv
if __name__=="__main__": asyncio.run(main(a[1] if len(a)>1 else 'English', a[2].split(',') if len(a)>2 and a[2] else None, len(a)>3 and a[3]=='1', int(a[4]) if len(a)>4 else 1366))
