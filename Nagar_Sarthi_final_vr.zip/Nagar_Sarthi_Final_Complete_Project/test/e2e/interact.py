import asyncio, json, sys
from playwright.async_api import async_playwright
from crawl import ACC, B, CH
async def run(lang):
    miss=set(); soft=set()
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH)
        async def ctxfor(role, width=1366):
            ctx=await b.new_context(viewport={'width':width,'height':900}); pg=await ctx.new_page(); pg.set_default_timeout(4000)
            await pg.route('**/fonts.googleapis.com/**', lambda r: r.abort())
            await pg.goto(B+'/'); await pg.evaluate(f"localStorage.setItem('ns_lang','{lang}')")
            if role!='guest':
                e,pw,portal=ACC[role]
                await pg.evaluate(f"fetch('/api/auth/{portal}/login',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{email:'{e}',password:'{pw}',language:'{lang}'}})}})")
            return pg
        async def harvest(pg):
            for x in await pg.evaluate("[...window.__i18nMissing]"): miss.add(x)
            for x in await pg.evaluate("[...window.__i18nSoft]"): soft.add(x)
        # guest: AI drawer, mobile menu, login error
        pg=await ctxfor('guest', 400)
        await pg.goto(B+'/#home'); await pg.reload(); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('button[aria-controls=mobile-menu]').click()"); await pg.wait_for_timeout(300)
        await pg.evaluate("window.toggleAIDrawer(true)"); await pg.wait_for_timeout(800)
        await pg.evaluate("window.askAI('x','How do I report a problem?')"); await pg.wait_for_timeout(800)
        await pg.goto(B+'/#citizen-login'); await pg.wait_for_timeout(800)
        await pg.fill('#f-email','a@b.c'); await pg.fill('#f-pass','x'); await pg.evaluate("document.getElementById('cit-form').requestSubmit()"); await pg.wait_for_timeout(800)
        await harvest(pg); print('step', flush=True)
        # citizen: report flow + voice modal + notifications
        pg=await ctxfor('citizen')
        await pg.goto(B+'/#report-issue'); await pg.reload(); await pg.wait_for_timeout(1200)
        await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(400)
        await pg.fill('#rf-desc','hello there friend nothing'); await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(1200)
        await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(300)
        await pg.evaluate("window.rfPickDomain('Water leakage')"); await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(1200)
        await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(400)
        await pg.evaluate("window.rfFindLandmark()"); await pg.fill('#rf-landmark','zzzz'); await pg.evaluate("window.rfFindLandmark()"); await pg.fill('#rf-landmark','Rasulgarh'); await pg.evaluate("window.rfFindLandmark()"); await pg.wait_for_timeout(800)
        await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(800)
        await pg.evaluate("window.rfNext()"); await pg.wait_for_timeout(800)
        await pg.evaluate("window.rfVoice()"); await pg.wait_for_timeout(800)
        await pg.evaluate("document.querySelector('[data-lang=Odia]').click()"); await pg.wait_for_timeout(300)
        await harvest(pg); print('step', flush=True)
        await pg.goto(B+'/#citizen-dashboard'); await pg.reload(); await pg.wait_for_timeout(1200)
        await pg.evaluate("window.toggleNotifications()"); await pg.wait_for_timeout(400)
        await pg.evaluate("document.getElementById('user-menu').classList.remove('hidden')")
        await pg.evaluate("window.toggleAIDrawer(true)"); await pg.wait_for_timeout(700)
        for q in ['Show my complaints','What is the SLA deadline?','How does verification work?','Community issues near me']:
            await pg.evaluate(f"window.askAI('x','{q}')"); await pg.wait_for_timeout(500)
        await pg.goto(B+'/#feedback'); await pg.reload(); await pg.wait_for_timeout(1000)
        await pg.evaluate("document.getElementById('fb-form').requestSubmit()"); await pg.wait_for_timeout(500)
        await pg.goto(B+'/#complaint-detail/NS-2026-1106'); await pg.reload(); await pg.wait_for_timeout(1000)
        await pg.evaluate("window.cdVerify(false)"); await pg.wait_for_timeout(500)
        await pg.goto(B+'/#public-map'); await pg.reload(); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('.leaflet-marker-icon') && document.querySelector('.leaflet-marker-icon').click()"); await pg.wait_for_timeout(700)
        await harvest(pg); print('step', flush=True)
        # admin modals
        pg=await ctxfor('admin')
        for fn in ['caPriority','caInfo','caEscalate','caRemark']:
            await pg.goto(B+'/#admin-complaint/NS-2026-1105'); await pg.reload(); await pg.wait_for_timeout(1200)
            await pg.evaluate(f"(window.{fn}(), 0)"); await pg.wait_for_timeout(500)
            await pg.evaluate("document.getElementById('ns-ask-ok') && document.getElementById('ns-ask-ok').click()"); await pg.wait_for_timeout(300)
            await harvest(pg); print('step', flush=True)
        await pg.evaluate("window.caStatus('Resolved')"); await pg.wait_for_timeout(800)
        await harvest(pg); print('step', flush=True)
        await b.close()
    json.dump({'missing':sorted(miss),'soft':sorted(soft)}, open(f'/tmp/interact_{lang}.json','w'), ensure_ascii=False, indent=0)
    print(len(miss), len(soft))
asyncio.run(run(sys.argv[1]))
