import asyncio, sys
from playwright.async_api import async_playwright
from crawl import ACC, B, CH
async def main(role, route, out, width=1366, lang='English', script=None, h=900):
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH)
        ctx=await b.new_context(viewport={'width':width,'height':h})
        pg=await ctx.new_page()
        await pg.route('**/fonts.googleapis.com/**', lambda r: r.abort())
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(B+'/'); await pg.evaluate(f"localStorage.setItem('ns_lang','{lang}')")
        if role!='guest':
            e,pw,portal=ACC[role]
            await pg.evaluate(f"fetch('/api/auth/{portal}/login',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{email:'{e}',password:'{pw}'}})}})")
        await pg.goto(B+'/#'+route); await pg.reload(); await pg.wait_for_timeout(1500)
        if script:
            for s in script.split(';;'):
                await pg.evaluate(s); await pg.wait_for_timeout(900)
        await pg.screenshot(path=out, full_page=True)
        print(errs[:3])
        await b.close()
a=sys.argv
asyncio.run(main(a[1], a[2], a[3], int(a[4]) if len(a)>4 else 1366, a[5] if len(a)>5 else 'English', a[6] if len(a)>6 else None))
